'use strict';

/**
 * public/forside.js
 *
 * Personaleskærmens forside: navnene, uret og intet andet.
 *
 * Skærmen står tændt hele dagen, så den holder sig selv opdateret:
 * uret hvert sekund, navnelisten hvert halve minut. Bliver forbindelsen
 * væk, siger den det tydeligt frem for at vise gamle oplysninger som
 * om de var friske.
 */

(function () {
  const { kald, lav, toem, find, vis, skjul, datoDansk, klokkenNu, iDag, varighed } = window.TR;

  const UGEDAGE = [
    'Søndag', 'Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag'
  ];

  const OPDATERING_SEKUNDER = 30;

  const navneomraade = find('#navne');
  const beskedomraade = find('#besked');
  const undertekst = find('#undertekst');
  const klokke = find('#klokke');
  const dagsdato = find('#dagsdato');

  let sidsteHentning = 0;

  /* ------------------------------------------------------------------ */
  /* Uret                                                               */
  /* ------------------------------------------------------------------ */

  function opdaterKlokke() {
    klokke.textContent = klokkenNu();

    const dato = iDag();
    const ugedag = UGEDAGE[new Date(`${dato}T12:00:00Z`).getUTCDay()];

    dagsdato.textContent = `${ugedag} ${datoDansk(dato)}`;
  }

  /* ------------------------------------------------------------------ */
  /* Navnene                                                            */
  /* ------------------------------------------------------------------ */

  function tegnNavn(medarbejder) {
    const paaArbejde = medarbejder.erCheketInd;

    const status = paaArbejde
      ? `På arbejde siden ${medarbejder.checkIndKlokkeslaet}`
      : 'Ikke checket ind';

    return lav('button', {
      klasse: `boks${paaArbejde ? ' paa-arbejde' : ''}`,
      type: 'button',
      'aria-label': `${medarbejder.navn}. ${status}.`,
      paaClick: () => {
        window.location.href = `/medarbejder/${medarbejder.id}`;
      }
    }, [
      lav('span', { klasse: 'boks-navn', tekst: medarbejder.navn }),
      lav('span', { klasse: 'boks-status' }, [
        lav('span', { klasse: 'prik' }),
        lav('span', { tekst: status })
      ])
    ]);
  }

  function tegnListe(medarbejdere) {
    toem(navneomraade);

    if (medarbejdere.length === 0) {
      // Ingen henvisning til Administration her. Skærmen står frit fremme ved
      // personaleindgangen, og panelet skal hverken kunne klikkes eller læses
      // ud af siden. Adressen står i LAES-MIG.
      navneomraade.append(lav('div', { klasse: 'tom-besked' }, [
        lav('p', { tekst: 'Der er ingen medarbejdere oprettet endnu.' })
      ]));

      undertekst.textContent = 'Ingen medarbejdere';
      return;
    }

    for (const medarbejder of medarbejdere) {
      navneomraade.append(tegnNavn(medarbejder));
    }

    const paaArbejde = medarbejdere.filter((m) => m.erCheketInd).length;

    undertekst.textContent = paaArbejde === 0
      ? `${medarbejdere.length} medarbejdere · ingen på arbejde lige nu`
      : `${medarbejdere.length} medarbejdere · ${paaArbejde} på arbejde lige nu`;
  }

  async function hent() {
    try {
      const svar = await kald('/api/medarbejdere');

      tegnListe(svar.medarbejdere);
      skjul(beskedomraade);
      sidsteHentning = Date.now();
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl');

      // Første hentning: skærmen er tom, så fjern "henter"-teksten
      if (sidsteHentning === 0) {
        toem(navneomraade);
        undertekst.textContent = 'Ingen forbindelse';
      } else {
        const minutter = Math.round((Date.now() - sidsteHentning) / 60000);
        undertekst.textContent = minutter < 1
          ? 'Oplysningerne er få sekunder gamle'
          : `Oplysningerne er ${minutter} ${minutter === 1 ? 'minut' : 'minutter'} gamle`;
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* Opstart                                                            */
  /* ------------------------------------------------------------------ */

  opdaterKlokke();
  setInterval(opdaterKlokke, 1000);

  hent();
  setInterval(hent, OPDATERING_SEKUNDER * 1000);

  // Kommer skærmen frem igen efter dvale, hentes der med det samme
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) hent();
  });

  // Efter et check ud sender medarbejdersiden en til forsiden med #opdater
  if (window.location.hash === '#opdater') {
    history.replaceState(null, '', '/');
  }
}());
