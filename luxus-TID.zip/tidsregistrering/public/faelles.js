'use strict';

/**
 * public/faelles.js
 *
 * Fælles værktøj til de tre skærme. Ingen rammeværk - det skal kunne læses
 * og rettes om fem år uden at nogen først skal installere noget.
 *
 * Alt hænger på window.TR, så filerne kan bruge det uden importer.
 */

(function () {
  /* ------------------------------------------------------------------ */
  /* Kald til serveren                                                  */
  /* ------------------------------------------------------------------ */

  /**
   * Kalder API'et og giver enten indholdet tilbage eller kaster en fejl
   * med den danske besked serveren sendte.
   */
  async function kald(adresse, valg = {}) {
    const indstillinger = {
      method: valg.method || 'GET',
      headers: { Accept: 'application/json' },
      credentials: 'same-origin'
    };

    if (valg.krop !== undefined) {
      indstillinger.headers['Content-Type'] = 'application/json';
      indstillinger.body = JSON.stringify(valg.krop);
    }

    let svar;

    try {
      svar = await fetch(adresse, indstillinger);
    } catch (_netvaerksfejl) {
      const fejl = new Error(
        'Der er ingen forbindelse til systemet. Kontrollér at computeren med '
        + 'systemet er tændt, og at du er på samme netværk.'
      );
      fejl.kode = 'ingen_forbindelse';
      throw fejl;
    }

    let indhold = null;

    try {
      indhold = await svar.json();
    } catch (_ignoreret) {
      indhold = null;
    }

    if (!svar.ok || !indhold || indhold.ok === false) {
      const oplysning = indhold && indhold.fejl ? indhold.fejl : {};
      const fejl = new Error(
        oplysning.besked || 'Handlingen kunne ikke gennemføres. Prøv igen.'
      );

      fejl.kode = oplysning.kode || 'ukendt';
      fejl.status = svar.status;
      fejl.detaljer = oplysning.detaljer || null;

      throw fejl;
    }

    return indhold;
  }

  /* ------------------------------------------------------------------ */
  /* Tid og tal                                                         */
  /* ------------------------------------------------------------------ */

  function to(tal) {
    return String(Math.abs(Math.floor(tal))).padStart(2, '0');
  }

  /** Sekunder -> 'tt:mm:ss'. Samme format som serveren bruger. */
  function varighed(sekunder) {
    const samlet = Math.max(0, Math.floor(Number(sekunder) || 0));
    return `${to(samlet / 3600)}:${to((samlet % 3600) / 60)}:${to(samlet % 60)}`;
  }

  /** '2026-07-26' -> '26-07-2026' */
  function datoDansk(dato) {
    if (!dato || dato.length !== 10) return dato || '';
    return `${dato.slice(8, 10)}-${dato.slice(5, 7)}-${dato.slice(0, 4)}`;
  }

  const MAANEDER = [
    'januar', 'februar', 'marts', 'april', 'maj', 'juni',
    'juli', 'august', 'september', 'oktober', 'november', 'december'
  ];

  const UGEDAGE_KORT = ['man', 'tir', 'ons', 'tor', 'fre', 'lør', 'søn'];

  /** Dagens dato i dansk tid som 'åååå-mm-dd'. */
  function iDag() {
    const dele = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Europe/Copenhagen',
      year: 'numeric', month: '2-digit', day: '2-digit'
    }).format(new Date());

    return dele;
  }

  /** Klokkeslættet nu i dansk tid, 'tt:mm:ss'. */
  function klokkenNu() {
    return new Intl.DateTimeFormat('da-DK', {
      timeZone: 'Europe/Copenhagen',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hourCycle: 'h23'
    }).format(new Date());
  }

  function datoLang(dato) {
    if (!dato) return '';
    const [aar, maaned, dag] = dato.split('-');
    return `${Number(dag)}. ${MAANEDER[Number(maaned) - 1]} ${aar}`;
  }

  /** Lægger måneder til 'åååå-mm-dd' og lander på den 1. i måneden. */
  function flytMaaned(dato, antal) {
    const [aar, maaned] = dato.split('-').map(Number);
    const samlet = (aar * 12) + (maaned - 1) + antal;

    return `${Math.floor(samlet / 12)}-${to((samlet % 12) + 1)}-01`;
  }

  /* ------------------------------------------------------------------ */
  /* Skærmen                                                            */
  /* ------------------------------------------------------------------ */

  function find(vaelger, rod = document) {
    return rod.querySelector(vaelger);
  }

  function findAlle(vaelger, rod = document) {
    return Array.from(rod.querySelectorAll(vaelger));
  }

  /**
   * Laver et element. Tekst sættes altid som tekst, aldrig som HTML, så et
   * medarbejdernavn med specialtegn ikke kan ændre siden.
   */
  function lav(navn, egenskaber = {}, boern = []) {
    const element = document.createElement(navn);

    for (const [noegle, vaerdi] of Object.entries(egenskaber)) {
      if (vaerdi === null || vaerdi === undefined || vaerdi === false) continue;

      if (noegle === 'klasse') {
        element.className = vaerdi;
      } else if (noegle === 'tekst') {
        element.textContent = String(vaerdi);
      } else if (noegle.startsWith('paa')) {
        element.addEventListener(noegle.slice(3).toLowerCase(), vaerdi);
      } else if (noegle.startsWith('data')) {
        element.setAttribute(noegle.replace(/([A-Z])/g, '-$1').toLowerCase(), vaerdi);
      } else {
        element.setAttribute(noegle, vaerdi === true ? '' : String(vaerdi));
      }
    }

    for (const barn of [].concat(boern)) {
      if (barn === null || barn === undefined || barn === false) continue;
      element.append(typeof barn === 'string' ? document.createTextNode(barn) : barn);
    }

    return element;
  }

  function toem(element) {
    if (element) element.replaceChildren();
    return element;
  }

  /**
   * Fylder et element med nyt indhold.
   *
   * Bruges frem for element.replaceChildren(), fordi den indbyggede skriver
   * teksten "null" på skærmen når et af argumenterne er null. Det sker hver
   * gang et kort kun skal vises på en betingelse:
   *
   *   fyld(indhold, kortEt, harNoget ? kortTo : null, kortTre)
   */
  function fyld(element, ...boern) {
    if (!element) return element;

    element.replaceChildren(
      ...boern.filter((b) => b !== null && b !== undefined && b !== false)
    );

    return element;
  }

  /** Viser en besked i et område. Forsvinder af sig selv, hvis der er sat tid på. */
  function vis(omraade, tekst, slags = 'neutral', sekunder = 0) {
    if (!omraade) return;

    omraade.className = `besked besked-${slags}`;
    omraade.textContent = tekst;
    omraade.hidden = false;

    if (omraade._skjul) clearTimeout(omraade._skjul);

    if (sekunder > 0) {
      omraade._skjul = setTimeout(() => { omraade.hidden = true; }, sekunder * 1000);
    }
  }

  function skjul(omraade) {
    if (!omraade) return;
    if (omraade._skjul) clearTimeout(omraade._skjul);
    omraade.hidden = true;
  }

  /* ------------------------------------------------------------------ */
  /* Bekræftelse                                                        */
  /* ------------------------------------------------------------------ */

  /**
   * Spørger om noget skal gennemføres. Giver et løfte der ender i true
   * eller false. Bruges frem for browserens egen dialog, så teksten er
   * dansk og knapperne er store nok til en tablet.
   */
  function spoerg({ titel, tekst, bekraeft = 'Ja, fortsæt', fare = false, kraevBegrundelse = false }) {
    return new Promise((klar) => {
      const felt = kraevBegrundelse
        ? lav('div', { klasse: 'felt' }, [
            lav('label', { for: 'spoerg-begrundelse', tekst: 'Begrundelse' }),
            lav('input', {
              type: 'text',
              id: 'spoerg-begrundelse',
              placeholder: 'Skriv hvorfor - det gemmes i ændringsloggen',
              maxlength: '200'
            })
          ])
        : null;

      const luk = (svar) => {
        document.removeEventListener('keydown', vedTast);
        bund.remove();
        klar(svar);
      };

      const bekraeftKnap = lav('button', {
        klasse: `knap ${fare ? 'knap-fare' : 'knap-messing'}`,
        tekst: bekraeft,
        paaClick: () => {
          const begrundelse = felt ? find('#spoerg-begrundelse', felt).value.trim() : '';

          if (kraevBegrundelse && begrundelse.length < 3) {
            find('#spoerg-begrundelse', felt).focus();
            return;
          }

          luk(kraevBegrundelse ? begrundelse : true);
        }
      });

      const vindue = lav('div', { klasse: 'vindue', role: 'dialog', 'aria-modal': 'true' }, [
        lav('h2', { tekst: titel }),
        tekst ? lav('p', { klasse: 'vindue-under', tekst }) : null,
        felt,
        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: () => luk(false) }),
          bekraeftKnap
        ])
      ]);

      const bund = lav('div', {
        klasse: 'vinduebund',
        paaClick: (haendelse) => { if (haendelse.target === bund) luk(false); }
      }, [vindue]);

      function vedTast(haendelse) {
        if (haendelse.key === 'Escape') luk(false);
      }

      document.addEventListener('keydown', vedTast);
      document.body.append(bund);

      (felt ? find('#spoerg-begrundelse', felt) : bekraeftKnap).focus();
    });
  }

  /** Åbner et vindue med vilkårligt indhold. Giver en funktion der lukker det. */
  function aabnVindue(indhold) {
    const luk = () => {
      document.removeEventListener('keydown', vedTast);
      bund.remove();
    };

    function vedTast(haendelse) {
      if (haendelse.key === 'Escape') luk();
    }

    const vindue = lav('div', { klasse: 'vindue', role: 'dialog', 'aria-modal': 'true' },
      typeof indhold === 'function' ? indhold(luk) : indhold);

    const bund = lav('div', {
      klasse: 'vinduebund',
      paaClick: (haendelse) => { if (haendelse.target === bund) luk(); }
    }, [vindue]);

    document.addEventListener('keydown', vedTast);
    document.body.append(bund);

    const foersteFelt = vindue.querySelector('input, select, textarea, button');
    if (foersteFelt) foersteFelt.focus();

    return luk;
  }

  window.TR = {
    kald,
    varighed,
    datoDansk,
    datoLang,
    iDag,
    klokkenNu,
    flytMaaned,
    MAANEDER,
    UGEDAGE_KORT,
    find,
    findAlle,
    lav,
    toem,
    fyld,
    vis,
    skjul,
    spoerg,
    aabnVindue
  };
}());
