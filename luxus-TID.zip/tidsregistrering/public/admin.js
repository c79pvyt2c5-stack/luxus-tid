'use strict';

/**
 * public/admin.js
 *
 * Adminpanelet. Én fane ad gangen, hver med sin egen tegnefunktion.
 *
 * Panelet henter selv sine oplysninger igen efter hver ændring, frem for at
 * rette i det der står på skærmen. Det er en anelse langsommere, men det man
 * ser er så altid det der faktisk står i databasen - og der er ét sted at
 * lave fejl i stedet for to.
 */

(function () {
  const {
    kald, lav, toem, fyld, find, findAlle, vis, skjul, spoerg, aabnVindue,
    datoDansk, datoLang, iDag, flytMaaned, MAANEDER
  } = window.TR;

  const indhold = find('#indhold');
  const beskedomraade = find('#besked');

  let administrator = null;
  let aktivFane = 'overblik';
  let overblikstikker = null;

  // Periodevalg der huskes mellem faner
  const periode = {
    type: 'maaned',
    dato: iDag(),
    fra: `${iDag().slice(0, 7)}-01`,
    til: iDag()
  };

  /* ================================================================== */
  /* Fælles                                                             */
  /* ================================================================== */

  function periodeParametre(ekstra = {}) {
    const dele = new URLSearchParams({ type: periode.type });

    if (periode.type === 'periode') {
      dele.set('fra', periode.fra);
      dele.set('til', periode.til);
    } else {
      dele.set('dato', periode.dato);
    }

    for (const [noegle, vaerdi] of Object.entries(ekstra)) {
      if (vaerdi !== null && vaerdi !== undefined && vaerdi !== '') {
        dele.set(noegle, vaerdi);
      }
    }

    return dele.toString();
  }

  /** Vælgeren til periode, som flere faner deler. */
  function periodevaelger(vedAendring) {
    const typefelt = lav('select', { id: 'p-type' }, [
      lav('option', { value: 'dag', tekst: 'Én dag' }),
      lav('option', { value: 'uge', tekst: 'Uge' }),
      lav('option', { value: 'maaned', tekst: 'Måned' }),
      lav('option', { value: 'aar', tekst: 'År' }),
      lav('option', { value: 'periode', tekst: 'Valgfri periode' })
    ]);

    typefelt.value = periode.type;

    const datofelt = lav('input', { type: 'date', id: 'p-dato', value: periode.dato });
    const frafelt = lav('input', { type: 'date', id: 'p-fra', value: periode.fra });
    const tilfelt = lav('input', { type: 'date', id: 'p-til', value: periode.til });

    const datoboks = lav('div', { klasse: 'felt' }, [
      lav('label', { for: 'p-dato', tekst: 'Dato i perioden' }), datofelt
    ]);
    const fraboks = lav('div', { klasse: 'felt' }, [
      lav('label', { for: 'p-fra', tekst: 'Fra' }), frafelt
    ]);
    const tilboks = lav('div', { klasse: 'felt' }, [
      lav('label', { for: 'p-til', tekst: 'Til' }), tilfelt
    ]);

    function opdaterSynlighed() {
      const valgfri = typefelt.value === 'periode';
      datoboks.classList.toggle('skjult', valgfri);
      fraboks.classList.toggle('skjult', !valgfri);
      tilboks.classList.toggle('skjult', !valgfri);
    }

    function gem() {
      periode.type = typefelt.value;
      periode.dato = datofelt.value || iDag();
      periode.fra = frafelt.value;
      periode.til = tilfelt.value;
      opdaterSynlighed();
      vedAendring();
    }

    for (const felt of [typefelt, datofelt, frafelt, tilfelt]) {
      felt.addEventListener('change', gem);
    }

    opdaterSynlighed();

    return lav('div', { klasse: 'felt-raekke' }, [
      lav('div', { klasse: 'felt' }, [
        lav('label', { for: 'p-type', tekst: 'Periode' }), typefelt
      ]),
      datoboks, fraboks, tilboks
    ]);
  }

  function henterBesked() {
    return lav('div', { klasse: 'henter', tekst: 'Henter …' });
  }

  function tabel(overskrifter, raekker, fod = null) {
    return lav('div', { klasse: 'tabelramme' }, [
      lav('table', {}, [
        lav('thead', {}, [
          lav('tr', {}, overskrifter.map((o) =>
            lav('th', { klasse: o.justering || '', tekst: o.tekst })))
        ]),
        lav('tbody', {}, raekker),
        fod ? lav('tfoot', {}, [fod]) : null
      ])
    ]);
  }

  /* ================================================================== */
  /* Overblik                                                           */
  /* ================================================================== */

  async function faneOverblik() {
    fyld(indhold, henterBesked());

    const svar = await kald('/api/admin/overblik');
    const o = svar.overblik;

    const paaArbejde = o.paaArbejdeNu.length === 0
      ? lav('p', { klasse: 'daempet', tekst: 'Der er ingen på arbejde lige nu.' })
      : tabel(
          [{ tekst: 'Medarbejder' }, { tekst: 'Checket ind' },
           { tekst: 'Arbejdet', justering: 'h' }],
          o.paaArbejdeNu.map((p) => lav('tr', {}, [
            lav('td', {}, [lav('strong', { tekst: p.navn })]),
            lav('td', { klasse: 'tal', tekst: p.checkInd }),
            lav('td', { klasse: 'tal h', tekst: p.varighedIndtilNu })
          ]))
        );

    const noegletal = [
      { etiket: 'På arbejde nu', vaerdi: String(o.antalPaaArbejde), under: o.loebendeVarighed + ' løbende' },
      { etiket: 'Timer i dag', vaerdi: o.iDag.varighed, under: `${o.iDag.antalMedarbejdere} medarbejdere` },
      { etiket: `Uge ${o.ugenummer}`, vaerdi: o.denneUge.varighed, under: `${datoDansk(o.denneUge.fra)} – ${datoDansk(o.denneUge.til)}` },
      { etiket: 'Denne måned', vaerdi: o.denneMaaned.varighed, under: o.mad ? `mad: ${o.mad.pris}` : '' }
    ];

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: `${o.ugedag} den ${o.datoLang}` }),
          lav('span', { klasse: 'tal daempet', tekst: o.klokkeslaet })
        ]),
        lav('div', { klasse: 'noegletal' }, noegletal.map((n) =>
          lav('div', { klasse: 'noegletal-felt' }, [
            lav('div', { klasse: 'noegletal-etiket', tekst: n.etiket }),
            lav('div', { klasse: 'noegletal-vaerdi', tekst: n.vaerdi }),
            lav('div', { klasse: 'noegletal-under', tekst: n.under })
          ])))
      ]),

      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Checket ind lige nu' })
        ]),
        paaArbejde
      ]),

      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Systemets tilstand' })
        ]),
        lav('p', { klasse: 'lille daempet',
          tekst: `Automatisk check ud kl. ${svar.planlaegger.lukketid}. `
            + `Næste backup ${svar.planlaegger.naesteBackupDansk || 'ukendt'}. `
            + (svar.senesteBackup
              ? `Seneste backup ${svar.senesteBackup.datoDansk} kl. ${svar.senesteBackup.klokkeslaet}.`
              : 'Der er endnu ingen backup.') }),
        lav('div', { klasse: 'knap-rulle' }, [
          lav('button', {
            klasse: 'knap knap-fin', tekst: 'Kør automatisk check ud nu',
            paaClick: koerAutomatiskCheckUd
          })
        ])
      ])
    );
  }

  async function koerAutomatiskCheckUd() {
    const ja = await spoerg({
      titel: 'Kør automatisk check ud nu?',
      tekst: 'Alle der stadig er checket ind fra en dag hvor lukketiden er passeret, bliver afsluttet.',
      bekraeft: 'Ja, kør nu'
    });

    if (!ja) return;

    try {
      const svar = await kald('/api/admin/koer-automatisk-check-ud', { method: 'POST' });
      vis(beskedomraade, svar.besked, 'god', 8);
      tegnFane();
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 8);
    }
  }

  /* ================================================================== */
  /* Timer                                                              */
  /* ================================================================== */

  let timerMedarbejderId = '';
  let sidsteMedarbejdernavn = null;

  async function faneTimer() {
    fyld(indhold, henterBesked());

    const medarbejdersvar = await kald('/api/admin/medarbejdere');

    const vaelger = lav('select', { id: 't-medarbejder' }, [
      lav('option', { value: '', tekst: 'Alle medarbejdere' }),
      ...medarbejdersvar.medarbejdere.map((m) =>
        lav('option', { value: String(m.id), tekst: m.navn + (m.aktiv ? '' : ' (inaktiv)') }))
    ]);

    vaelger.value = timerMedarbejderId;
    vaelger.addEventListener('change', () => {
      timerMedarbejderId = vaelger.value;

      const valgt = medarbejdersvar.medarbejdere.find((m) => String(m.id) === vaelger.value);
      sidsteMedarbejdernavn = valgt ? valgt.navn : null;

      hentTimer();
    });

    const alleredeValgt = medarbejdersvar.medarbejdere
      .find((m) => String(m.id) === timerMedarbejderId);
    sidsteMedarbejdernavn = alleredeValgt ? alleredeValgt.navn : null;

    const resultat = lav('div', { id: 't-resultat' }, [henterBesked()]);

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Vis timer' }),
          lav('button', {
            klasse: 'knap knap-fin knap-messing', tekst: 'Tilføj registrering',
            paaClick: () => opretRegistrering(medarbejdersvar.medarbejdere)
          })
        ]),
        periodevaelger(hentTimer),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 't-medarbejder', tekst: 'Medarbejder' }), vaelger
        ])
      ]),
      resultat
    );

    hentTimer();
  }

  async function hentTimer() {
    const omraade = find('#t-resultat');
    if (!omraade) return;

    fyld(omraade, henterBesked());

    try {
      const svar = await kald(
        `/api/admin/registreringer?${periodeParametre({ medarbejderId: timerMedarbejderId })}`
      );

      fyld(omraade, timerMedarbejderId
        ? tegnEnMedarbejdersTimer(svar)
        : tegnAlleDage(svar));
    } catch (fejl) {
      fyld(omraade, lav('div', { klasse: 'besked besked-fejl', tekst: fejl.message }));
    }
  }

  function tegnEnMedarbejdersTimer(svar) {
    if (svar.registreringer.length === 0) {
      return lav('div', { klasse: 'kort' }, [
        lav('p', { klasse: 'tom-besked', tekst: 'Ingen registreringer i perioden.' })
      ]);
    }

    const raekker = svar.registreringer.map((r) => lav('tr', {}, [
      lav('td', { klasse: 'tal', tekst: r.datoDansk }),
      lav('td', { klasse: 'daempet lille', tekst: r.ugedag }),
      lav('td', { klasse: 'tal', tekst: r.checkInd }),
      lav('td', { klasse: 'tal', tekst: r.checkUd || '—' }),
      lav('td', { klasse: 'tal h', tekst: r.varighed || 'åben' }),
      lav('td', {}, [
        r.aaben ? lav('span', { klasse: 'maerke maerke-groen', tekst: 'på arbejde' }) : null,
        r.kommentar ? lav('span', { klasse: 'lille daempet', tekst: ' ' + r.kommentar }) : null
      ]),
      lav('td', { klasse: 'h' }, [
        lav('button', {
          klasse: 'knap knap-fin', tekst: 'Ret',
          paaClick: () => retRegistrering(r.id)
        })
      ])
    ]));

    const fod = lav('tr', {}, [
      lav('td', { colspan: '4', tekst: `${svar.periode.etiket} · ${svar.total.dage} dage` }),
      lav('td', { klasse: 'tal h', tekst: window.TR.varighed(svar.total.sekunder) }),
      lav('td', { colspan: '2' })
    ]);

    const medarbejder = svar.registreringer.length > 0
      ? sidsteMedarbejdernavn
      : null;

    return lav('div', { klasse: 'kort' }, [
      medarbejder
        ? lav('div', { klasse: 'kort-hoved' }, [
            lav('span', { klasse: 'kort-titel', tekst: medarbejder }),
            lav('span', { klasse: 'daempet lille', tekst: svar.periode.etiket })
          ])
        : null,
      tabel(
        [{ tekst: 'Dato' }, { tekst: '' }, { tekst: 'Ind' }, { tekst: 'Ud' },
         { tekst: 'Timer', justering: 'h' }, { tekst: '' }, { tekst: '' }],
        raekker, fod
      )
    ]);
  }

  function tegnAlleDage(svar) {
    if (svar.dage.length === 0) {
      return lav('div', { klasse: 'kort' }, [
        lav('p', { klasse: 'tom-besked', tekst: 'Ingen registreringer i perioden.' })
      ]);
    }

    return lav('div', {}, svar.dage.slice().reverse().map((dag) =>
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: `${dag.ugedag} ${dag.datoDansk}` }),
          lav('span', { klasse: 'tal', tekst: dag.varighed })
        ]),
        tabel(
          [{ tekst: 'Medarbejder' }, { tekst: 'Ind' }, { tekst: 'Ud' },
           { tekst: 'Timer', justering: 'h' }, { tekst: '' }, { tekst: '' }],
          dag.registreringer.map((r) => lav('tr', {}, [
            lav('td', { tekst: r.navn }),
            lav('td', { klasse: 'tal', tekst: r.checkInd }),
            lav('td', { klasse: 'tal', tekst: r.checkUd || '—' }),
            lav('td', { klasse: 'tal h', tekst: r.varighed || 'åben' }),
            lav('td', {}, [
              r.aaben ? lav('span', { klasse: 'maerke maerke-groen', tekst: 'på arbejde' }) : null,
              r.madPris ? lav('span', { klasse: 'maerke maerke-blaa', tekst: 'mad ' + r.madPris }) : null
            ]),
            lav('td', { klasse: 'h' }, [
              lav('button', {
                klasse: 'knap knap-fin', tekst: 'Ret',
                paaClick: () => retRegistrering(r.id)
              })
            ])
          ]))
        )
      ])
    ));
  }

  async function retRegistrering(id) {
    const svar = await kald(`/api/admin/registreringer/${id}`);
    const r = svar.registrering;

    aabnVindue((luk) => {
      const datofelt = lav('input', { type: 'date', id: 'r-dato', value: r.dato });
      const indfelt = lav('input', { type: 'time', id: 'r-ind', value: r.checkInd });
      const udfelt = lav('input', { type: 'time', id: 'r-ud', value: r.checkUd || '' });
      const kommentarfelt = lav('input', {
        type: 'text', id: 'r-kommentar', maxlength: '300', value: r.kommentar || ''
      });
      const begrundelsefelt = lav('input', {
        type: 'text', id: 'r-begrundelse', maxlength: '200',
        placeholder: 'Hvorfor rettes den? Gemmes i ændringsloggen'
      });

      const gem = async () => {
        try {
          await kald(`/api/admin/registreringer/${id}`, {
            method: 'PUT',
            krop: {
              dato: datofelt.value,
              checkInd: indfelt.value,
              checkUd: udfelt.value || null,
              kommentar: kommentarfelt.value,
              begrundelse: begrundelsefelt.value
            }
          });

          luk();
          vis(beskedomraade, 'Registreringen er rettet.', 'god', 5);
          hentTimer();
        } catch (fejl) {
          vis(find('#r-besked'), fejl.message, 'fejl');
        }
      };

      const slet = async () => {
        const begrundelse = await spoerg({
          titel: 'Slet registreringen?',
          tekst: `${r.datoDansk} ${r.checkInd}–${r.checkUd || 'åben'}. `
            + 'Registreringen gemmes i ændringsloggen, så timerne kan genskabes.',
          bekraeft: 'Slet',
          fare: true,
          kraevBegrundelse: true
        });

        if (!begrundelse) return;

        try {
          await kald(`/api/admin/registreringer/${id}`, {
            method: 'DELETE', krop: { begrundelse }
          });

          luk();
          vis(beskedomraade, 'Registreringen er slettet.', 'god', 5);
          hentTimer();
        } catch (fejl) {
          vis(find('#r-besked'), fejl.message, 'fejl');
        }
      };

      return [
        lav('h2', { tekst: 'Ret registrering' }),
        lav('p', { klasse: 'vindue-under', tekst: `${r.ugedag} den ${datoLang(r.dato)}` }),
        lav('div', { klasse: 'besked', id: 'r-besked', hidden: true }),

        lav('div', { klasse: 'felt' }, [lav('label', { for: 'r-dato', tekst: 'Dato' }), datofelt]),
        lav('div', { klasse: 'felt-raekke' }, [
          lav('div', { klasse: 'felt' }, [lav('label', { for: 'r-ind', tekst: 'Check ind' }), indfelt]),
          lav('div', { klasse: 'felt' }, [lav('label', { for: 'r-ud', tekst: 'Check ud' }), udfelt])
        ]),
        lav('div', { klasse: 'hjaelpetekst',
          tekst: 'Lad Check ud stå tom, hvis medarbejderen stadig er på arbejde. '
            + 'Slutter vagten efter midnat, lægges sluttiden automatisk på dagen efter.' }),
        lav('div', { klasse: 'felt mt' }, [
          lav('label', { for: 'r-kommentar', tekst: 'Kommentar' }), kommentarfelt
        ]),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'r-begrundelse', tekst: 'Begrundelse' }), begrundelsefelt
        ]),


        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap knap-fare', tekst: 'Slet', paaClick: slet }),
          lav('span', { klasse: 'mellemrum' }),
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: luk }),
          lav('button', { klasse: 'knap knap-messing', tekst: 'Gem', paaClick: gem })
        ])
      ];
    });
  }

  function opretRegistrering(medarbejdere) {
    aabnVindue((luk) => {
      const vaelger = lav('select', { id: 'n-medarbejder' },
        medarbejdere.filter((m) => m.aktiv).map((m) =>
          lav('option', { value: String(m.id), tekst: m.navn })));

      const datofelt = lav('input', { type: 'date', id: 'n-dato', value: iDag() });
      const indfelt = lav('input', { type: 'time', id: 'n-ind', value: '10:00' });
      const udfelt = lav('input', { type: 'time', id: 'n-ud', value: '18:00' });
      const kommentarfelt = lav('input', {
        type: 'text', id: 'n-kommentar', maxlength: '300',
        placeholder: 'F.eks. Glemte at checke ind'
      });

      const gem = async () => {
        try {
          await kald('/api/admin/registreringer', {
            method: 'POST',
            krop: {
              medarbejderId: Number(vaelger.value),
              dato: datofelt.value,
              checkInd: indfelt.value,
              checkUd: udfelt.value || null,
              kommentar: kommentarfelt.value,
              begrundelse: 'Oprettet manuelt af administrator'
            }
          });

          luk();
          vis(beskedomraade, 'Registreringen er oprettet.', 'god', 5);
          hentTimer();
        } catch (fejl) {
          vis(find('#n-besked'), fejl.message, 'fejl');
        }
      };

      return [
        lav('h2', { tekst: 'Tilføj registrering' }),
        lav('p', { klasse: 'vindue-under',
          tekst: 'Bruges når en medarbejder helt glemte at checke ind.' }),
        lav('div', { klasse: 'besked', id: 'n-besked', hidden: true }),

        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'n-medarbejder', tekst: 'Medarbejder' }), vaelger
        ]),
        lav('div', { klasse: 'felt' }, [lav('label', { for: 'n-dato', tekst: 'Dato' }), datofelt]),
        lav('div', { klasse: 'felt-raekke' }, [
          lav('div', { klasse: 'felt' }, [lav('label', { for: 'n-ind', tekst: 'Check ind' }), indfelt]),
          lav('div', { klasse: 'felt' }, [lav('label', { for: 'n-ud', tekst: 'Check ud' }), udfelt])
        ]),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'n-kommentar', tekst: 'Kommentar' }), kommentarfelt
        ]),

        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: luk }),
          lav('button', { klasse: 'knap knap-messing', tekst: 'Opret', paaClick: gem })
        ])
      ];
    });
  }

  /* ================================================================== */
  /* Medarbejdere                                                       */
  /* ================================================================== */

  async function faneMedarbejdere() {
    fyld(indhold, henterBesked());

    const svar = await kald('/api/admin/medarbejdere');

    const raekker = svar.medarbejdere.map((m) => lav('tr', {}, [
      lav('td', {}, [
        lav('strong', { tekst: m.navn }),
        m.aktiv ? null : lav('span', { klasse: 'maerke maerke-graa', tekst: 'inaktiv' })
      ]),
      lav('td', { klasse: 'tal c', tekst: String(m.sorteringsnummer) }),
      lav('td', { klasse: 'tal h', tekst: String(m.registreringer) }),
      lav('td', { klasse: 'tal h', tekst: String(m.madregistreringer) }),
      lav('td', { klasse: 'daempet lille', tekst: m.noter || '' }),
      lav('td', { klasse: 'h' }, [
        lav('div', { klasse: 'knap-rulle', style: 'justify-content: flex-end;' }, [
          lav('button', {
            klasse: 'knap knap-fin', tekst: 'Ret',
            paaClick: () => retMedarbejder(m)
          }),
          lav('button', {
            klasse: 'knap knap-fin',
            tekst: m.aktiv ? 'Deaktivér' : 'Aktivér',
            paaClick: () => skiftAktiv(m)
          }),
          m.harData ? null : lav('button', {
            klasse: 'knap knap-fin knap-fare', tekst: 'Slet',
            paaClick: () => sletMedarbejder(m)
          })
        ])
      ])
    ]));

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: `${svar.medarbejdere.length} medarbejdere` }),
          lav('button', {
            klasse: 'knap knap-fin knap-messing', tekst: 'Opret medarbejder',
            paaClick: opretMedarbejder
          })
        ]),

        svar.medarbejdere.length === 0
          ? lav('p', { klasse: 'tom-besked', tekst: 'Der er ingen medarbejdere endnu. Opret den første ovenfor.' })
          : tabel(
              [{ tekst: 'Navn' }, { tekst: 'Rækkefølge', justering: 'c' },
               { tekst: 'Vagter', justering: 'h' }, { tekst: 'Måltider', justering: 'h' },
               { tekst: 'Note' }, { tekst: '' }],
              raekker
            ),

        lav('p', { klasse: 'hjaelpetekst mt',
          tekst: 'Rækkefølgen bestemmer navnenes plads på personaleskærmen. '
            + 'Lavest tal står først. En medarbejder med registreringer kan ikke slettes '
            + '- deaktivér i stedet, så timerne bevares.' })
      ])
    );
  }

  function medarbejdervindue(medarbejder = null) {
    const erNy = medarbejder === null;

    aabnVindue((luk) => {
      const navnefelt = lav('input', {
        type: 'text', id: 'm-navn', maxlength: '60',
        value: erNy ? '' : medarbejder.navn, placeholder: 'F.eks. Mads'
      });

      const sorteringfelt = lav('input', {
        type: 'number', id: 'm-sortering', min: '0', max: '100000',
        value: erNy ? '' : String(medarbejder.sorteringsnummer),
        placeholder: 'Automatisk'
      });

      const notefelt = lav('textarea', { id: 'm-note', maxlength: '500' });
      if (!erNy && medarbejder.noter) notefelt.value = medarbejder.noter;

      const gem = async () => {
        const krop = {
          navn: navnefelt.value,
          sorteringsnummer: sorteringfelt.value === '' ? undefined : Number(sorteringfelt.value),
          noter: notefelt.value
        };

        try {
          if (erNy) {
            await kald('/api/admin/medarbejdere', { method: 'POST', krop });
          } else {
            await kald(`/api/admin/medarbejdere/${medarbejder.id}`, { method: 'PUT', krop });
          }

          luk();
          vis(beskedomraade, erNy ? 'Medarbejderen er oprettet.' : 'Medarbejderen er rettet.', 'god', 5);
          faneMedarbejdere();
        } catch (fejl) {
          vis(find('#m-besked'), fejl.message, 'fejl');
        }
      };

      return [
        lav('h2', { tekst: erNy ? 'Opret medarbejder' : 'Ret medarbejder' }),
        lav('div', { klasse: 'besked', id: 'm-besked', hidden: true }),

        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'm-navn', tekst: 'Navn' }), navnefelt,
          lav('div', { klasse: 'hjaelpetekst',
            tekst: 'Navnet står på personaleskærmen. Har I to med samme fornavn, så tilføj efternavn.' })
        ]),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'm-sortering', tekst: 'Rækkefølge på skærmen' }), sorteringfelt
        ]),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'm-note', tekst: 'Note (kun synlig her)' }), notefelt
        ]),

        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: luk }),
          lav('button', { klasse: 'knap knap-messing', tekst: erNy ? 'Opret' : 'Gem', paaClick: gem })
        ])
      ];
    });
  }

  const opretMedarbejder = () => medarbejdervindue(null);
  const retMedarbejder = (m) => medarbejdervindue(m);

  async function skiftAktiv(m) {
    const ja = await spoerg({
      titel: m.aktiv ? `Deaktivér ${m.navn}?` : `Aktivér ${m.navn}?`,
      tekst: m.aktiv
        ? 'Navnet forsvinder fra personaleskærmen. Alle timer og måltider bevares.'
        : 'Navnet kommer tilbage på personaleskærmen.',
      bekraeft: m.aktiv ? 'Deaktivér' : 'Aktivér'
    });

    if (!ja) return;

    try {
      await kald(`/api/admin/medarbejdere/${m.id}/aktiv`, {
        method: 'POST', krop: { aktiv: !m.aktiv }
      });

      faneMedarbejdere();
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 8);
    }
  }

  async function sletMedarbejder(m) {
    const ja = await spoerg({
      titel: `Slet ${m.navn}?`,
      tekst: 'Medarbejderen har ingen registreringer, så rækken kan fjernes helt.',
      bekraeft: 'Slet',
      fare: true
    });

    if (!ja) return;

    try {
      await kald(`/api/admin/medarbejdere/${m.id}`, { method: 'DELETE' });
      vis(beskedomraade, `${m.navn} er slettet.`, 'god', 5);
      faneMedarbejdere();
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 10);
    }
  }

  /* ================================================================== */
  /* Mad                                                                */
  /* ================================================================== */

  async function faneMad() {
    fyld(indhold, henterBesked());

    const resultat = lav('div', { id: 'mad-resultat' }, [henterBesked()]);

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Madordning' })
        ]),
        periodevaelger(hentMad)
      ]),
      resultat
    );

    hentMad();
  }

  async function hentMad() {
    const omraade = find('#mad-resultat');
    if (!omraade) return;

    fyld(omraade, henterBesked());

    try {
      const svar = await kald(`/api/admin/mad?${periodeParametre()}`);

      const opgoerelse = svar.opgoerelse.length === 0
        ? lav('p', { klasse: 'tom-besked', tekst: 'Ingen måltider i perioden.' })
        : tabel(
            [{ tekst: 'Medarbejder' }, { tekst: 'Måltider', justering: 'h' },
             { tekst: 'Rabat', justering: 'h' }, { tekst: 'Beløb', justering: 'h' }],
            svar.opgoerelse.map((o) => lav('tr', {}, [
              lav('td', { tekst: o.navn }),
              lav('td', { klasse: 'tal h', tekst: String(o.antal) }),
              lav('td', { klasse: 'tal h daempet', tekst: o.rabat }),
              lav('td', { klasse: 'tal h', tekst: o.pris })
            ]))
          );

      const liste = svar.registreringer.length === 0 ? null : tabel(
        [{ tekst: 'Dato' }, { tekst: 'Medarbejder' }, { tekst: 'Kl.' },
         { tekst: 'Beløb', justering: 'h' }, { tekst: 'Betalt', justering: 'h' },
         { tekst: 'Kommentar' }, { tekst: '' }],
        svar.registreringer.map((r) => lav('tr', {}, [
          lav('td', { klasse: 'tal', tekst: r.datoDansk }),
          lav('td', { tekst: r.medarbejderNavn }),
          lav('td', { klasse: 'tal', tekst: r.klokkeslaet }),
          lav('td', { klasse: 'tal h daempet', tekst: r.normalpris }),
          lav('td', { klasse: 'tal h', tekst: r.pris }),
          lav('td', { klasse: 'lille daempet', tekst: r.kommentar || '' }),
          lav('td', { klasse: 'h' }, [
            lav('div', { klasse: 'knap-rulle', style: 'justify-content: flex-end;' }, [
              lav('button', {
                klasse: 'knap knap-fin', tekst: 'Ret',
                paaClick: () => retMad(r)
              }),
              lav('button', {
                klasse: 'knap knap-fin knap-fare', tekst: 'Fjern',
                paaClick: () => fjernMad(r)
              })
            ])
          ])
        ]))
      );

      fyld(omraade, 
        lav('div', { klasse: 'kort' }, [
          lav('div', { klasse: 'kort-hoved' }, [
            lav('span', { klasse: 'kort-titel', tekst: 'Opgørelse pr. medarbejder' }),
            lav('span', { klasse: 'daempet lille', tekst: svar.periode.etiket })
          ]),
          opgoerelse
        ]),
        liste ? lav('div', { klasse: 'kort' }, [
          lav('div', { klasse: 'kort-hoved' }, [
            lav('span', { klasse: 'kort-titel', tekst: 'Alle måltider' })
          ]),
          liste
        ]) : null
      );
    } catch (fejl) {
      fyld(omraade, lav('div', { klasse: 'besked besked-fejl', tekst: fejl.message }));
    }
  }

  /**
   * Retter et måltid. Beløbet skrives i kroner, og den nye pris regnes ud
   * mens man skriver - med den rabat måltidet oprindeligt fik.
   */
  function retMad(r) {
    aabnVindue((luk) => {
      const beloebsfelt = lav('input', {
        type: 'text', inputmode: 'decimal', id: 'rm-beloeb',
        value: (r.normalprisOere / 100).toFixed(2).replace('.', ','), maxlength: '10'
      });

      const datofelt = lav('input', { type: 'date', id: 'rm-dato', value: r.dato });
      const kommentarfelt = lav('input', {
        type: 'text', id: 'rm-kommentar', maxlength: '300', value: r.kommentar || ''
      });
      const begrundelsefelt = lav('input', {
        type: 'text', id: 'rm-begrundelse', maxlength: '200',
        placeholder: 'Hvorfor rettes den?'
      });

      const udregning = lav('div', { klasse: 'besked besked-neutral' });
      const fejlfelt = lav('div', { klasse: 'besked', hidden: true });

      const laes = () => {
        const tekstvaerdi = String(beloebsfelt.value)
          .replace(/kr\.?/gi, '').replace(/\s/g, '')
          .replace(/\./g, '').replace(',', '.').trim();

        if (!/^\d+(\.\d{1,2})?$/.test(tekstvaerdi)) return null;
        return Math.round(Number.parseFloat(tekstvaerdi) * 100);
      };

      const kroner = (oere) => {
        const hele = Math.floor(oere / 100);
        return `${String(hele).replace(/\B(?=(\d{3})+(?!\d))/g, '.')},`
          + `${String(oere % 100).padStart(2, '0')} kr.`;
      };

      const opdaterUdregning = () => {
        const oere = laes();

        if (oere === null || oere <= 0) {
          udregning.className = 'besked besked-neutral';
          udregning.textContent = 'Skriv beløbet, f.eks. 99 eller 85,50.';
          return;
        }

        const pris = Math.round((oere * (100 - r.rabatProcent)) / 100);
        udregning.className = 'besked besked-god';
        udregning.textContent = `${r.medarbejderNavn} betaler ${kroner(pris)} `
          + `(${kroner(oere)} minus ${r.rabatProcent} % rabat).`;
      };

      beloebsfelt.addEventListener('input', opdaterUdregning);
      opdaterUdregning();

      const gem = async () => {
        try {
          await kald(`/api/admin/mad/${r.id}`, {
            method: 'PUT',
            krop: {
              beloeb: beloebsfelt.value,
              dato: datofelt.value,
              kommentar: kommentarfelt.value,
              begrundelse: begrundelsefelt.value
            }
          });

          luk();
          vis(beskedomraade, 'Madregistreringen er rettet.', 'god', 5);
          hentMad();
        } catch (fejl) {
          vis(fejlfelt, fejl.message, 'fejl');
        }
      };

      beloebsfelt.addEventListener('keydown', (h) => { if (h.key === 'Enter') gem(); });

      return [
        lav('h2', { tekst: 'Ret madregistrering' }),
        lav('p', { klasse: 'vindue-under',
          tekst: `${r.medarbejderNavn} · ${r.datoDansk} kl. ${r.klokkeslaet}` }),

        fejlfelt,

        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'rm-beloeb', tekst: 'Beløb i kroner' }), beloebsfelt
        ]),
        udregning,
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'rm-dato', tekst: 'Dato' }), datofelt
        ]),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'rm-kommentar', tekst: 'Kommentar' }), kommentarfelt
        ]),
        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'rm-begrundelse', tekst: 'Begrundelse' }), begrundelsefelt
        ]),

        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap knap-fare', tekst: 'Fjern',
            paaClick: () => { luk(); fjernMad(r); } }),
          lav('span', { klasse: 'mellemrum' }),
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: luk }),
          lav('button', { klasse: 'knap knap-messing', tekst: 'Gem', paaClick: gem })
        ])
      ];
    });
  }

  async function fjernMad(r) {
    const begrundelse = await spoerg({
      titel: 'Fjern madregistreringen?',
      tekst: `${r.medarbejderNavn}, ${r.datoDansk}, ${r.pris}.`,
      bekraeft: 'Fjern',
      fare: true,
      kraevBegrundelse: true
    });

    if (!begrundelse) return;

    try {
      await kald(`/api/admin/mad/${r.id}`, { method: 'DELETE', krop: { begrundelse } });
      vis(beskedomraade, 'Madregistreringen er fjernet.', 'god', 5);
      hentMad();
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 8);
    }
  }

  /* ================================================================== */
  /* Statistik                                                          */
  /* ================================================================== */

  let statistikAar = Number(iDag().slice(0, 4));

  async function faneStatistik() {
    fyld(indhold, henterBesked());

    const [prMedarbejder, aarssvar] = await Promise.all([
      kald(`/api/admin/statistik/medarbejdere?${periodeParametre()}`),
      kald('/api/admin/statistik/aar')
    ]);

    const maanedssvar = await kald(`/api/admin/statistik/maaneder/${statistikAar}`);

    const medarbejderraekker = prMedarbejder.medarbejdere.map((m) => lav('tr', {}, [
      lav('td', {}, [
        lav('span', { tekst: m.navn }),
        m.aktiv ? null : lav('span', { klasse: 'maerke maerke-graa', tekst: 'inaktiv' })
      ]),
      lav('td', { klasse: 'tal h', tekst: m.varighed }),
      lav('td', { klasse: 'tal h daempet', tekst: m.timer }),
      lav('td', { klasse: 'tal h', tekst: String(m.antalDage) }),
      lav('td', { klasse: 'tal h daempet', tekst: m.gennemsnitPrDag }),
      lav('td', { klasse: 'tal h', tekst: String(m.madAntal) }),
      lav('td', { klasse: 'tal h', tekst: m.madPris })
    ]));

    const aarvaelger = lav('select', { id: 's-aar' },
      (aarssvar.aar.length > 0 ? aarssvar.aar.map((a) => a.aar) : [statistikAar])
        .map((a) => lav('option', { value: String(a), tekst: String(a) })));

    aarvaelger.value = String(statistikAar);
    aarvaelger.addEventListener('change', () => {
      statistikAar = Number(aarvaelger.value);
      faneStatistik();
    });

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Timer pr. medarbejder' })
        ]),
        periodevaelger(faneStatistik),
        tabel(
          [{ tekst: 'Medarbejder' }, { tekst: 'Timer', justering: 'h' },
           { tekst: 'Decimal', justering: 'h' }, { tekst: 'Dage', justering: 'h' },
           { tekst: 'Snit/dag', justering: 'h' }, { tekst: 'Måltider', justering: 'h' },
           { tekst: 'Mad', justering: 'h' }],
          medarbejderraekker
        )
      ]),

      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Timer pr. måned' }),
          aarvaelger
        ]),
        tabel(
          [{ tekst: 'Måned' }, { tekst: 'Timer', justering: 'h' },
           { tekst: 'Dage', justering: 'h' }, { tekst: 'Medarbejdere', justering: 'h' },
           { tekst: 'Måltider', justering: 'h' }, { tekst: 'Mad', justering: 'h' }],
          maanedssvar.maaneder.map((m) => lav('tr', {}, [
            lav('td', { tekst: m.navn }),
            lav('td', { klasse: 'tal h', tekst: m.varighed }),
            lav('td', { klasse: 'tal h', tekst: String(m.antalDage) }),
            lav('td', { klasse: 'tal h', tekst: String(m.antalMedarbejdere) }),
            lav('td', { klasse: 'tal h', tekst: String(m.madAntal) }),
            lav('td', { klasse: 'tal h daempet', tekst: m.madPris })
          ]))
        )
      ]),

      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Pr. år og samlet' })
        ]),
        tabel(
          [{ tekst: 'År' }, { tekst: 'Timer', justering: 'h' },
           { tekst: 'Dage', justering: 'h' }, { tekst: 'Medarbejdere', justering: 'h' }],
          aarssvar.aar.map((a) => lav('tr', {}, [
            lav('td', { klasse: 'tal', tekst: String(a.aar) }),
            lav('td', { klasse: 'tal h', tekst: a.varighed }),
            lav('td', { klasse: 'tal h', tekst: String(a.antalDage) }),
            lav('td', { klasse: 'tal h', tekst: String(a.antalMedarbejdere) })
          ])),
          lav('tr', {}, [
            lav('td', { tekst: 'Samlet' }),
            lav('td', { klasse: 'tal h', tekst: aarssvar.samlet.varighed }),
            lav('td', { klasse: 'tal h', tekst: String(aarssvar.samlet.antalDage) }),
            lav('td', { klasse: 'h daempet lille',
              tekst: aarssvar.samlet.foersteDatoDansk
                ? `fra ${aarssvar.samlet.foersteDatoDansk}` : '' })
          ])
        )
      ])
    );
  }

  /* ================================================================== */
  /* Udskrift                                                           */
  /* ================================================================== */

  async function faneUdskrift() {
    fyld(indhold, henterBesked());

    const svar = await kald('/api/admin/medarbejdere');

    const vaelger = lav('select', { id: 'u-medarbejder' }, [
      lav('option', { value: '', tekst: 'Alle medarbejdere (samlet oversigt)' }),
      ...svar.medarbejdere.map((m) =>
        lav('option', { value: String(m.id), tekst: m.navn + (m.aktiv ? '' : ' (inaktiv)') }))
    ]);

    const adresse = (hent) => {
      const ekstra = { medarbejderId: vaelger.value };
      if (hent) ekstra.hent = '1';
      return `/api/admin/pdf?${periodeParametre(ekstra)}`;
    };

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Udskriv timer' })
        ]),

        periodevaelger(() => {}),

        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'u-medarbejder', tekst: 'Hvem' }), vaelger
        ]),

        lav('div', { klasse: 'knap-rulle mt' }, [
          lav('button', {
            klasse: 'knap knap-messing', tekst: 'Vis PDF',
            paaClick: () => window.open(adresse(false), '_blank', 'noopener')
          }),
          lav('button', {
            klasse: 'knap', tekst: 'Hent PDF',
            paaClick: () => { window.location.href = adresse(true); }
          })
        ]),

        lav('p', { klasse: 'hjaelpetekst mt',
          tekst: 'Vælges en enkelt medarbejder, kommer der én linje pr. vagt med '
            + 'madregistreringer. Vælges alle, kommer der én linje pr. medarbejder med totaler.' })
      ])
    );
  }

  /* ================================================================== */
  /* Indstillinger                                                      */
  /* ================================================================== */

  async function faneIndstillinger() {
    fyld(indhold, henterBesked());

    const [svar, adminsvar] = await Promise.all([
      kald('/api/admin/indstillinger'),
      kald('/api/admin/administratorer')
    ]);

    const felter = svar.indstillinger.map((i) => {
      const felt = lav('input', {
        type: 'text', id: `i-${i.noegle}`, value: i.vaerdi,
        'data-noegle': i.noegle
      });

      return lav('div', { klasse: 'felt' }, [
        lav('label', { for: `i-${i.noegle}`, tekst: i.etiket }),
        felt,
        lav('div', { klasse: 'hjaelpetekst', tekst: i.beskrivelse })
      ]);
    });

    const gem = async () => {
      let antal = 0;

      for (const i of svar.indstillinger) {
        const felt = find(`#i-${i.noegle}`);
        if (!felt) continue;

        try {
          const resultat = await kald(`/api/admin/indstillinger/${i.noegle}`, {
            method: 'PUT', krop: { vaerdi: felt.value }
          });

          if (resultat.aendret) antal += 1;
        } catch (fejl) {
          vis(beskedomraade, fejl.message, 'fejl', 10);
          return;
        }
      }

      vis(beskedomraade, antal === 0
        ? 'Der var ingen ændringer at gemme.'
        : `${antal} ${antal === 1 ? 'indstilling' : 'indstillinger'} gemt.`, 'god', 5);

      faneIndstillinger();
    };

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Indstillinger' })
        ]),

        lav('div', { klasse: 'besked besked-neutral',
          tekst: `Medarbejderen skriver selv hvad maden kostede. Systemet trækker `
            + `${svar.madrabatProcent} % fra. Rabatprocenten er fast og ændres i koden.` }),

        ...felter,

        lav('div', { klasse: 'knap-rulle mt' }, [
          lav('button', { klasse: 'knap knap-messing', tekst: 'Gem indstillinger', paaClick: gem })
        ]),

        lav('p', { klasse: 'hjaelpetekst mt',
          tekst: 'Måltider beholder den pris de blev registreret til.' })
      ]),

      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Administrator' }),
          lav('button', { klasse: 'knap knap-fin', tekst: 'Skift adgangskode',
            paaClick: skiftKodeord })
        ]),
        lav('p', { klasse: 'hjaelpetekst',
          tekst: 'Der er kun én administrator. Systemet oprettede den ved første start '
            + 'med brugernavn "admin" og adgangskode "admin123". Skift den, hvis den '
            + 'stadig er den samme - alle på restaurantens netværk kan nå login-siden.' }),
        tabel(
          [{ tekst: 'Brugernavn' }, { tekst: 'Navn' }, { tekst: 'Seneste login' }],
          adminsvar.administratorer.map((a) => lav('tr', {}, [
            lav('td', {}, [
              lav('strong', { tekst: a.brugernavn }),
              a.aktiv ? null : lav('span', { klasse: 'maerke maerke-graa', tekst: 'inaktiv' })
            ]),
            lav('td', { tekst: a.navn }),
            lav('td', { klasse: 'daempet lille', tekst: a.sidsteLogin })
          ]))
        )
      ])
    );
  }

  function skiftKodeord() {
    aabnVindue((luk) => {
      const nuvaerende = lav('input', { type: 'password', id: 'k-nu', autocomplete: 'current-password' });
      const nyt = lav('input', { type: 'password', id: 'k-ny', autocomplete: 'new-password' });
      const gentag = lav('input', { type: 'password', id: 'k-gentag', autocomplete: 'new-password' });

      const gem = async () => {
        if (nyt.value !== gentag.value) {
          vis(find('#k-besked'), 'De to nye adgangskoder er ikke ens.', 'fejl');
          return;
        }

        try {
          await kald('/api/admin/skift-kodeord', {
            method: 'POST', krop: { nuvaerende: nuvaerende.value, nyt: nyt.value }
          });

          luk();
          administrator = null;
          visLogin('Adgangskoden er ændret. Log ind med den nye kode.');
        } catch (fejl) {
          vis(find('#k-besked'), fejl.message, 'fejl');
        }
      };

      return [
        lav('h2', { tekst: 'Skift adgangskode' }),
        lav('p', { klasse: 'vindue-under',
          tekst: 'Mindst 8 tegn. Alle åbne vinduer bliver logget ud efter skiftet.' }),
        lav('div', { klasse: 'besked', id: 'k-besked', hidden: true }),

        lav('div', { klasse: 'felt' }, [lav('label', { for: 'k-nu', tekst: 'Nuværende adgangskode' }), nuvaerende]),
        lav('div', { klasse: 'felt' }, [lav('label', { for: 'k-ny', tekst: 'Ny adgangskode' }), nyt]),
        lav('div', { klasse: 'felt' }, [lav('label', { for: 'k-gentag', tekst: 'Gentag ny adgangskode' }), gentag]),

        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: luk }),
          lav('button', { klasse: 'knap knap-messing', tekst: 'Skift', paaClick: gem })
        ])
      ];
    });
  }


  /* ================================================================== */
  /* Backup                                                             */
  /* ================================================================== */

  async function faneBackup() {
    fyld(indhold, henterBesked());

    const svar = await kald('/api/admin/backups');

    const raekker = svar.backups.map((b) => lav('tr', {}, [
      lav('td', { klasse: 'tal', tekst: `${b.datoDansk} ${b.klokkeslaet}` }),
      lav('td', {}, [
        lav('span', {
          klasse: `maerke ${b.type === 'manuel' ? 'maerke-blaa'
            : b.type === 'foer_gendannelse' ? 'maerke-messing' : 'maerke-graa'}`,
          tekst: b.type === 'foer_gendannelse' ? 'før gendannelse' : b.type
        })
      ]),
      lav('td', { klasse: 'tal h', tekst: b.stoerrelseKb === null ? '—' : `${b.stoerrelseKb} kB` }),
      lav('td', { klasse: 'h' }, [
        lav('button', {
          klasse: 'knap knap-fin', tekst: 'Gendan',
          paaClick: () => gendanBackup(b)
        })
      ])
    ]));

    fyld(indhold, 
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Backup' }),
          lav('button', {
            klasse: 'knap knap-fin knap-messing', tekst: 'Tag backup nu',
            paaClick: tagBackup
          })
        ]),

        lav('p', { klasse: 'lille daempet',
          tekst: `Automatisk backup kl. ${svar.planlaegger.backupKlokken}. `
            + `Næste: ${svar.planlaegger.naesteBackupDansk || 'ukendt'}. `
            + `De ${svar.planlaegger.antalBackupsGemmes} nyeste automatiske gemmes; `
            + 'manuelle slettes aldrig af sig selv.' }),

        svar.backups.length === 0
          ? lav('p', { klasse: 'tom-besked', tekst: 'Der er endnu ingen backups.' })
          : tabel(
              [{ tekst: 'Tidspunkt' }, { tekst: 'Type' },
               { tekst: 'Størrelse', justering: 'h' }, { tekst: '' }],
              raekker
            )
      ]),

      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Databasen' })
        ]),
        lav('p', { klasse: 'lille daempet',
          tekst: `Skemaversion ${svar.database.skemaversion} · `
            + `${Math.round((svar.database.stoerrelseBytes || 0) / 1024)} kB · `
            + `${svar.database.sti}` })
      ])
    );
  }

  async function tagBackup() {
    try {
      const svar = await kald('/api/admin/backups', { method: 'POST' });
      vis(beskedomraade, svar.besked, 'god', 8);
      faneBackup();
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 10);
    }
  }

  async function gendanBackup(b) {
    let kontrol;

    try {
      const svar = await kald(`/api/admin/backups/${b.filnavn}/kontroller`);
      kontrol = svar.kontrol;
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 10);
      return;
    }

    const ja = await spoerg({
      titel: 'Gendan denne backup?',
      tekst: `Hele databasen erstattes med indholdet fra ${b.datoDansk} kl. ${b.klokkeslaet}: `
        + `${kontrol.medarbejdere} medarbejdere og ${kontrol.registreringer} registreringer. `
        + 'Alt der er registreret siden da, forsvinder. '
        + 'Der tages automatisk en sikkerhedskopi først, så handlingen kan fortrydes.',
      bekraeft: 'Ja, gendan',
      fare: true
    });

    if (!ja) return;

    try {
      const svar = await kald(`/api/admin/backups/${b.filnavn}/gendan`, {
        method: 'POST', krop: { bekraeft: true }
      });

      fyld(indhold, 
        lav('div', { klasse: 'kort' }, [
          lav('div', { klasse: 'besked besked-advarsel', tekst: svar.besked }),
          lav('p', { klasse: 'lille daempet',
            tekst: `Sikkerhedskopi af det tidligere indhold: ${svar.sikkerhedskopi}` }),
          lav('button', {
            klasse: 'knap knap-messing mt', tekst: 'Opdatér siden',
            paaClick: () => window.location.reload()
          })
        ])
      );
    } catch (fejl) {
      vis(beskedomraade, fejl.message, 'fejl', 12);
    }
  }

  /* ================================================================== */
  /* Ændringslog                                                        */
  /*                                                                    */
  /* Det eneste sted en rettelse kan ses. Ude på registreringerne selv  */
  /* står der intet - heller ikke i fanen Timer.                        */
  /* ================================================================== */

  async function faneLog() {
    fyld(indhold, henterBesked());

    const soegefelt = lav('input', {
      type: 'search', id: 'l-soeg', placeholder: 'Søg i navne, felter og begrundelser'
    });

    const handlingsfelt = lav('select', { id: 'l-handling' }, [
      lav('option', { value: '', tekst: 'Alle handlinger' })
    ]);

    const resultat = lav('div', { id: 'l-resultat' }, [henterBesked()]);

    let ur = null;

    const hentSenere = () => {
      if (ur) clearTimeout(ur);
      ur = setTimeout(hentLog, 300);
    };

    soegefelt.addEventListener('input', hentSenere);
    handlingsfelt.addEventListener('change', hentLog);

    fyld(indhold,
      lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'kort-titel', tekst: 'Ændringslog' })
        ]),
        lav('p', { klasse: 'lille daempet',
          tekst: 'Her - og kun her - kan du se hvad der er blevet rettet. '
            + 'Ude på selve registreringerne står der intet, hverken i fanen Timer '
            + 'eller på medarbejdersiden. Loggen kan ikke redigeres eller slettes.' }),
        lav('div', { klasse: 'felt-raekke' }, [
          lav('div', { klasse: 'felt' }, [
            lav('label', { for: 'l-soeg', tekst: 'Søg' }), soegefelt
          ]),
          lav('div', { klasse: 'felt' }, [
            lav('label', { for: 'l-handling', tekst: 'Handling' }), handlingsfelt
          ])
        ])
      ]),
      resultat
    );

    await hentLog(handlingsfelt);
  }

  async function hentLog(handlingsfelt = null) {
    const omraade = find('#l-resultat');
    if (!omraade) return;

    const soeg = find('#l-soeg')?.value || '';
    const handling = find('#l-handling')?.value || '';

    try {
      const dele = new URLSearchParams({ graense: '300' });
      if (soeg) dele.set('soeg', soeg);
      if (handling) dele.set('handling', handling);

      const svar = await kald(`/api/admin/aendringslog?${dele.toString()}`);

      // Handlingslisten fyldes ud første gang
      const vaelger = handlingsfelt || find('#l-handling');

      if (vaelger && vaelger.options.length === 1) {
        for (const h of svar.handlinger) {
          vaelger.append(lav('option', { value: h, tekst: h }));
        }
      }

      fyld(omraade, lav('div', { klasse: 'kort' }, [
        lav('div', { klasse: 'kort-hoved' }, [
          lav('span', { klasse: 'daempet lille',
            tekst: `Viser ${svar.poster.length} af ${svar.antal} poster` })
        ]),

        svar.poster.length === 0
          ? lav('p', { klasse: 'tom-besked', tekst: 'Ingen poster fundet.' })
          : tabel(
              [{ tekst: 'Tidspunkt' }, { tekst: 'Hvem' }, { tekst: 'Handling' },
               { tekst: 'Felt' }, { tekst: 'Fra' }, { tekst: 'Til' }, { tekst: 'Begrundelse' }],
              svar.poster.map((p) => lav('tr', {}, [
                lav('td', { klasse: 'tal lille', tekst: `${p.dato} ${p.klokkeslaet}` }),
                lav('td', { tekst: p.administrator }),
                lav('td', {}, [lav('span', { klasse: 'maerke maerke-graa', tekst: p.handling })]),
                lav('td', { klasse: 'lille', tekst: p.felt || '' }),
                lav('td', { klasse: 'lille daempet', tekst: p.foer || '' }),
                lav('td', { klasse: 'lille', tekst: p.efter || '' }),
                lav('td', { klasse: 'lille daempet', tekst: p.begrundelse || '' })
              ]))
            )
      ]));
    } catch (fejl) {
      fyld(omraade, lav('div', { klasse: 'besked besked-fejl', tekst: fejl.message }));
    }
  }

  const FANER = {
    overblik: faneOverblik,
    timer: faneTimer,
    medarbejdere: faneMedarbejdere,
    mad: faneMad,
    statistik: faneStatistik,
    udskrift: faneUdskrift,
    indstillinger: faneIndstillinger,
    backup: faneBackup,
    log: faneLog
  };

  async function tegnFane() {
    if (overblikstikker) {
      clearInterval(overblikstikker);
      overblikstikker = null;
    }

    for (const knap of findAlle('.fane')) {
      knap.classList.toggle('valgt', knap.dataset.fane === aktivFane);
    }

    try {
      await FANER[aktivFane]();
    } catch (fejl) {
      if (fejl.status === 401) {
        visLogin('Du er blevet logget ud. Log ind igen.');
        return;
      }

      fyld(indhold, lav('div', { klasse: 'besked besked-fejl', tekst: fejl.message }));
    }

    // Overblikket holder sig selv frisk, så skærmen kan stå åben
    if (aktivFane === 'overblik') {
      overblikstikker = setInterval(() => {
        if (aktivFane === 'overblik' && !document.hidden) {
          faneOverblik().catch(() => {});
        }
      }, 30000);
    }
  }

  function visPanel() {
    find('#loginside').hidden = true;
    find('#panel').hidden = false;
    find('#admin-byline').textContent = `Logget ind som ${administrator.navn}`;
    tegnFane();
  }

  function visLogin(besked = null) {
    find('#panel').hidden = true;
    find('#loginside').hidden = false;

    if (besked) vis(find('#login-besked'), besked, 'advarsel');
    else skjul(find('#login-besked'));

    find('#brugernavn').focus();
  }

  async function logInd() {
    const knap = find('#login-knap');
    knap.disabled = true;

    try {
      const svar = await kald('/api/admin/login', {
        method: 'POST',
        krop: {
          brugernavn: find('#brugernavn').value,
          kodeord: find('#kodeord').value
        }
      });

      administrator = svar.administrator;
      find('#kodeord').value = '';
      skjul(find('#login-besked'));
      visPanel();
    } catch (fejl) {
      vis(find('#login-besked'), fejl.message, 'fejl');
      find('#kodeord').select();
    } finally {
      knap.disabled = false;
    }
  }

  async function logUd() {
    try {
      await kald('/api/admin/log-ud', { method: 'POST' });
    } catch (_ignoreret) {
      // Lykkes det ikke, er sessionen alligevel væk for brugeren
    }

    administrator = null;
    visLogin('Du er logget ud.');
  }

  async function start() {
    for (const knap of findAlle('.fane')) {
      knap.addEventListener('click', () => {
        aktivFane = knap.dataset.fane;
        tegnFane();
      });
    }

    find('#login-knap').addEventListener('click', logInd);
    find('#log-ud').addEventListener('click', logUd);

    for (const felt of [find('#brugernavn'), find('#kodeord')]) {
      felt.addEventListener('keydown', (haendelse) => {
        if (haendelse.key === 'Enter') logInd();
      });
    }

    try {
      const svar = await kald('/api/admin/tilstand');

      if (svar.loggetInd) {
        administrator = svar.administrator;
        visPanel();
        return;
      }

      visLogin(svar.antalAdministratorer === 0
        ? 'Administratoren oprettes automatisk første gang systemet startes. '
          + 'Genstart systemet, og log ind med admin / admin123.'
        : null);
    } catch (fejl) {
      visLogin(fejl.message);
    }
  }

  start();
}());
