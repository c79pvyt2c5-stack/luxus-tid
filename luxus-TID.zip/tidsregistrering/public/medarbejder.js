'use strict';

/**
 * public/medarbejder.js
 *
 * Medarbejderens egen side.
 *
 * Uret tæller op i browseren, men bygger på serverens tidspunkt for check ind.
 * Tabletten kan have et ur der går forkert - serverens tid er den der gælder,
 * og den er også den der bliver gemt.
 */

(function () {
  const {
    kald, lav, toem, find, vis, skjul, spoerg, aabnVindue,
    varighed, datoDansk, datoLang, iDag, flytMaaned, MAANEDER, UGEDAGE_KORT
  } = window.TR;

  const medarbejderId = Number.parseInt(window.location.pathname.split('/').pop(), 10);

  const OPDATERING_SEKUNDER = 60;

  let tilstand = null;
  let tikker = null;

  /**
   * Nøgletallene som de var ved sidste hentning, uden den løbende vagt.
   * Uret tæller hvert sekund, mens tallene kun hentes hvert minut - uden dette
   * ville "I dag" stå stille mens timeren ovenfor talte, og de to ville vise
   * forskelligt. Her lægges den løbende tid til begge steder samtidig.
   */
  let grundtal = null;
  let kalendermaaned = `${iDag().slice(0, 7)}-01`;
  let valgtDag = null;
  let sekunderFoerRetur = 5;

  const el = {
    navn: find('#navn'),
    dagsdato: find('#dagsdato'),
    besked: find('#besked'),
    ur: find('#ur'),
    urEtiket: find('#ur-etiket'),
    urUnder: find('#ur-under'),
    knapInd: find('#knap-ind'),
    knapUd: find('#knap-ud'),
    knapMad: find('#knap-mad'),
    madpris: find('#madpris'),
    madMaaned: find('#mad-maaned'),
    noegletal: find('#noegletal'),
    kalender: find('#kalender'),
    kalenderUgedage: find('#kalender-ugedage'),
    maanedNavn: find('#maaned-navn'),
    maanedTotal: find('#maaned-total'),
    dagsdetalje: find('#dagsdetalje')
  };

  /* ------------------------------------------------------------------ */
  /* Uret                                                               */
  /* ------------------------------------------------------------------ */

  function startUr() {
    stopUr();
    tikker = setInterval(tegnUr, 1000);
    tegnUr();
  }

  function stopUr() {
    if (tikker !== null) {
      clearInterval(tikker);
      tikker = null;
    }
  }

  function tegnUr() {
    if (!tilstand) return;

    // Nøgletallene følger med sekund for sekund, så "I dag" og den store
    // timer aldrig viser to forskellige tal.
    if (tilstand.erCheketInd) {
      const startet = new Date(tilstand.aktivRegistrering.checkIndTid).getTime();
      tegnNoegletal(Math.max(0, Math.round((Date.now() - startet) / 1000)));
    }

    if (!tilstand.erCheketInd) {
      el.ur.textContent = tilstand.oversigt.iDag.varighed;
      el.ur.classList.add('ur-hvile');
      el.urEtiket.textContent = 'Arbejdet tid i dag';
      el.urUnder.textContent = tilstand.oversigt.iDag.sekunder > 0
        ? 'Du er checket ud for i dag'
        : 'Ikke checket ind';
      return;
    }

    const start = new Date(tilstand.aktivRegistrering.checkIndTid).getTime();
    const gaaet = Math.max(0, Math.round((Date.now() - start) / 1000));

    el.ur.textContent = varighed(gaaet);
    el.ur.classList.remove('ur-hvile');
    el.urEtiket.textContent = 'Arbejdet tid';
    el.urUnder.textContent = `Checket ind kl. ${tilstand.aktivRegistrering.checkInd}`;
  }

  /* ------------------------------------------------------------------ */
  /* Tegning                                                            */
  /* ------------------------------------------------------------------ */

  /**
   * Tegner de fem tal.
   *
   * @param {number} [loebendeNu] Sekunder på den åbne vagt lige nu. Serverens
   *        tal indeholder allerede den løbende tid som den var ved hentningen,
   *        så forskellen lægges til - ellers ville tallene stå stille i op til
   *        et minut, mens den store timer talte videre.
   */
  function tegnNoegletal(loebendeNu = null) {
    const o = tilstand.oversigt;

    const forskel = loebendeNu === null
      ? 0
      : Math.max(0, loebendeNu - (o.loebendeSekunder || 0));

    const med = (felt) => window.TR.varighed(felt.sekunder + forskel);

    const felter = [
      { etiket: 'I dag', vaerdi: med(o.iDag),
        under: `${((o.iDag.sekunder + forskel) / 3600).toFixed(2).replace('.', ',')} timer` },
      { etiket: `Uge ${o.ugenummer}`, vaerdi: med(o.denneUge), under: `${o.denneUge.antalDage} dage` },
      { etiket: 'Denne måned', vaerdi: med(o.denneMaaned), under: `${o.denneMaaned.antalDage} dage` },
      { etiket: 'I år', vaerdi: med(o.detteAar), under: `${o.detteAar.antalDage} dage` },
      { etiket: 'Samlet', vaerdi: med(o.samlet), under: `${o.samlet.antalDage} dage i alt` }
    ];

    toem(el.noegletal);

    for (const felt of felter) {
      el.noegletal.append(lav('div', { klasse: 'noegletal-felt' }, [
        lav('div', { klasse: 'noegletal-etiket', tekst: felt.etiket }),
        lav('div', { klasse: 'noegletal-vaerdi', tekst: felt.vaerdi }),
        lav('div', { klasse: 'noegletal-under', tekst: felt.under })
      ]));
    }
  }

  function tegnKnapper() {
    el.knapInd.classList.toggle('skjult', tilstand.erCheketInd);
    el.knapUd.classList.toggle('skjult', !tilstand.erCheketInd);

    const harSpist = tilstand.mad.harSpistIDag;

    el.knapMad.disabled = harSpist;
    el.knapMad.textContent = harSpist
      ? `Registreret i dag · ${tilstand.mad.iDag.pris}`
      : 'Jeg har spist';

    el.madpris.textContent = harSpist
      ? ''
      : `Du får ${tilstand.mad.rabatProcent} % rabat på det du skriver`;

    const maaned = tilstand.mad.denneMaaned;

    el.madMaaned.textContent = maaned.antal === 0
      ? 'Ingen måltider registreret denne måned.'
      : `Denne måned: ${maaned.antal} `
        + `${maaned.antal === 1 ? 'måltid' : 'måltider'} til ${maaned.pris} `
        + `(du har sparet ${maaned.rabat})`;
  }

  /* ------------------------------------------------------------------ */
  /* Kalender                                                           */
  /* ------------------------------------------------------------------ */

  function tegnUgedage() {
    toem(el.kalenderUgedage);

    for (const dag of UGEDAGE_KORT) {
      el.kalenderUgedage.append(lav('div', { klasse: 'kalender-ugedag', tekst: dag }));
    }
  }

  async function hentKalender() {
    const [aar, maaned] = kalendermaaned.split('-').map(Number);

    el.maanedNavn.textContent = `${MAANEDER[maaned - 1]} ${aar}`;

    try {
      const svar = await kald(
        `/api/medarbejder/${medarbejderId}/kalender?type=maaned&dato=${kalendermaaned}`
      );

      tegnKalender(svar, aar, maaned);
    } catch (fejl) {
      toem(el.kalender);
      el.maanedTotal.textContent = fejl.message;
    }
  }

  function tegnKalender(svar, aar, maaned) {
    const dagePrDato = new Map();

    for (const dag of svar.dage.concat(svar.kunMaddage || [])) {
      dagePrDato.set(dag.dato, dag);
    }

    const foersteDag = new Date(Date.UTC(aar, maaned - 1, 1));
    const antalDage = new Date(Date.UTC(aar, maaned, 0)).getUTCDate();

    // Mandag er ugens første dag i Danmark
    const tomme = (foersteDag.getUTCDay() + 6) % 7;

    toem(el.kalender);

    for (let i = 0; i < tomme; i += 1) {
      el.kalender.append(lav('div', { klasse: 'kalender-dag tom' }));
    }

    const dagensDato = iDag();

    for (let dagtal = 1; dagtal <= antalDage; dagtal += 1) {
      const dato = `${aar}-${String(maaned).padStart(2, '0')}-${String(dagtal).padStart(2, '0')}`;
      const oplysning = dagePrDato.get(dato);
      const harTimer = oplysning && oplysning.sekunder > 0;

      const klasser = ['kalender-dag'];
      if (harTimer) klasser.push('har-timer');
      if (dato === dagensDato) klasser.push('i-dag');
      if (dato === valgtDag) klasser.push('valgt');

      el.kalender.append(lav('button', {
        klasse: klasser.join(' '),
        type: 'button',
        'aria-label': `${datoLang(dato)}${harTimer ? `, ${oplysning.varighed}` : ', ingen timer'}`,
        paaClick: () => vaelgDag(dato)
      }, [
        lav('span', { klasse: 'kalender-dagtal', tekst: String(dagtal) }),
        oplysning && oplysning.mad ? lav('span', { klasse: 'kalender-mad' }) : null,
        harTimer ? lav('span', { klasse: 'kalender-timer', tekst: oplysning.varighed.slice(0, 5) }) : null
      ]));
    }

    const total = svar.total;

    el.maanedTotal.textContent =
      `${MAANEDER[maaned - 1]}: ${total.varighed} på ${total.antalDage} `
      + `${total.antalDage === 1 ? 'dag' : 'dage'}`
      + (total.madAntal > 0 ? ` · ${total.madAntal} måltider, ${total.madPris}` : '');
  }

  async function vaelgDag(dato) {
    valgtDag = valgtDag === dato ? null : dato;

    for (const knap of Array.from(el.kalender.children)) {
      knap.classList.remove('valgt');
    }

    if (valgtDag === null) {
      toem(el.dagsdetalje);
      return;
    }

    try {
      const dag = await kald(`/api/medarbejder/${medarbejderId}/dag/${dato}`);
      tegnDagsdetalje(dag);
    } catch (fejl) {
      toem(el.dagsdetalje);
      el.dagsdetalje.append(lav('div', { klasse: 'besked besked-fejl', tekst: fejl.message }));
    }

    // Markér den valgte dag igen efter hentningen
    for (const knap of Array.from(el.kalender.children)) {
      if (knap.getAttribute('aria-label')?.startsWith(datoLang(dato))) {
        knap.classList.add('valgt');
      }
    }
  }

  function tegnDagsdetalje(dag) {
    toem(el.dagsdetalje);

    // Medarbejderen ser kun tiderne. Om en registrering er rettet eller lukket
    // automatisk, står intet sted her - det er en oplysning til Administration.
    const raekker = dag.registreringer.map((r) => lav('tr', {}, [
      lav('td', { klasse: 'tal', tekst: r.checkInd }),
      lav('td', { klasse: 'tal', tekst: r.checkUd || '—' }),
      lav('td', { klasse: 'tal h', tekst: r.varighed || 'ikke afsluttet' })
    ]));

    el.dagsdetalje.append(lav('div', { klasse: 'kort mt', style: 'background: var(--flade-hoej);' }, [
      lav('div', { klasse: 'kort-hoved' }, [
        lav('strong', { tekst: `${dag.ugedag} den ${dag.datoLang}` }),
        lav('span', { klasse: 'tal', tekst: dag.varighed })
      ]),

      dag.registreringer.length === 0
        ? lav('p', { klasse: 'daempet lille', tekst: 'Ingen tidsregistreringer denne dag.' })
        : lav('div', { klasse: 'tabelramme' }, [
            lav('table', {}, [
              lav('thead', {}, [
                lav('tr', {}, [
                  lav('th', { tekst: 'Ind' }),
                  lav('th', { tekst: 'Ud' }),
                  lav('th', { klasse: 'h', tekst: 'Timer' })
                ])
              ]),
              lav('tbody', {}, raekker)
            ])
          ]),

      dag.mad
        ? lav('p', { klasse: 'lille daempet mt',
            tekst: `Mad registreret kl. ${dag.mad.klokkeslaet} · ${dag.mad.pris}` })
        : null
    ]));
  }

  /* ------------------------------------------------------------------ */
  /* Handlinger                                                         */
  /* ------------------------------------------------------------------ */

  async function checkInd() {
    el.knapInd.disabled = true;

    try {
      const svar = await kald(`/api/medarbejder/${medarbejderId}/check-ind`, { method: 'POST' });

      vis(el.besked, svar.besked, 'god', 6);
      await hent();
    } catch (fejl) {
      vis(el.besked, fejl.message, 'fejl', 8);
      await hent();
    } finally {
      el.knapInd.disabled = false;
    }
  }

  async function checkUd() {
    const svarPaaSpoergsmaal = await spoerg({
      titel: 'Check ud nu?',
      tekst: `Din arbejdstid bliver gemt, og du kommer tilbage til navnene.`,
      bekraeft: 'Ja, check mig ud'
    });

    if (!svarPaaSpoergsmaal) return;

    el.knapUd.disabled = true;

    try {
      const svar = await kald(`/api/medarbejder/${medarbejderId}/check-ud`, { method: 'POST' });

      stopUr();
      visKvittering(svar);
    } catch (fejl) {
      vis(el.besked, fejl.message, 'fejl', 8);
      el.knapUd.disabled = false;
      await hent();
    }
  }

  /** Fylder skærmen efter check ud og sender tilbage til forsiden af sig selv. */
  function visKvittering(svar) {
    let tilbage = svar.sekunderFoerRetur || sekunderFoerRetur;

    const nedtaelling = lav('div', { klasse: 'kvittering-under' });

    const skaerm = lav('div', { klasse: 'kvittering' }, [
      lav('div', { klasse: 'kvittering-overskrift', tekst: `Farvel, ${tilstand.medarbejder.navn}` }),
      lav('div', { klasse: 'kvittering-tal', tekst: svar.registrering.varighed }),
      lav('div', { klasse: 'kvittering-under',
        tekst: `${svar.registrering.checkInd} – ${svar.registrering.checkUd} · gemt` }),
      nedtaelling,
      lav('button', {
        klasse: 'knap mt',
        tekst: 'Tilbage til navnene nu',
        paaClick: () => { window.location.href = '/'; }
      })
    ]);

    document.body.append(skaerm);

    const opdaterNedtaelling = () => {
      nedtaelling.textContent = `Tilbage til navnene om ${tilbage} `
        + `${tilbage === 1 ? 'sekund' : 'sekunder'} …`;
    };

    opdaterNedtaelling();

    const ur = setInterval(() => {
      tilbage -= 1;

      if (tilbage <= 0) {
        clearInterval(ur);
        window.location.href = '/';
        return;
      }

      opdaterNedtaelling();
    }, 1000);
  }

  /**
   * Beder om beløbet og registrerer måltidet.
   *
   * Feltet starter tomt - der findes ingen fast pris. Rabatten regnes ud mens
   * man skriver, så man kan se hvad man kommer til at betale, inden man trykker.
   */
  function registrerMad() {
    const rabat = tilstand.mad.rabatProcent;
    const hoejeste = tilstand.mad.hoejesteBeloebOere || 100000;

    aabnVindue((luk) => {
      const beloebsfelt = lav('input', {
        type: 'text',
        inputmode: 'decimal',
        id: 'mad-beloeb',
        placeholder: 'F.eks. 99',
        maxlength: '10'
      });

      const udregning = lav('div', { klasse: 'besked besked-neutral' });
      const fejlfelt = lav('div', { klasse: 'besked', hidden: true });

      /** Læser feltet og viser hvad der skal betales. Returnerer ører, eller null. */
      const laes = () => {
        const tekst = String(beloebsfelt.value)
          .replace(/kr\.?/gi, '').replace(/\s/g, '')
          .replace(/\./g, '').replace(',', '.').trim();

        if (!/^\d+(\.\d{1,2})?$/.test(tekst)) return null;

        return Math.round(Number.parseFloat(tekst) * 100);
      };

      const kroner = (oere) => {
        const hele = Math.floor(oere / 100);
        return `${String(hele).replace(/\B(?=(\d{3})+(?!\d))/g, '.')},`
          + `${String(oere % 100).padStart(2, '0')} kr.`;
      };

      const opdater = () => {
        const oere = laes();

        if (oere === null || oere <= 0) {
          udregning.className = 'besked besked-neutral';
          udregning.textContent = 'Skriv beløbet, f.eks. 99 eller 85,50.';
          return;
        }

        if (oere > hoejeste) {
          udregning.className = 'besked besked-fejl';
          udregning.textContent = `Beløbet må højst være ${kroner(hoejeste)}. `
            + 'Kontrollér at du har skrevet kroner og ikke ører.';
          return;
        }

        const pris = Math.round((oere * (100 - rabat)) / 100);

        udregning.className = 'besked besked-god';
        udregning.textContent = `Du betaler ${kroner(pris)} `
          + `(${kroner(oere)} minus ${rabat} % medarbejderrabat).`;
      };

      beloebsfelt.addEventListener('input', opdater);
      opdater();

      const gem = async () => {
        const oere = laes();

        if (oere === null || oere <= 0) {
          vis(fejlfelt, 'Skriv beløbet som kroner og ører, f.eks. 99 eller 85,50.', 'fejl');
          beloebsfelt.focus();
          return;
        }

        try {
          const svar = await kald(`/api/medarbejder/${medarbejderId}/mad`, {
            method: 'POST',
            krop: { beloeb: beloebsfelt.value }
          });

          luk();
          vis(el.besked, svar.besked, 'god', 8);
          await hent();
          await hentKalender();
        } catch (fejl) {
          vis(fejlfelt, fejl.message, 'fejl');
        }
      };

      beloebsfelt.addEventListener('keydown', (haendelse) => {
        if (haendelse.key === 'Enter') gem();
      });

      return [
        lav('h2', { tekst: 'Hvad kostede maden?' }),
        lav('p', { klasse: 'vindue-under',
          tekst: `Skriv hvad maden kostede. Du får ${rabat} % rabat.` }),

        fejlfelt,

        lav('div', { klasse: 'felt' }, [
          lav('label', { for: 'mad-beloeb', tekst: 'Beløb i kroner' }),
          beloebsfelt
        ]),

        udregning,

        lav('div', { klasse: 'vindue-fod' }, [
          lav('button', { klasse: 'knap', tekst: 'Fortryd', paaClick: luk }),
          lav('button', { klasse: 'knap knap-messing', tekst: 'Registrér', paaClick: gem })
        ])
      ];
    });
  }

  /* ------------------------------------------------------------------ */
  /* Udskrift                                                           */
  /* ------------------------------------------------------------------ */

  function pdfAdresse(hent) {
    const type = find('#pdf-type').value;
    const dele = new URLSearchParams({ type });

    if (type === 'periode') {
      const fra = find('#pdf-fra').value;
      const til = find('#pdf-til').value;

      if (!fra || !til) {
        vis(el.besked, 'Vælg både en fra-dato og en til-dato.', 'advarsel', 6);
        return null;
      }

      dele.set('fra', fra);
      dele.set('til', til);
    } else {
      dele.set('dato', find('#pdf-dato').value || iDag());
    }

    if (hent) dele.set('hent', '1');

    return `/api/medarbejder/${medarbejderId}/pdf?${dele.toString()}`;
  }

  function opsaetUdskrift() {
    const typefelt = find('#pdf-type');

    find('#pdf-dato').value = iDag();
    find('#pdf-fra').value = `${iDag().slice(0, 7)}-01`;
    find('#pdf-til').value = iDag();

    typefelt.addEventListener('change', () => {
      const valgfri = typefelt.value === 'periode';

      find('#pdf-dato-felt').classList.toggle('skjult', valgfri);
      find('#pdf-fra-felt').classList.toggle('skjult', !valgfri);
      find('#pdf-til-felt').classList.toggle('skjult', !valgfri);
    });

    find('#pdf-vis').addEventListener('click', () => {
      const adresse = pdfAdresse(false);
      if (adresse) window.open(adresse, '_blank', 'noopener');
    });

    find('#pdf-hent').addEventListener('click', () => {
      const adresse = pdfAdresse(true);
      if (adresse) window.location.href = adresse;
    });
  }

  /* ------------------------------------------------------------------ */
  /* Hentning                                                           */
  /* ------------------------------------------------------------------ */

  async function hent() {
    try {
      tilstand = await kald(`/api/medarbejder/${medarbejderId}`);
      sekunderFoerRetur = tilstand.sekunderFoerRetur || 5;

      // Træk den løbende vagt fra, så den kan lægges til igen hvert sekund
      const o = tilstand.oversigt;
      const l = o.loebendeSekunder || 0;

      grundtal = {
        loebende: l,
        iDag: o.iDag.sekunder - l,
        uge: o.denneUge.sekunder - l,
        maaned: o.denneMaaned.sekunder - l,
        aar: o.detteAar.sekunder - l,
        samlet: o.samlet.sekunder - l
      };

      document.title = `${tilstand.medarbejder.navn} · Min tid`;
      el.navn.textContent = tilstand.medarbejder.navn;
      el.dagsdato.textContent = `${tilstand.oversigt.datoDansk} · lukketid ${tilstand.lukketid}`;

      tegnKnapper();
      tegnNoegletal();
      startUr();

      skjul(el.besked);
    } catch (fejl) {
      vis(el.besked, fejl.message, 'fejl');

      if (fejl.status === 404) {
        el.navn.textContent = 'Medarbejderen findes ikke';
        setTimeout(() => { window.location.href = '/'; }, 4000);
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* Opstart                                                            */
  /* ------------------------------------------------------------------ */

  if (!Number.isInteger(medarbejderId)) {
    window.location.href = '/';
    return;
  }

  find('#tilbage').addEventListener('click', () => { window.location.href = '/'; });
  el.knapInd.addEventListener('click', checkInd);
  el.knapUd.addEventListener('click', checkUd);
  el.knapMad.addEventListener('click', registrerMad);

  find('#maaned-tilbage').addEventListener('click', () => {
    kalendermaaned = flytMaaned(kalendermaaned, -1);
    hentKalender();
  });

  find('#maaned-frem').addEventListener('click', () => {
    kalendermaaned = flytMaaned(kalendermaaned, 1);
    hentKalender();
  });

  tegnUgedage();
  opsaetUdskrift();
  hent();
  hentKalender();

  setInterval(hent, OPDATERING_SEKUNDER * 1000);

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) hent();
  });
}());
