# Tidsregistrering

Lokalt tidsregistreringssystem til restauranten. Kører på én Mac uden internet.
Medarbejderne trykker på deres navn, checker ind og ud. Alt gemmes lokalt.

---

## Sådan kommer du i gang

### 1. Læg mappen det rigtige sted

Læg mappen `tidsregistrering` i din **hjemmemappe** — for eksempel:

```
/Users/ditnavn/tidsregistrering
```

**Vigtigt:** læg den **ikke** i iCloud Drive, Dropbox, Google Drive eller på et
netværksdrev. Databasen skriver hele tiden små ændringer, og de tjenester
synkroniserer filerne midt i en skrivning. Det kan ødelægge databasen.
En almindelig mappe på Mac'ens egen disk er det rigtige sted.

### 2. Installer Node.js

Systemet kræver Node.js version 20 eller nyere.

Åbn **Terminal** (findes under Programmer → Hjælpeprogrammer) og skriv:

```
node --version
```

Får du et tal på 20 eller derover, er du klar. Får du "command not found",
skal Node installeres:

1. Gå til <https://nodejs.org>
2. Hent versionen der er mærket **LTS**
3. Åbn den hentede fil og følg vejledningen

### 3. Gør startfilerne klar

Første gang skal Mac'en have lov til at køre filerne. Åbn Terminal, skriv `cd `
(med mellemrum efter), træk mappen ind i Terminal-vinduet og tryk retur.
Skriv derefter:

```
chmod +x *.command
```

### 4. Kør INSTALLER

Dobbeltklik på **INSTALLER.command**.

Den henter de tre programbiblioteker systemet bruger. Det kræver internet
*denne ene gang* — derefter kører systemet permanent offline.

Siger macOS at filen ikke kan åbnes, fordi den er fra en ukendt udvikler:
højreklik på filen, vælg **Åbn**, og bekræft.

### 5. Start systemet

Dobbeltklik på **START-SYSTEM.command**.

Første gang oprettes administratoren automatisk:

```
Brugernavn:   admin
Adgangskode:  admin123
```

> **Skift adgangskoden.** Alle på restaurantens wi-fi kan nå login-siden, og
> "admin123" er blandt de første koder nogen prøver. Log ind på
> `localhost:3000/admin` og skift den under **Indstillinger**.
> Der findes kun én administrator — flere kan ikke oprettes.

Vinduet viser adresserne:

```
  På denne computer:      http://localhost:3000
  På netværket:           http://192.168.1.42:3000
  Administration:         http://localhost:3000/admin
```

**Luk ikke vinduet** — minimér det. Lukker du vinduet, stopper systemet.

---

## Sådan kommer tabletten på

Skriv netværksadressen fra START-SYSTEM ind i tablettens browser, for eksempel
`http://192.168.1.42:3000`. Tabletten skal være på samme wi-fi som Mac'en.

Gem den som ikon på hjemmeskærmen: tryk på del-knappen i Safari og vælg
**Føj til hjemmeskærm**. Så åbner den i fuld skærm uden adresselinje.

### Giv Mac'en en fast IP

Mac'ens adresse kan skifte, når routeren genstarter — og så kan tabletten ikke
finde systemet. Bed routeren om at give Mac'en den samme adresse hver gang.
Det hedder typisk "DHCP-reservation" eller "statisk lease" i routerens
opsætning. Alternativt kan adressen sættes fast under
Systemindstillinger → Netværk → Detaljer → TCP/IP.

### Slå dvale fra

En Mac der går i dvale, stopper systemet — og så virker det automatiske check
ud kl. 21:00 ikke. Under **Systemindstillinger → Batteri** (eller **Energi**)
slås dvale fra. Skærmen må gerne slukke; computeren må ikke sove.

---

## Daglig brug

**Medarbejderen** trykker på sit navn, trykker den grønne **Check ind**, og går
på arbejde. Timeren tæller op. Når vagten er slut: den røde **Check ud**.
Skærmen viser dagens tid og vender selv tilbage til navnene efter fem sekunder.

Har medarbejderen spist, trykkes **Jeg har spist**. Der kommer et tomt felt,
hvor beløbet skrives — f.eks. 99. Systemet trækker de 25 % fra og viser hvad
der skal betales, mens man skriver.

**Glemmer nogen at checke ud**, lukker systemet vagten kl. 21:00 med sluttid
21:00. Ingen timer forsvinder. Vagten markeres som "automatisk" og lægges i
Administration under **Kræver gennemsyn**, så du kan rette den hvis tiden er
forkert.

---

## Administration

Åbn `http://localhost:3000/admin` og log ind.

Der er **med vilje intet link til Administration** på personaleskærmen — heller
ikke i sidens kildekode. Skærmen står frit fremme ved personaleindgangen, og
ordet "admin" står ingen steder på den. Man kommer kun ind ved selv at skrive
adressen.

Fra din egen computer eller telefon skriver du:

```
192.168.1.42:3000/admin
```

(tallet er Mac'ens adresse — den står i START-SYSTEM-vinduet)

Gem den som bogmærke på din egen enhed. Gem den **ikke** på tabletten ved
personaleindgangen.

| Fane | Hvad du kan gøre |
|---|---|
| **Overblik** | Se hvem der er på arbejde nu, dagens og ugens timer, hvad der kræver gennemsyn |
| **Timer** | Se, rette, tilføje og slette registreringer. Filtrér på periode og medarbejder |
| **Medarbejdere** | Opret, ret, deaktivér og slet. Bestem rækkefølgen på personaleskærmen |
| **Mad** | Opgørelse pr. medarbejder, og alle måltider — hvor du kan rette beløbet eller fjerne en fejlregistrering |
| **Statistik** | Timer pr. medarbejder, pr. måned, pr. år og samlet |
| **Udskrift** | PDF for én medarbejder (linje pr. vagt) eller alle samlet (linje pr. medarbejder med vagter og timer — den revisoren skal bruge) |
| **Indstillinger** | Virksomhedsnavn til PDF, skift adgangskode |
| **Backup** | Tag backup, se de eksisterende, gendan en tidligere |
| **Ændringslog** | Det eneste sted rettelser kan ses |

### Om at slette en medarbejder

En medarbejder med registreringer **kan ikke slettes** — så ville timerne
forsvinde. Brug **Deaktivér**: navnet forsvinder fra personaleskærmen, mens alle
timer bliver i kalenderen, statistikken og udskrifterne. Kun en nyoprettet
medarbejder uden registreringer kan slettes helt.

### Om madprisen

Der findes ingen fast madpris i systemet. Medarbejderen skriver selv hvad maden
kostede, og systemet trækker altid 25 % fra det indtastede beløb.

Der kan højst registreres ét måltid pr. medarbejder pr. dag, og beløbet kan
højst være 1.000 kr. Grænsen fanger tastefejl som "9900" i stedet for "99".

**Måltider beholder den pris de blev registreret til.** En opgørelse fra en
tidligere måned kan derfor ikke ændre sig bagud.

### Om rettede tider

Retter du en tid, eller lukker systemet en vagt automatisk kl. 21:00, står det
**ingen steder på selve registreringen**. Åbner man vagten — på
medarbejdersiden, i kalenderen, på PDF-udskriften eller i Administrations egen
fane **Timer** — ser den ud som enhver anden. Der er ingen mærkat, intet
"rettet", intet "automatisk".

Rettelsen kan kun ses ét sted: i fanen **Ændringslog**. Der står hvem, hvornår,
hvilket felt, fra hvad til hvad og hvorfor. Loggen er bag dit login, og den kan
ikke redigeres eller slettes.

Sletter du en registrering, gemmes hele den slettede vagt i loggen, så timerne
kan skrives ind igen hvis du fortryder.

---

## Backup

Systemet tager selv backup hver nat kl. 03:30 og gemmer de 30 nyeste.
Er maskinen slukket kl. 03:30, tages backuppen i stedet ved næste opstart.

Du kan tage en backup manuelt fra Administration, eller ved at dobbeltklikke på
**BACKUP.command**. Manuelle backups slettes aldrig af sig selv.

Filerne ligger i mappen `backups/`.

> **Læg jævnligt en kopi af `backups/` over på en USB-nøgle eller et andet
> drev.** En backup der kun ligger på samme computer som databasen, hjælper ikke
> hvis computeren bliver stjålet eller går i stykker.

### Gendan en backup

I Administration → Backup, tryk **Gendan** ud for den ønskede. Systemet
kontrollerer filen først, tager en sikkerhedskopi af det nuværende indhold, og
erstatter så databasen. Fortryder du, kan du gendanne sikkerhedskopien.
Serveren skal genstartes bagefter — det sker af sig selv.

Kan systemet slet ikke startes, kan du gendanne fra Terminal:

```
npm run gendan
```

Kør **STOP-SYSTEM** først.

---

## Når noget går galt

**Tabletten kan ikke finde systemet.** Kontrollér at START-SYSTEM-vinduet står
åbent, at Mac'en ikke sover, og at tabletten er på samme wi-fi. Adressen kan
have ændret sig — se den i START-SYSTEM-vinduet.

**"Port 3000 er allerede i brug."** Systemet kører sandsynligvis allerede. Kør
STOP-SYSTEM, og start igen. Bruger et andet program porten, kan du ændre den i
`konfiguration.json`.

**Glemt administratoradgangskode.** Har du skiftet den og ikke kan huske den,
så åbn Terminal i mappen og skriv:

```
npm run nulstil-adminkode
```

Det kan kun gøres fra maskinen selv — derfor findes der ingen "glemt kode"-knap
i panelet.

**Vil du se om databasen er sund?**

```
npm run tjek-database
```

Den viser hvor meget der er registreret, om integritetstjekket består, og
hvornår der sidst blev taget backup.

**Systemet gik ned.** START-SYSTEM starter det automatisk igen efter tre
sekunder. Sker det gentagne gange, står årsagen i mappen `logfiler/` under
dagens dato.

---

## Sådan er det bygget

| Del | Valg | Hvorfor |
|---|---|---|
| Server | Node.js + Express | Ét program, starter på et sekund, ingen kompilering |
| Database | SQLite (én fil) | Ingen serverproces at holde kørende, backup er en filkopi |
| Skærme | Almindelig HTML, CSS og JavaScript | Ingen byggetrin — ret en fil, opdatér browseren |
| PDF | pdfkit | Ren JavaScript, ingen systemkrav |
| Adgangskoder | scrypt (indbygget i Node) | Ingen ekstra afhængighed |

Tre afhængigheder i alt. Det er med vilje: hver afhængighed er noget der kan
gå i stykker om to år, og på en maskine uden internet kan du ikke reparere det
du ikke kan hente.

### Mappestruktur

```
tidsregistrering/
├── INSTALLER.command          Klargør systemet (kør én gang)
├── START-SYSTEM.command       Start
├── STOP-SYSTEM.command        Stop
├── BACKUP.command             Backup nu
├── konfiguration.json         Port, lukketid, backuptidspunkt
├── package.json
│
├── data/                      Databasen. Rør ikke filerne her.
├── backups/                   Backupfiler
├── logfiler/                  Én logfil pr. dag, ryddes efter 90 dage
│
├── public/                    De tre skærme
│   ├── index.html             Forsiden med navnene
│   ├── medarbejder.html       Medarbejderens egen side
│   ├── admin.html             Administration
│   ├── stil.css               Fælles udseende
│   ├── faelles.js             Delte hjælpefunktioner
│   ├── forside.js
│   ├── medarbejder.js
│   └── admin.js
│
└── server/
    ├── index.js               Serveren
    ├── config.js              Indstillinger og validering
    ├── api/                   Ruterne
    │   ├── hjaelp.js
    │   ├── personale.js       Åbne ruter til personaleskærmen
    │   └── admin.js           Ruter bag login
    ├── db/
    │   ├── schema.sql         Databasedesignet
    │   ├── database.js        Forbindelse og skemaopdatering
    │   ├── medarbejdere.js
    │   ├── registreringer.js  Check ind, check ud, timeopgørelser
    │   ├── mad.js
    │   ├── indstillinger.js
    │   └── revision.js        Ændringsloggen
    ├── lib/
    │   ├── tid.js             Al tidshåndtering, Europe/Copenhagen
    │   ├── fejl.js            Fejlhåndtering og danske beskeder
    │   ├── log.js
    │   ├── adgang.js          Login og sessioner
    │   ├── backup.js
    │   ├── planlaegger.js     Automatisk check ud og backup
    │   ├── statistik.js
    │   ├── rapport.js         Indholdet i udskrifter
    │   └── pdf.js             Tegningen af udskrifter
    └── scripts/
        ├── opret-admin.js
        ├── nulstil-adminkode.js
        ├── backup-nu.js
        ├── gendan-backup.js
        └── tjek-database.js
```

### Indstillinger i konfiguration.json

| Felt | Standard | Betydning |
|---|---|---|
| `port` | 3000 | Adressen systemet svarer på |
| `lukketid` | "21:00" | Hvornår åbne vagter lukkes automatisk |
| `automatiskBackupKlokken` | "03:30" | Tidspunkt for den daglige backup |
| `antalBackupsGemmes` | 30 | Antal automatiske backups der beholdes |
| `sessionTimer` | 8 | Timer før administrator logges ud |
| `maksLoginForsoeg` | 5 | Mislykkede forsøg før spærring |
| `spaerretidMinutter` | 15 | Hvor længe der spærres |
| `sekunderFoerReturTilForside` | 5 | Efter check ud |
| `logNiveau` | "info" | `debug` logger hvert kald |

Ændringer kræver genstart af systemet.

### Rettigheder

**Medarbejdere** har intet login. De kan checke sig selv ind og ud, registrere
mad, og se og udskrive deres egne timer. De kan ikke rette en tid og ser ingen
administrationsfunktioner.

**Administrator** har fuld adgang bag login. Hver rettelse gemmes i
ændringsloggen, som kun administrator kan se, og som ikke kan redigeres eller
slettes. Ude på selve registreringerne står der intet om at noget er ændret.

### Om tid

Tidspunkter gemmes i UTC og vises i dansk tid. Det betyder at en vagt over
sommertidsskiftet får den rigtige længde — den nat hvor uret flyttes, bliver
vagten faktisk en time længere eller kortere, og det er den faktiske arbejdstid
der bliver gemt.

Datoer vises som `dd-mm-åååå` og klokkeslæt i 24 timer overalt.
Ugen starter mandag.
