#!/bin/bash
#
# BACKUP.command
#
# Tager en backup med det samme. Kan køres mens systemet kører.
#
# Manuelle backups slettes aldrig af sig selv - kun de automatiske ryddes op.

cd "$(dirname "$0")" || exit 1

printf '\033[2J\033[H'
echo ""
echo "  Tager backup …"
echo ""

if [ ! -d node_modules ]; then
  echo "  Programbibliotekerne mangler. Dobbeltklik på INSTALLER først."
  echo ""
  read -r -p "  Tryk retur for at lukke. " _
  exit 1
fi

npm run backup --silent

echo "  Backupfilerne ligger i mappen backups/ ved siden af dette program."
echo ""
echo "  Læg jævnligt en kopi af mappen over på en USB-nøgle eller i skyen."
echo "  En backup der ligger på den samme computer som databasen, hjælper"
echo "  ikke hvis computeren går tabt."
echo ""
read -r -p "  Tryk retur for at lukke. " _
