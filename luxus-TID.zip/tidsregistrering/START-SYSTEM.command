#!/bin/bash
#
# START-SYSTEM.command
#
# Starter systemet og holder det kørende. Vinduet skal stå åbent - lukker du
# det, lukker systemet. Minimér det i stedet.
#
# Går serveren ned af en uventet årsag, starter den automatisk igen efter
# tre sekunder. Det er derfor medarbejderne kan blive ved med at checke ind,
# selv hvis noget uforudset sker en aften.

cd "$(dirname "$0")" || exit 1

if ! command -v node > /dev/null 2>&1; then
  printf '\033[2J\033[H'
  echo ""
  echo "  Node.js er ikke installeret."
  echo "  Dobbeltklik på INSTALLER først."
  echo ""
  read -r -p "  Tryk retur for at lukke. " _
  exit 1
fi

if [ ! -d node_modules ]; then
  printf '\033[2J\033[H'
  echo ""
  echo "  Programbibliotekerne mangler."
  echo "  Dobbeltklik på INSTALLER først."
  echo ""
  read -r -p "  Tryk retur for at lukke. " _
  exit 1
fi

# Gem serverens proces-id, så STOP-SYSTEM kan finde den
echo $$ > .server.pid

oprydning() {
  rm -f .server.pid
  echo ""
  echo "  Systemet er stoppet."
  echo ""
  exit 0
}

trap oprydning INT TERM

printf '\033[2J\033[H'
echo ""
echo "  Tidsregistrering starter …"
echo "  Luk ikke dette vindue - minimér det i stedet."
echo ""

FORSOEG=0

while true; do
  node server/index.js
  KODE=$?

  # Kode 0 betyder en planlagt nedlukning - så skal der ikke startes igen
  if [ $KODE -eq 0 ]; then
    oprydning
  fi

  FORSOEG=$((FORSOEG + 1))

  echo ""
  echo "  Serveren stoppede uventet (kode $KODE). Genstarter om 3 sekunder …"
  echo "  Genstart nummer $FORSOEG. Tryk Ctrl+C for at stoppe helt."
  echo ""

  sleep 3
done
