#!/bin/bash
#
# STOP-SYSTEM.command
#
# Stopper systemet pænt, så databasen bliver lukket forsvarligt.

cd "$(dirname "$0")" || exit 1

printf '\033[2J\033[H'
echo ""
echo "  Stopper tidsregistrering …"
echo ""

STOPPET=0

# Først den proces START-SYSTEM skrev ned
if [ -f .server.pid ]; then
  PID=$(cat .server.pid)

  if kill -0 "$PID" 2> /dev/null; then
    kill -TERM "$PID" 2> /dev/null
    STOPPET=1
    echo "  Sender stopsignal til systemet …"
  fi

  rm -f .server.pid
fi

# Derefter en eventuel server startet direkte fra Terminal
RESTER=$(pgrep -f "node server/index.js" 2> /dev/null)

if [ -n "$RESTER" ]; then
  echo "$RESTER" | xargs kill -TERM 2> /dev/null
  STOPPET=1
fi

sleep 2

# Er noget stadig i live, lukkes det hårdt
RESTER=$(pgrep -f "node server/index.js" 2> /dev/null)

if [ -n "$RESTER" ]; then
  echo "  Serveren svarede ikke. Lukker den hårdt."
  echo "$RESTER" | xargs kill -9 2> /dev/null
fi

echo ""

if [ $STOPPET -eq 1 ]; then
  echo "  Systemet er stoppet."
else
  echo "  Systemet kørte ikke."
fi

echo ""
sleep 2
