#!/bin/bash
#
# INSTALLER.command
#
# Klargør systemet. Køres én gang, og kræver internet netop denne ene gang.
# Derefter kører systemet permanent uden netværk.

cd "$(dirname "$0")" || exit 1

printf '\033[2J\033[H'
echo ""
echo "  Tidsregistrering - installation"
echo "  ==============================="
echo ""

# --- Node.js ---------------------------------------------------------------
if ! command -v node > /dev/null 2>&1; then
  echo "  Node.js er ikke installeret."
  echo ""
  echo "  Sådan gør du:"
  echo "    1. Åbn https://nodejs.org"
  echo "    2. Hent versionen der er mærket LTS"
  echo "    3. Åbn den hentede fil og følg vejledningen"
  echo "    4. Kør dette installationsprogram igen"
  echo ""
  read -r -p "  Tryk retur for at lukke. " _
  exit 1
fi

VERSION=$(node --version)
HOVEDVERSION=$(echo "$VERSION" | sed 's/v\([0-9]*\).*/\1/')

echo "  Node.js fundet: $VERSION"

if [ "$HOVEDVERSION" -lt 20 ]; then
  echo ""
  echo "  Systemet kræver Node.js 20 eller nyere. Hent den nyeste LTS-version"
  echo "  fra https://nodejs.org og kør dette program igen."
  echo ""
  read -r -p "  Tryk retur for at lukke. " _
  exit 1
fi

# --- Afhængigheder --------------------------------------------------------
echo ""
echo "  Henter de tre programbiblioteker systemet bruger."
echo "  Det kræver internet, og det tager typisk et halvt minut."
echo ""

if ! npm install --no-audit --no-fund; then
  echo ""
  echo "  Installationen mislykkedes."
  echo ""
  echo "  De to mest almindelige årsager:"
  echo "    1. Ingen internetforbindelse. Kontrollér den og prøv igen."
  echo "    2. Apples byggeværktøjer mangler. Kør i Terminal:"
  echo "         xcode-select --install"
  echo "       Vent til den er færdig, og kør så dette program igen."
  echo ""
  read -r -p "  Tryk retur for at lukke. " _
  exit 1
fi

# --- Startfilerne skal kunne dobbeltklikkes -------------------------------
chmod +x ./*.command 2> /dev/null

# --- Administrator --------------------------------------------------------
echo ""
echo "  Programbibliotekerne er installeret."
echo ""

if node -e "process.exit(require('./server/lib/adgang').antalAdministratorer() > 0 ? 0 : 1)" 2> /dev/null; then
  echo "  Administratoren findes allerede. Installationen er færdig."
else
  echo "  Opretter administratoren ..."
  node server/scripts/opret-admin.js

  if [ $? -ne 0 ]; then
    echo ""
    echo "  Administratoren kunne ikke oprettes."
    echo ""
    read -r -p "  Tryk retur for at lukke. " _
    exit 1
  fi
fi

echo ""
echo "  ---------------------------------------------------------------"
echo "  Installationen er færdig."
echo ""
echo "  Start systemet ved at dobbeltklikke på START-SYSTEM."
echo ""
echo "  Log ind på Administration med:"
echo "      Brugernavn:   admin"
echo "      Adgangskode:  admin123"
echo ""
echo "  Skift adgangskoden under Indstillinger, hvis flere end dig"
echo "  har adgang til netværket."
echo "  ---------------------------------------------------------------"
echo ""
read -r -p "  Tryk retur for at lukke. " _
