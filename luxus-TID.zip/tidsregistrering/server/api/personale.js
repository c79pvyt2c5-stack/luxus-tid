'use strict';

/**
 * server/api/personale.js
 *
 * Ruterne bag personaleskærmen. Ingen af dem kræver login - skærmen står ved
 * personaleindgangen, og det er sådan systemet er tænkt.
 *
 * Til gengæld kan man her kun:
 *   - se listen over aktive medarbejdere
 *   - checke sig selv ind og ud
 *   - registrere dagens måltid
 *   - se og udskrive sine egne timer
 *
 * Der findes ingen rute her der kan rette en tid, se en anden medarbejders
 * oplysninger eller ændre en indstilling. Det ligger i admin.js bag login.
 */

const express = require('express');

const config = require('../config');
const medarbejdere = require('../db/medarbejdere');
const registreringer = require('../db/registreringer');
const mad = require('../db/mad');
const indstillinger = require('../db/indstillinger');
const rapport = require('../lib/rapport');
const pdf = require('../lib/pdf');
const tid = require('../lib/tid');
const log = require('../lib/log');
const { svar, rute, heltal, tekst, periodevalg } = require('./hjaelp');
const { Valideringsfejl } = require('../lib/fejl');

const ruter = express.Router();

/* -------------------------------------------------------------------------- */
/* Forsiden                                                                   */
/* -------------------------------------------------------------------------- */

/** Navnene til forsiden, med oplysning om hvem der allerede er checket ind. */
ruter.get('/medarbejdere', rute((req, res) => {
  return svar(res, {
    medarbejdere: medarbejdere.hentTilForside(),
    serverTid: tid.tilISO(tid.nu()),
    sekunderFoerRetur: config.sekunderFoerReturTilForside
  });
}, 'forside'));

/* -------------------------------------------------------------------------- */
/* Medarbejderens egen side                                                   */
/* -------------------------------------------------------------------------- */

/** Alt medarbejdersiden skal bruge, i ét kald: status, timer og mad. */
ruter.get('/medarbejder/:id', rute((req, res) => {
  const id = heltal(req.params.id);
  const nu = tid.nu();

  const status = registreringer.status(id, nu);
  const madoversigt = mad.oversigt(id, nu);

  return svar(res, {
    medarbejder: status.medarbejder,
    erCheketInd: status.erCheketInd,
    aktivRegistrering: status.aktivRegistrering,
    oversigt: status.oversigt,
    mad: madoversigt,
    serverTid: status.serverTid,
    lukketid: config.lukketid.tekst,
    sekunderFoerRetur: config.sekunderFoerReturTilForside
  });
}, 'medarbejderside'));

/* -------------------------------------------------------------------------- */
/* Check ind og check ud                                                      */
/* -------------------------------------------------------------------------- */

ruter.post('/medarbejder/:id/check-ind', rute((req, res) => {
  const id = heltal(req.params.id);
  const resultat = registreringer.checkInd(id);

  log.info(
    `Check ind: ${resultat.medarbejder.navn} (id ${id}) `
    + `kl. ${resultat.registrering.checkInd}.`
  );

  return svar(res, {
    registrering: resultat.registrering,
    oversigt: registreringer.oversigt(id),
    besked: `God arbejdsdag, ${resultat.medarbejder.navn}.`
  }, 201);
}, 'check ind'));

ruter.post('/medarbejder/:id/check-ud', rute((req, res) => {
  const id = heltal(req.params.id);
  const resultat = registreringer.checkUd(id);

  log.info(
    `Check ud: ${resultat.medarbejder.navn} (id ${id}) `
    + `kl. ${resultat.registrering.checkUd}, ${resultat.registrering.varighed}.`
  );

  return svar(res, {
    registrering: resultat.registrering,
    oversigt: registreringer.oversigt(id),
    besked: `Farvel, ${resultat.medarbejder.navn}. Du har arbejdet ${resultat.registrering.varighed} i dag.`,
    sekunderFoerRetur: config.sekunderFoerReturTilForside
  });
}, 'check ud'));

/* -------------------------------------------------------------------------- */
/* Madordning                                                                 */
/* -------------------------------------------------------------------------- */

ruter.post('/medarbejder/:id/mad', rute((req, res) => {
  const id = heltal(req.params.id);

  const resultat = mad.registrer({
    medarbejderId: id,
    beloeb: req.body?.beloeb,
    registreretAf: 'medarbejder'
  });

  log.info(
    `Mad registreret: ${resultat.medarbejder.navn} (id ${id}), `
    + `${resultat.madregistrering.pris}.`
  );

  return svar(res, {
    madregistrering: resultat.madregistrering,
    mad: mad.oversigt(id),
    besked: `Registreret. Dagens pris er ${resultat.madregistrering.pris}`
  }, 201);
}, 'madregistrering'));

/** Rabatprocenten, så skærmen kan regne med samme tal som serveren. */
ruter.get('/madpris', rute((req, res) => {
  return svar(res, {
    rabatProcent: config.madrabatProcent,
    hoejesteBeloebOere: mad.HOEJESTE_BELOEB_OERE
  });
}, 'madpris'));

/* -------------------------------------------------------------------------- */
/* Kalender                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Dag for dag i en periode. Bruges af kalenderens måneds- og ugevisning.
 * Perioden vælges som ?type=maaned&dato=2026-07-15 eller med fra og til.
 */
ruter.get('/medarbejder/:id/kalender', rute((req, res) => {
  const id = heltal(req.params.id);
  const periode = rapport.byggPeriode(periodevalg(req.query));

  const dage = registreringer.dagssummer(id, periode.fra, periode.til);
  const maaltider = mad.hentPeriode(id, periode.fra, periode.til);
  const madPrDato = new Map(maaltider.map((m) => [m.dato, m]));

  const sum = registreringer.sumFor(id, periode.fra, periode.til);
  const madsum = mad.sumFor(id, periode.fra, periode.til);

  return svar(res, {
    periode,
    dage: dage.map((dag) => ({
      ...dag,
      mad: madPrDato.has(dag.dato)
        ? { pris: madPrDato.get(dag.dato).pris, prisOere: madPrDato.get(dag.dato).prisOere }
        : null
    })),
    // Måltider på dage helt uden vagt hører også til i kalenderen
    kunMaddage: maaltider
      .filter((m) => !dage.some((d) => d.dato === m.dato))
      .map((m) => ({
        dato: m.dato,
        datoDansk: m.datoDansk,
        ugedag: tid.ugedagsnavn(m.dato),
        sekunder: 0,
        varighed: '00:00:00',
        antalRegistreringer: 0,
        mad: { pris: m.pris, prisOere: m.prisOere }
      })),
    total: {
      sekunder: sum.sekunder,
      varighed: tid.varighed(sum.sekunder),
      timer: tid.timerDecimal(sum.sekunder),
      antalDage: sum.dage,
      madAntal: madsum.antal,
      madPris: madsum.pris
    }
  });
}, 'kalender'));

/** Alt om én dato: tider, mad og kommentarer. */
ruter.get('/medarbejder/:id/dag/:dato', rute((req, res) => {
  const id = heltal(req.params.id);
  const dato = tid.kraevGyldigDato(String(req.params.dato), 'Dato');

  // medAdminfelter: false — medarbejderen får ikke at vide om en tid er
  // rettet eller lukket automatisk. Oplysningen findes kun i Administration.
  const dag = registreringer.hentDag(id, dato, { medAdminfelter: false });
  const maaltid = mad.hentForDato(id, dato);

  return svar(res, { ...dag, mad: maaltid });
}, 'dagsvisning'));

/** Hvilke år findes der data for? Bruges af kalenderens årvælger. */
ruter.get('/medarbejder/:id/aar', rute((req, res) => {
  const statistik = require('../lib/statistik');
  const id = heltal(req.params.id);

  return svar(res, { aar: statistik.prAar(id) });
}, 'årsoversigt'));

/* -------------------------------------------------------------------------- */
/* Medarbejderens egen PDF                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Medarbejderen udskriver sine egne timer. Kun sine egne - id'et i adressen
 * bestemmer hvis timer der vises, og der findes ingen rute her der kan
 * udskrive en anden. Til gengæld er der ingen adgangskontrol, så en
 * medarbejder der kender en andens id kan i princippet se de timer.
 * Det er en bevidst afvejning: skærmen står internt, og alternativet ville
 * være en kode for hver medarbejder, som kravdokumentet udtrykkeligt fravælger.
 */
ruter.get('/medarbejder/:id/pdf', rute((req, res) => {
  const id = heltal(req.params.id);

  if (id === null) {
    throw new Valideringsfejl('Der mangler et gyldigt medarbejder-id.');
  }

  const indhold = rapport.forMedarbejder(id, periodevalg(req.query));
  const filnavn = rapport.filnavn(indhold);
  const download = tekst(req.query.hent) !== null;

  log.info(`PDF udskrevet: ${indhold.medarbejder.navn}, ${indhold.periode.etiket}.`);

  return pdf.sendTilSvar(res, indhold, filnavn, download);
}, 'pdf'));

module.exports = ruter;
