'use strict';

/**
 * server/api/admin.js
 *
 * Alle ruter bag administratorloginet.
 *
 * Kun /login og /tilstand er åbne. Alt andet går gennem kraevAdmin, som
 * afviser med 401 hvis der ikke er en gyldig session. Adgangskontrollen
 * ligger dermed ét sted i stedet for at være gentaget i hver rute.
 */

const express = require('express');

const config = require('../config');
const adgang = require('../lib/adgang');
const medarbejdere = require('../db/medarbejdere');
const registreringer = require('../db/registreringer');
const mad = require('../db/mad');
const indstillinger = require('../db/indstillinger');
const revision = require('../db/revision');
const statistik = require('../lib/statistik');
const backup = require('../lib/backup');
const planlaegger = require('../lib/planlaegger');
const rapport = require('../lib/rapport');
const pdf = require('../lib/pdf');
const database = require('../db/database');
const tid = require('../lib/tid');
const log = require('../lib/log');
const {
  svar, rute, kraevAdmin, tokenFraAnmodning,
  heltal, boolsk, tekst, periodevalg, klientIp, browserNavn
} = require('./hjaelp');
const { Valideringsfejl, Konflikt } = require('../lib/fejl');

const ruter = express.Router();

/* -------------------------------------------------------------------------- */
/* Login                                                                      */
/* -------------------------------------------------------------------------- */

ruter.post('/login', rute((req, res) => {
  const resultat = adgang.login(
    { brugernavn: req.body?.brugernavn, kodeord: req.body?.kodeord },
    { ip: klientIp(req), browser: browserNavn(req) }
  );

  res.setHeader('Set-Cookie', adgang.sessionCookie(resultat.token));

  log.info(`Administrator logget ind: ${resultat.administrator.brugernavn}.`);

  return svar(res, {
    administrator: resultat.administrator,
    udloeberTid: resultat.udloeberTid
  });
}, 'login'));

ruter.post('/log-ud', rute((req, res) => {
  const resultat = adgang.logUd(tokenFraAnmodning(req));

  res.setHeader('Set-Cookie', adgang.sessionCookie('', { slet: true }));

  return svar(res, resultat);
}, 'log ud'));

/** Er jeg logget ind? Bruges når adminpanelet åbnes. */
ruter.get('/tilstand', rute((req, res) => {
  const administrator = adgang.hentSession(tokenFraAnmodning(req));

  return svar(res, {
    loggetInd: administrator !== null,
    administrator,
    antalAdministratorer: adgang.antalAdministratorer(),
    lukketid: config.lukketid.tekst
  });
}, 'tilstand'));

ruter.post('/skift-kodeord', kraevAdmin, rute((req, res) => {
  adgang.skiftKodeord(
    req.administrator.id,
    { nuvaerende: req.body?.nuvaerende, nyt: req.body?.nyt },
    req.administrator
  );

  // Sessionerne er lukket ved skiftet, så cookien fjernes også
  res.setHeader('Set-Cookie', adgang.sessionCookie('', { slet: true }));

  return svar(res, {
    besked: 'Adgangskoden er ændret. Log ind igen med den nye kode.'
  });
}, 'skift kodeord'));

/* -------------------------------------------------------------------------- */
/* Overblik og statistik                                                      */
/* -------------------------------------------------------------------------- */

ruter.get('/overblik', kraevAdmin, rute((req, res) => {
  return svar(res, {
    overblik: statistik.overblik(),
    planlaegger: planlaegger.tilstand(),
    senesteBackup: backup.seneste()
  });
}, 'overblik'));

ruter.get('/statistik/medarbejdere', kraevAdmin, rute((req, res) => {
  const periode = rapport.byggPeriode(periodevalg(req.query));

  return svar(res, {
    periode,
    medarbejdere: statistik.prMedarbejder(periode.fra, periode.til, {
      kunAktive: boolsk(req.query.kunAktive, false)
    })
  });
}, 'statistik pr. medarbejder'));

ruter.get('/statistik/maaneder/:aar', kraevAdmin, rute((req, res) => {
  const aar = heltal(req.params.aar);
  const medarbejderId = heltal(req.query.medarbejderId);

  return svar(res, {
    aar,
    maaneder: statistik.prMaaned(aar, medarbejderId)
  });
}, 'statistik pr. måned'));

ruter.get('/statistik/aar', kraevAdmin, rute((req, res) => {
  return svar(res, {
    aar: statistik.prAar(heltal(req.query.medarbejderId)),
    samlet: statistik.samlet()
  });
}, 'statistik pr. år'));

ruter.get('/statistik/dag/:dato', kraevAdmin, rute((req, res) => {
  return svar(res, statistik.dagsoversigt(String(req.params.dato)));
}, 'dagsoversigt'));

/* -------------------------------------------------------------------------- */
/* Medarbejdere                                                               */
/* -------------------------------------------------------------------------- */

ruter.get('/medarbejdere', kraevAdmin, rute((req, res) => {
  const liste = medarbejdere.hentAlle({
    medInaktive: boolsk(req.query.medInaktive, true),
    soegetekst: tekst(req.query.soeg, 60)
  });

  return svar(res, {
    medarbejdere: liste.map((m) => ({ ...m, ...medarbejdere.optaelling(m.id) }))
  });
}, 'medarbejderliste'));

ruter.get('/medarbejdere/:id', kraevAdmin, rute((req, res) => {
  const id = heltal(req.params.id);

  return svar(res, {
    medarbejder: medarbejdere.hent(id),
    optaelling: medarbejdere.optaelling(id)
  });
}, 'medarbejder'));

ruter.post('/medarbejdere', kraevAdmin, rute((req, res) => {
  const medarbejder = medarbejdere.opret({
    navn: req.body?.navn,
    sorteringsnummer: req.body?.sorteringsnummer,
    noter: req.body?.noter
  }, req.administrator);

  log.info(`Medarbejder oprettet: ${medarbejder.navn} (id ${medarbejder.id}).`);

  return svar(res, { medarbejder }, 201);
}, 'opret medarbejder'));

ruter.put('/medarbejdere/:id', kraevAdmin, rute((req, res) => {
  const resultat = medarbejdere.opdater(
    heltal(req.params.id),
    {
      navn: req.body?.navn,
      sorteringsnummer: req.body?.sorteringsnummer,
      noter: req.body?.noter
    },
    req.administrator,
    tekst(req.body?.begrundelse)
  );

  return svar(res, resultat);
}, 'ret medarbejder'));

ruter.post('/medarbejdere/:id/aktiv', kraevAdmin, rute((req, res) => {
  const resultat = medarbejdere.saetAktiv(
    heltal(req.params.id),
    boolsk(req.body?.aktiv, true),
    req.administrator,
    tekst(req.body?.begrundelse)
  );

  return svar(res, resultat);
}, 'aktivér medarbejder'));

ruter.delete('/medarbejdere/:id', kraevAdmin, rute((req, res) => {
  const resultat = medarbejdere.slet(
    heltal(req.params.id),
    req.administrator,
    tekst(req.body?.begrundelse)
  );

  log.advarsel(`Medarbejder slettet: ${resultat.navn}.`);

  return svar(res, resultat);
}, 'slet medarbejder'));

/* -------------------------------------------------------------------------- */
/* Registreringer                                                             */
/* -------------------------------------------------------------------------- */

/** Søgning og filtrering i timerne. */
ruter.get('/registreringer', kraevAdmin, rute((req, res) => {
  const periode = rapport.byggPeriode(periodevalg(req.query));
  const medarbejderId = heltal(req.query.medarbejderId);

  if (medarbejderId) {
    // Uden adminfelterne: at en tid er rettet eller lukket automatisk, vises
    // ikke i oversigten. Det kan kun slås op i Ændringsloggen.
    const raekker = registreringer.hentPeriode(medarbejderId, periode.fra, periode.til)
      .map(({ afsluttetAutomatisk, rettetAfAdmin, ...resten }) => resten);

    return svar(res, {
      periode,
      registreringer: raekker,
      total: registreringer.sumFor(medarbejderId, periode.fra, periode.til)
    });
  }

  // Uden medarbejderfilter samles dagene på tværs
  const dage = tid.datoerIInterval(periode.fra, periode.til)
    .map((dato) => statistik.dagsoversigt(dato))
    .filter((dag) => dag.registreringer.length > 0);

  return svar(res, { periode, dage });
}, 'registreringer'));

ruter.get('/registreringer/:id', kraevAdmin, rute((req, res) => {
  const id = heltal(req.params.id);

  return svar(res, {
    registrering: registreringer.hent(id)
  });
}, 'registrering'));

ruter.post('/registreringer', kraevAdmin, rute((req, res) => {
  const registrering = registreringer.opretManuelt({
    medarbejderId: heltal(req.body?.medarbejderId),
    dato: req.body?.dato,
    checkInd: req.body?.checkInd,
    checkUd: req.body?.checkUd,
    kommentar: req.body?.kommentar
  }, req.administrator, tekst(req.body?.begrundelse));

  return svar(res, { registrering }, 201);
}, 'opret registrering'));

ruter.put('/registreringer/:id', kraevAdmin, rute((req, res) => {
  const aendringer = {};

  if (req.body?.dato !== undefined) aendringer.dato = req.body.dato;
  if (req.body?.checkInd !== undefined) aendringer.checkInd = req.body.checkInd;
  if (req.body?.checkUd !== undefined) aendringer.checkUd = req.body.checkUd;
  if (req.body?.kommentar !== undefined) aendringer.kommentar = req.body.kommentar;

  const resultat = registreringer.opdater(
    heltal(req.params.id),
    aendringer,
    req.administrator,
    tekst(req.body?.begrundelse)
  );

  return svar(res, resultat);
}, 'ret registrering'));

ruter.delete('/registreringer/:id', kraevAdmin, rute((req, res) => {
  const resultat = registreringer.slet(
    heltal(req.params.id),
    req.administrator,
    req.body?.begrundelse
  );

  log.advarsel(
    `Registrering slettet af ${req.administrator.navn}: `
    + `${resultat.registrering.datoDansk} ${resultat.registrering.checkInd}.`
  );

  return svar(res, { slettet: true });
}, 'slet registrering'));

/* -------------------------------------------------------------------------- */
/* Mad                                                                        */
/* -------------------------------------------------------------------------- */

ruter.get('/mad', kraevAdmin, rute((req, res) => {
  const periode = rapport.byggPeriode(periodevalg(req.query));

  return svar(res, {
    periode,
    registreringer: mad.alleForPeriode(periode.fra, periode.til, heltal(req.query.medarbejderId)),
    opgoerelse: mad.opgoerelsePrMedarbejder(periode.fra, periode.til)
  });
}, 'madoversigt'));

ruter.post('/mad', kraevAdmin, rute((req, res) => {
  const resultat = mad.registrer({
    medarbejderId: heltal(req.body?.medarbejderId),
    dato: req.body?.dato,
    beloeb: req.body?.beloeb,
    kommentar: req.body?.kommentar,
    registreretAf: 'administrator',
    administrator: req.administrator,
    begrundelse: tekst(req.body?.begrundelse)
  });

  return svar(res, { madregistrering: resultat.madregistrering }, 201);
}, 'opret madregistrering'));

ruter.put('/mad/:id', kraevAdmin, rute((req, res) => {
  const aendringer = {};

  if (req.body?.beloeb !== undefined) aendringer.beloeb = req.body.beloeb;
  if (req.body?.dato !== undefined) aendringer.dato = req.body.dato;
  if (req.body?.kommentar !== undefined) aendringer.kommentar = req.body.kommentar;

  const resultat = mad.opdater(
    heltal(req.params.id),
    aendringer,
    req.administrator,
    tekst(req.body?.begrundelse)
  );

  return svar(res, resultat);
}, 'ret madregistrering'));

ruter.delete('/mad/:id', kraevAdmin, rute((req, res) => {
  mad.fjern(heltal(req.params.id), req.administrator, req.body?.begrundelse);

  return svar(res, { slettet: true });
}, 'fjern madregistrering'));

/* -------------------------------------------------------------------------- */
/* Indstillinger                                                              */
/* -------------------------------------------------------------------------- */

ruter.get('/indstillinger', kraevAdmin, rute((req, res) => {
  return svar(res, {
    indstillinger: indstillinger.hentAlle(),
    madrabatProcent: config.madrabatProcent
  });
}, 'indstillinger'));

ruter.put('/indstillinger/:noegle', kraevAdmin, rute((req, res) => {
  const resultat = indstillinger.saet(
    String(req.params.noegle),
    req.body?.vaerdi,
    req.administrator,
    tekst(req.body?.begrundelse)
  );

  if (resultat.aendret) {
    log.info(`Indstilling ændret af ${req.administrator.navn}: ${resultat.noegle}.`);
  }

  return svar(res, {
    ...resultat,
    indstillinger: indstillinger.hentAlle()
  });
}, 'ret indstilling'));

/* -------------------------------------------------------------------------- */
/* Ændringslog                                                                */
/*                                                                            */
/* Det eneste sted en rettelse kan ses. Ude på selve registreringerne står    */
/* der intet - hverken her i panelet eller på medarbejdersiden.               */
/* -------------------------------------------------------------------------- */

ruter.get('/aendringslog', kraevAdmin, rute((req, res) => {
  return svar(res, {
    poster: revision.soeg({
      fraDato: tekst(req.query.fra),
      tilDato: tekst(req.query.til),
      handling: tekst(req.query.handling),
      tabel: tekst(req.query.tabel),
      medarbejderId: heltal(req.query.medarbejderId),
      soegetekst: tekst(req.query.soeg, 100),
      graense: heltal(req.query.graense, 200)
    }),
    antal: revision.antal(),
    handlinger: revision.HANDLINGER
  });
}, 'ændringslog'));

/* -------------------------------------------------------------------------- */
/* PDF                                                                        */
/* -------------------------------------------------------------------------- */

/** En bestemt medarbejder eller alle - styres af ?medarbejderId= */
ruter.get('/pdf', kraevAdmin, rute((req, res) => {
  const medarbejderId = heltal(req.query.medarbejderId);
  const valg = periodevalg(req.query);

  const indhold = medarbejderId
    ? rapport.forMedarbejder(medarbejderId, valg)
    : rapport.forAlle(valg, { kunAktive: boolsk(req.query.kunAktive, false) });

  const filnavn = rapport.filnavn(indhold);

  log.info(`PDF udskrevet af ${req.administrator.navn}: ${indhold.overskrift}, ${indhold.periode.etiket}.`);

  return pdf.sendTilSvar(res, indhold, filnavn, tekst(req.query.hent) !== null);
}, 'pdf'));

/* -------------------------------------------------------------------------- */
/* Backup                                                                     */
/* -------------------------------------------------------------------------- */

ruter.get('/backups', kraevAdmin, rute((req, res) => {
  return svar(res, {
    backups: backup.hentAlle(),
    database: database.databaseoplysninger(),
    planlaegger: planlaegger.tilstand()
  });
}, 'backupliste'));

ruter.post('/backups', kraevAdmin, rute((req, res) => {
  const resultat = backup.lav({ type: 'manuel', administrator: req.administrator });

  return svar(res, {
    backup: resultat,
    besked: `Backup gemt som ${resultat.filnavn} (${Math.round(resultat.stoerrelseBytes / 1024)} kB).`
  }, 201);
}, 'manuel backup'));

/** Kontrollerer en backupfil uden at gendanne den. */
ruter.get('/backups/:filnavn/kontroller', kraevAdmin, rute((req, res) => {
  return svar(res, { kontrol: backup.kontroller(String(req.params.filnavn)) });
}, 'kontrollér backup'));

/**
 * Gendanner en backup. Kræver at kroppen indeholder bekraeft: true, så et
 * enkelt fejlklik ikke kan erstatte hele databasen.
 */
ruter.post('/backups/:filnavn/gendan', kraevAdmin, rute((req, res) => {
  if (req.body?.bekraeft !== true) {
    throw new Konflikt(
      'Gendannelse erstatter hele databasen. Bekræft handlingen for at fortsætte.',
      'kraever_bekraeftelse'
    );
  }

  const resultat = backup.gendan(String(req.params.filnavn), req.administrator);

  return svar(res, {
    ...resultat,
    besked: 'Databasen er gendannet. Systemet genstarter nu - vent nogle sekunder og opdatér siden.'
  });
}, 'gendan backup'));

/* -------------------------------------------------------------------------- */
/* Drift                                                                      */
/* -------------------------------------------------------------------------- */

/** Kører det automatiske check ud med det samme, uden at vente på lukketid. */
ruter.post('/koer-automatisk-check-ud', kraevAdmin, rute((req, res) => {
  const lukkede = registreringer.automatiskCheckUd();

  return svar(res, {
    antal: lukkede.length,
    registreringer: lukkede,
    besked: lukkede.length === 0
      ? 'Der var ingen registreringer at afslutte.'
      : `${lukkede.length} ${lukkede.length === 1 ? 'registrering' : 'registreringer'} blev afsluttet.`
  });
}, 'kør automatisk check ud'));

/**
 * Administratoren. Der findes med vilje kun én, og der kan ikke oprettes
 * flere gennem panelet - adgangskoden skiftes med /skift-kodeord, eller
 * nulstilles fra Terminal med "npm run nulstil-adminkode".
 */
ruter.get('/administratorer', kraevAdmin, rute((req, res) => {
  const { forbered } = database;

  const liste = forbered(`
    SELECT id, brugernavn, navn, aktiv, oprettet_tid, sidste_login_tid
    FROM administratorer ORDER BY brugernavn
  `).all().map((r) => ({
    id: r.id,
    brugernavn: r.brugernavn,
    navn: r.navn,
    aktiv: r.aktiv === 1,
    sidsteLogin: r.sidste_login_tid
      ? `${tid.datoDansk(tid.lokalDato(tid.fraISO(r.sidste_login_tid)))} kl. ${tid.klokkeslaet(r.sidste_login_tid)}`
      : 'aldrig'
  }));

  return svar(res, { administratorer: liste });
}, 'administratorer'));

module.exports = ruter;
