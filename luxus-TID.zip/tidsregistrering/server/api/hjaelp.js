'use strict';

/**
 * server/api/hjaelp.js
 *
 * Fælles værktøj til alle ruter, så hver enkelt rute kun indeholder det der
 * er særligt for netop den.
 *
 * Alle svar har samme form:
 *   { ok: true,  ...indhold }
 *   { ok: false, fejl: { kode, besked, detaljer } }
 *
 * Frontenden behøver derfor kun ét sted at læse fejl, og en fejl ser ens ud
 * uanset om den kom fra en validering, fra databasen eller fra noget uventet.
 */

const config = require('../config');
const adgang = require('../lib/adgang');
const log = require('../lib/log');
const { tilSvar, erBrugerfejl, oversaetDatabasefejl } = require('../lib/fejl');

/* -------------------------------------------------------------------------- */
/* Svar                                                                       */
/* -------------------------------------------------------------------------- */

function svar(res, indhold = {}, status = 200) {
  return res.status(status).json({ ok: true, ...indhold });
}

/**
 * Sender en fejl til brugeren og logger det der ikke skal vises.
 * Programfejl logges med fuldt stakspor; brugerfejl logges kun i debug.
 */
function fejlsvar(res, fejl, sammenhaeng = '') {
  const oversat = oversaetDatabasefejl(fejl);
  const { status, krop } = tilSvar(oversat);

  if (erBrugerfejl(oversat)) {
    log.debug(`Afvist${sammenhaeng ? ' (' + sammenhaeng + ')' : ''}: ${oversat.message}`);
  } else {
    log.fejl(`Uventet fejl${sammenhaeng ? ' i ' + sammenhaeng : ''}.`, fejl);
  }

  if (res.headersSent) return null;

  return res.status(status).json(krop);
}

/**
 * Pakker en rutefunktion ind, så en fejl aldrig kan vælte serveren.
 * Alt der kastes - også fra en asynkron funktion - ender i fejlsvar.
 */
function rute(handling, navn = '') {
  return function haandter(req, res, next) {
    try {
      const resultat = handling(req, res, next);

      if (resultat && typeof resultat.catch === 'function') {
        resultat.catch((fejl) => fejlsvar(res, fejl, navn || req.path));
      }
    } catch (fejl) {
      fejlsvar(res, fejl, navn || req.path);
    }
  };
}

/* -------------------------------------------------------------------------- */
/* Administratoradgang                                                        */
/* -------------------------------------------------------------------------- */

function tokenFraAnmodning(req) {
  return adgang.laesCookie(req.headers.cookie, config.sessionCookieNavn);
}

/**
 * Mellemled der kræver et gyldigt administratorlogin.
 * Lægger administratoren på req.administrator til den efterfølgende rute.
 */
function kraevAdmin(req, res, next) {
  try {
    req.administrator = adgang.kraevAdministrator(tokenFraAnmodning(req));
    return next();
  } catch (fejl) {
    return fejlsvar(res, fejl, 'adgangskontrol');
  }
}

/** Som kraevAdmin, men uden at afvise. Bruges hvor login kun ændrer indholdet. */
function maaskeAdmin(req, _res, next) {
  try {
    req.administrator = adgang.hentSession(tokenFraAnmodning(req));
  } catch (_ignoreret) {
    req.administrator = null;
  }

  return next();
}

/* -------------------------------------------------------------------------- */
/* Indlæsning af felter                                                       */
/* -------------------------------------------------------------------------- */

/** Læser et heltal fra adressen eller kroppen. */
function heltal(vaerdi, standard = null) {
  if (vaerdi === undefined || vaerdi === null || vaerdi === '') return standard;

  const tal = Number.parseInt(String(vaerdi), 10);
  return Number.isInteger(tal) ? tal : standard;
}

/** Læser en boolesk værdi fra en adresse: '1', 'true', 'ja' betyder sand. */
function boolsk(vaerdi, standard = false) {
  if (vaerdi === undefined || vaerdi === null || vaerdi === '') return standard;

  const tekst = String(vaerdi).trim().toLowerCase();
  return ['1', 'true', 'ja', 'sand', 'on'].includes(tekst);
}

/** Læser en tekst og skærer den til, så en adresse ikke kan fylde hukommelsen. */
function tekst(vaerdi, hoejst = 500) {
  if (vaerdi === undefined || vaerdi === null) return null;

  const renset = String(vaerdi).trim();
  return renset === '' ? null : renset.slice(0, hoejst);
}

/**
 * Samler periodevalget fra en adresse, så alle PDF- og oversigtsruter
 * læser det ens: ?type=uge&dato=2026-07-22 eller ?type=periode&fra=…&til=…
 */
function periodevalg(query) {
  return {
    type: tekst(query.type) || 'maaned',
    dato: tekst(query.dato),
    fra: tekst(query.fra),
    til: tekst(query.til)
  };
}

/* -------------------------------------------------------------------------- */
/* Klientens adresse                                                          */
/* -------------------------------------------------------------------------- */

/** Kort form af IP-adressen. Bruges til loginforsøg, ikke til sporing. */
function klientIp(req) {
  const raa = req.socket?.remoteAddress || req.ip || null;
  if (!raa) return null;

  // ::ffff:192.168.1.30 -> 192.168.1.30
  return raa.replace(/^::ffff:/, '').slice(0, 45);
}

function browserNavn(req) {
  const raa = req.headers['user-agent'];
  return raa ? String(raa).slice(0, 200) : null;
}

module.exports = {
  svar,
  fejlsvar,
  rute,
  kraevAdmin,
  maaskeAdmin,
  tokenFraAnmodning,
  heltal,
  boolsk,
  tekst,
  periodevalg,
  klientIp,
  browserNavn
};
