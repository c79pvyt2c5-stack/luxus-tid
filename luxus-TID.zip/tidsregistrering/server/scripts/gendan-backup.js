'use strict';

/**
 * server/scripts/gendan-backup.js
 *
 * Gendanner en backup fra Terminal.
 *
 *   npm run gendan
 *
 * Bruges når systemet ikke kan startes, og adminpanelet derfor ikke kan nås.
 * STOP-SYSTEM skal køres først - to programmer må ikke skrive i databasen
 * på samme tid.
 */

const readline = require('readline');

const backup = require('../lib/backup');
const database = require('../db/database');

function spoerg(spoergsmaal) {
  const linje = readline.createInterface({ input: process.stdin, output: process.stdout });

  return new Promise((klar) => {
    linje.question(spoergsmaal, (svar) => {
      linje.close();
      klar(svar.trim());
    });
  });
}

async function koer() {
  console.log('');
  console.log('  Gendan backup');
  console.log('  -------------');
  console.log('');
  console.log('  VIGTIGT: Stop systemet først med STOP-SYSTEM.');
  console.log('');

  const alle = backup.hentAlle();

  if (alle.length === 0) {
    console.log('  Der findes ingen backups i mappen backups/.');
    console.log('');
    process.exit(1);
  }

  console.log('  Tilgængelige backups, nyeste først:');
  console.log('');

  alle.slice(0, 30).forEach((b, nummer) => {
    const type = b.type === 'foer_gendannelse' ? 'før gendannelse' : b.type;
    console.log(
      `   ${String(nummer + 1).padStart(2)}. ${b.datoDansk} kl. ${b.klokkeslaet}`
      + `  ${type.padEnd(16)}${b.stoerrelseKb} kB`
    );
  });

  console.log('');

  const valg = await spoerg('  Skriv nummeret på den backup der skal gendannes (eller Enter for at afbryde): ');

  if (valg === '') {
    console.log('\n  Afbrudt. Intet blev ændret.\n');
    process.exit(0);
  }

  const nummer = Number.parseInt(valg, 10);
  const valgt = alle[nummer - 1];

  if (!valgt) {
    console.error('\n  Der findes ikke en backup med det nummer.\n');
    process.exit(1);
  }

  let kontrol;

  try {
    kontrol = backup.kontroller(valgt.filnavn);
  } catch (fejl) {
    console.error(`\n  ${fejl.message}\n`);
    process.exit(1);
  }

  console.log('');
  console.log(`  Backuppen indeholder:`);
  console.log(`    ${kontrol.medarbejdere} medarbejdere`);
  console.log(`    ${kontrol.registreringer} tidsregistreringer`);
  console.log(`    ${kontrol.madregistreringer} madregistreringer`);
  console.log('');
  console.log('  Hele den nuværende database bliver erstattet.');
  console.log('  Der tages automatisk en sikkerhedskopi først.');
  console.log('');

  const bekraeftelse = await spoerg('  Skriv GENDAN med store bogstaver for at fortsætte: ');

  if (bekraeftelse !== 'GENDAN') {
    console.log('\n  Afbrudt. Intet blev ændret.\n');
    process.exit(0);
  }

  try {
    const resultat = backup.gendan(valgt.filnavn, { id: null, navn: 'Terminal' });

    console.log('');
    console.log('  Databasen er gendannet.');
    console.log(`    Fra:            ${resultat.fra}`);
    console.log(`    Sikkerhedskopi: ${resultat.sikkerhedskopi}`);
    console.log('');
    console.log('  Start systemet igen med START-SYSTEM.');
    console.log('');

    process.exit(0);
  } catch (fejl) {
    console.error('');
    console.error(`  Gendannelsen mislykkedes: ${fejl.message}`);
    console.error('');
    process.exit(1);
  }
}

koer().catch((fejl) => {
  console.error(`\n  Uventet fejl: ${fejl.message}\n`);
  process.exit(1);
});
