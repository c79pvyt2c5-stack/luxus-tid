'use strict';

/**
 * server/scripts/tjek-database.js
 *
 * Ser databasen efter og fortæller hvad der er i den.
 *
 *   npm run tjek-database
 *
 * Kør den hvis noget virker forkert, eller blot for at se hvor meget der
 * er samlet op. Den ændrer ingenting.
 */

const database = require('../db/database');
const { forbered } = database;
const adgang = require('../lib/adgang');
const backup = require('../lib/backup');
const statistik = require('../lib/statistik');
const indstillinger = require('../db/indstillinger');
const tid = require('../lib/tid');

function linje(etiket, vaerdi) {
  console.log(`  ${String(etiket).padEnd(26)}${vaerdi}`);
}

try {
  const oplysninger = database.databaseoplysninger();

  console.log('');
  console.log('  Tjek af databasen');
  console.log('  -----------------');
  console.log('');

  linje('Databasefil', oplysninger.sti);
  linje('Skemaversion', oplysninger.skemaversion);
  linje('Størrelse', `${Math.round((oplysninger.stoerrelseBytes || 0) / 1024)} kB`);
  linje('Journaltilstand', oplysninger.journaltilstand);

  const tilstand = database.hurtigtIntegritetstjek();
  linje('Integritetstjek', tilstand === 'ok' ? 'ok' : `FEJL: ${tilstand}`);

  console.log('');
  console.log('  Indhold');
  console.log('  -------');
  console.log('');

  const medarbejdere = forbered(
    'SELECT COUNT(*) AS ialt, COALESCE(SUM(aktiv), 0) AS aktive FROM medarbejdere'
  ).get();

  linje('Medarbejdere', `${medarbejdere.ialt} (${medarbejdere.aktive} aktive)`);
  linje('Administratorer', adgang.antalAdministratorer());

  const samlet = statistik.samlet();

  linje('Tidsregistreringer', samlet.antalRegistreringer);
  linje('Samlet arbejdstid', `${samlet.varighed}  (${samlet.timer} timer)`);
  linje('Arbejdsdage', samlet.antalDage);

  if (samlet.foersteDatoDansk) {
    linje('Første registrering', samlet.foersteDatoDansk);
    linje('Seneste registrering', samlet.senesteDatoDansk);
  }

  linje('Madregistreringer', `${samlet.madAntal}  (${samlet.madPris})`);

  const aabne = forbered(
    'SELECT COUNT(*) AS antal FROM registreringer WHERE check_ud_tid IS NULL'
  ).get().antal;

  linje('Åbne registreringer', aabne === 0 ? '0' : `${aabne} - nogen er checket ind`);

  linje('Poster i ændringslog', forbered('SELECT COUNT(*) AS a FROM aendringslog').get().a);

  console.log('');
  console.log('  Indstillinger');
  console.log('  -------------');
  console.log('');

  for (const i of indstillinger.hentAlle()) {
    linje(i.etiket, i.visning || '(tom)');
  }

  console.log('');
  console.log('  Backup');
  console.log('  ------');
  console.log('');

  const alle = backup.hentAlle();
  const seneste = alle[0];

  linje('Antal backups', alle.length);

  if (seneste) {
    linje('Seneste backup', `${seneste.datoDansk} kl. ${seneste.klokkeslaet} (${seneste.type})`);

    const dageSiden = tid.datoerIInterval(seneste.dato, tid.iDag()).length - 1;

    if (dageSiden > 1) {
      linje('Bemærk', `Seneste backup er ${dageSiden} dage gammel.`);
    }
  } else {
    linje('Bemærk', 'Der findes endnu ingen backup. Kør: npm run backup');
  }

  console.log('');

  database.luk();
  process.exit(tilstand === 'ok' ? 0 : 1);
} catch (fejl) {
  console.error('');
  console.error(`  Databasen kunne ikke undersøges: ${fejl.message}`);
  console.error('');
  process.exit(1);
}
