'use strict';

/**
 * server/scripts/opret-admin.js
 *
 * Opretter systemets ene administrator.
 *
 *   npm run opret-admin
 *
 * Kaldes af INSTALLER og kræver ingen indtastning. Loginet er fast:
 *
 *   Brugernavn:   admin
 *   Adgangskode:  admin123
 *
 * Der findes med vilje kun én administrator. Skal adgangskoden ændres, gøres
 * det under Indstillinger i panelet, eller med:  npm run nulstil-adminkode
 *
 * BEMÆRK: "admin123" er en kode enhver ville gætte. Systemet er tilgængeligt
 * for alle på restaurantens netværk, så skift den, hvis andre end du selv har
 * adgang til wi-fi'et.
 */

const adgang = require('../lib/adgang');
const database = require('../db/database');
const { erBrugerfejl } = require('../lib/fejl');

const BRUGERNAVN = 'admin';
const KODEORD = 'admin123';
const NAVN = 'Administrator';

console.log('');
console.log('  Administrator');
console.log('  -------------');

const findes = adgang.antalAdministratorer();

if (findes > 0) {
  console.log('');
  console.log('  Administratoren findes allerede. Intet blev ændret.');
  console.log('');
  console.log('  Har du glemt adgangskoden, kan den nulstilles med:');
  console.log('      npm run nulstil-adminkode');
  console.log('');

  database.luk();
  process.exit(0);
}

try {
  adgang.opretAdministrator({
    brugernavn: BRUGERNAVN,
    navn: NAVN,
    kodeord: KODEORD
  });

  console.log('');
  console.log('  Administratoren er oprettet.');
  console.log('');
  console.log(`      Brugernavn:   ${BRUGERNAVN}`);
  console.log(`      Adgangskode:  ${KODEORD}`);
  console.log('');
  console.log('  Log ind på http://localhost:3000/admin');
  console.log('  Skift adgangskoden under Indstillinger.');
  console.log('');

  database.luk();
  process.exit(0);
} catch (fejl) {
  console.error('');
  console.error(`  ${erBrugerfejl(fejl) ? fejl.message : 'Administratoren kunne ikke oprettes: ' + fejl.message}`);
  console.error('');
  process.exit(1);
}
