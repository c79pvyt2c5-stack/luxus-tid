'use strict';

/**
 * server/scripts/backup-nu.js
 *
 * Tager en backup fra Terminal, uden at gå gennem adminpanelet.
 *
 *   npm run backup
 *
 * Kan køres mens serveren kører - SQLite laver en konsistent kopi selv om
 * der bliver skrevet undervejs.
 */

const backup = require('../lib/backup');
const database = require('../db/database');

try {
  const resultat = backup.lav({ type: 'manuel' });

  console.log('');
  console.log(`  Backup gemt: ${resultat.filnavn}`);
  console.log(`  Størrelse:   ${Math.round(resultat.stoerrelseBytes / 1024)} kB`);
  console.log(`  Placering:   ${resultat.sti}`);
  console.log('');

  const alle = backup.hentAlle();
  console.log(`  Der ligger nu ${alle.length} backup${alle.length === 1 ? '' : 's'} i mappen.`);
  console.log('');

  database.luk();
  process.exit(0);
} catch (fejl) {
  console.error('');
  console.error(`  Backuppen mislykkedes: ${fejl.message}`);
  console.error('  Kontrollér at der er ledig plads på disken.');
  console.error('');
  process.exit(1);
}
