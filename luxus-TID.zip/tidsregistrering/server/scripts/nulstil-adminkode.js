'use strict';

/**
 * server/scripts/nulstil-adminkode.js
 *
 * Sætter en ny adgangskode på en administrator, uden at kende den gamle.
 *
 *   npm run nulstil-adminkode
 *
 * Kan kun køres fra Terminal på selve maskinen. Det er derfor der ikke findes
 * en "glemt adgangskode"-knap i panelet: den ville kunne bruges af alle på
 * netværket, mens denne kræver fysisk adgang til computeren.
 */

const readline = require('readline');
const crypto = require('crypto');

const { forbered } = require('../db/database');
const adgang = require('../lib/adgang');
const revision = require('../db/revision');
const tid = require('../lib/tid');

function spoerg(spoergsmaal) {
  const linje = readline.createInterface({ input: process.stdin, output: process.stdout });

  return new Promise((klar) => {
    linje.question(spoergsmaal, (svar) => {
      linje.close();
      klar(svar.trim());
    });
  });
}

function spoergSkjult(spoergsmaal) {
  return new Promise((klar) => {
    if (!process.stdin.isTTY) {
      spoerg(spoergsmaal).then(klar);
      return;
    }

    process.stdout.write(spoergsmaal);

    const stdin = process.stdin;
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding('utf8');

    let kode = '';

    const vedTast = (tegn) => {
      if (tegn === '\n' || tegn === '\r' || tegn === '\u0004') {
        stdin.removeListener('data', vedTast);
        stdin.setRawMode(false);
        stdin.pause();
        process.stdout.write('\n');
        klar(kode);
        return;
      }

      if (tegn === '\u0003') {
        stdin.setRawMode(false);
        process.stdout.write('\n');
        process.exit(1);
      }

      if (tegn === '\u007f' || tegn === '\b') {
        if (kode.length > 0) {
          kode = kode.slice(0, -1);
          process.stdout.write('\b \b');
        }
        return;
      }

      kode += tegn;
      process.stdout.write('*');
    };

    stdin.on('data', vedTast);
  });
}

async function koer() {
  console.log('');
  console.log('  Nulstil adgangskode');
  console.log('  -------------------');
  console.log('');

  const liste = forbered(
    'SELECT id, brugernavn, navn FROM administratorer ORDER BY brugernavn'
  ).all();

  if (liste.length === 0) {
    console.log('  Der findes ingen administratorer endnu.');
    console.log('  Kør i stedet:  npm run opret-admin');
    console.log('');
    process.exit(1);
  }

  console.log('  Administratorer i systemet:');
  for (const a of liste) {
    console.log(`    ${a.brugernavn}  (${a.navn})`);
  }
  console.log('');

  const brugernavn = (await spoerg('  Hvilket brugernavn skal nulstilles? ')).toLowerCase();
  const valgt = liste.find((a) => a.brugernavn === brugernavn);

  if (!valgt) {
    console.error(`\n  Der findes ingen administrator med brugernavnet "${brugernavn}".\n`);
    process.exit(1);
  }

  console.log('');
  const kodeord = await spoergSkjult('  Ny adgangskode (mindst 8 tegn): ');
  const gentaget = await spoergSkjult('  Gentag ny adgangskode: ');

  if (kodeord !== gentaget) {
    console.error('\n  De to adgangskoder er ikke ens. Intet blev ændret.\n');
    process.exit(1);
  }

  try {
    const hash = adgang.hashKodeord(kodeord);

    forbered(
      'UPDATE administratorer SET kodeord_hash = ?, sidst_aendret_tid = ?, aktiv = 1 WHERE id = ?'
    ).run(hash, tid.tilISO(tid.nu()), valgt.id);

    forbered('DELETE FROM admin_sessioner WHERE administrator_id = ?').run(valgt.id);
    forbered('DELETE FROM login_forsoeg WHERE brugernavn = ?').run(valgt.brugernavn);

    revision.skriv({
      handling: 'ret',
      tabel: 'administratorer',
      postId: valgt.id,
      felt: 'kodeord',
      gammel: '(skjult)',
      ny: '(nulstillet fra Terminal)',
      begrundelse: 'Nulstillet med nulstil-adminkode paa selve maskinen'
    });

    console.log('');
    console.log(`  Adgangskoden for "${valgt.brugernavn}" er nulstillet.`);
    console.log('  Eventuel spærring efter mislykkede forsøg er også fjernet.');
    console.log('');
  } catch (fejl) {
    console.error(`\n  ${fejl.message}\n`);
    process.exit(1);
  }

  process.exit(0);
}

koer().catch((fejl) => {
  console.error(`\n  Uventet fejl: ${fejl.message}\n`);
  process.exit(1);
});
