'use strict';

/**
 * server/index.js
 *
 * Serveren. Starter alt i den rigtige rækkefølge, og lukker pænt ned igen.
 *
 * Opstart:
 *   1. Konfiguration læses og mapperne oprettes.       (config.js)
 *   2. Databasen åbnes, skemaet oprettes eller opdateres. (database.js)
 *   3. Fejlfangere sættes op, så intet uventet vælter serveren.
 *   4. Ruterne kobles på.
 *   5. Planlæggeren startes: efterslæb indhentes, backup tages om nødvendigt.
 *   6. Serveren lytter - også på det lokale netværk, så tablets kan nå den.
 */

const os = require('os');
const path = require('path');

const express = require('express');

const config = require('./config');
const database = require('./db/database');
const adgang = require('./lib/adgang');
const planlaegger = require('./lib/planlaegger');
const log = require('./lib/log');
const tid = require('./lib/tid');
const { tilSvar } = require('./lib/fejl');

const personaleRuter = require('./api/personale');
const adminRuter = require('./api/admin');

const app = express();

/* -------------------------------------------------------------------------- */
/* Grundopsætning                                                             */
/* -------------------------------------------------------------------------- */

app.disable('x-powered-by');
app.set('trust proxy', false);

// Krop som JSON. Grænsen er lav med vilje - ingen rute her modtager store data,
// og en lav grænse gør det umuligt at fylde hukommelsen med én anmodning.
app.use(express.json({ limit: '64kb' }));

// Systemet kører på et lukket netværk uden https, så en stram
// indholdspolitik er den beskyttelse der giver mening her.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
    + "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
  );
  next();
});

/** Skriver hvert kald i loggen. Kun ved logNiveau debug. */
app.use((req, res, next) => {
  if (log.niveau !== 'debug') return next();

  const start = Date.now();

  res.on('finish', () => {
    log.debug(`${req.method} ${req.originalUrl} -> ${res.statusCode} (${Date.now() - start} ms)`);
  });

  return next();
});

/* -------------------------------------------------------------------------- */
/* Ruter                                                                      */
/* -------------------------------------------------------------------------- */

app.use('/api', personaleRuter);
app.use('/api/admin', adminRuter);

/** Til overvågning og til START-SYSTEM, der venter på at serveren er klar. */
app.get('/api/sundhed', (req, res) => {
  let databaseOk = true;

  try {
    database.forbered('SELECT 1 AS ok').get();
  } catch (_ignoreret) {
    databaseOk = false;
  }

  res.json({
    ok: databaseOk,
    tidspunkt: tid.tilISO(tid.nu()),
    dato: tid.datoDansk(tid.iDag()),
    klokkeslaet: tid.klokkeslaetMedSekunder(tid.tilISO(tid.nu())),
    tidszone: config.tidszone,
    planlaegger: planlaegger.tilstand().koerer,
    oppetidSekunder: Math.round(process.uptime())
  });
});

// Statiske filer: de tre skærme. maxAge er nul, så en rettelse i en fil
// slår igennem ved næste opdatering i stedet for at hænge i browserens cache.
app.use(express.static(config.mapper.offentlig, {
  maxAge: 0,
  etag: true,
  index: 'index.html'
}));

/** Adminpanelet ligger på /admin og skal virke, også når man skriver adressen selv. */
app.get('/admin', (req, res) => {
  res.sendFile(path.join(config.mapper.offentlig, 'admin.html'));
});

/** Medarbejdersiden: /medarbejder/3 */
app.get('/medarbejder/:id', (req, res) => {
  res.sendFile(path.join(config.mapper.offentlig, 'medarbejder.html'));
});

/* -------------------------------------------------------------------------- */
/* Ukendte adresser og uventede fejl                                          */
/* -------------------------------------------------------------------------- */

app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({
      ok: false,
      fejl: { kode: 'ukendt_adresse', besked: 'Den forespørgsel findes ikke i systemet.' }
    });
  }

  return res.status(404).sendFile(path.join(config.mapper.offentlig, 'index.html'));
});

/**
 * Sidste led. Alt der er sluppet forbi rutefangerne ender her, så en fejl
 * bliver til et pænt svar frem for en afbrudt forbindelse.
 */
app.use((fejl, req, res, _next) => {
  const { status, krop } = tilSvar(fejl);

  log.fejl(`Uventet fejl i ${req.method} ${req.originalUrl}.`, fejl);

  if (res.headersSent) return res.end();

  return res.status(status).json(krop);
});

/* -------------------------------------------------------------------------- */
/* Netværksadresser                                                           */
/* -------------------------------------------------------------------------- */

/** De adresser tablets og telefoner kan bruge. Vises ved opstart. */
function netvaerksadresser() {
  const adresser = [];

  for (const [navn, liste] of Object.entries(os.networkInterfaces())) {
    for (const kort of liste || []) {
      if (kort.family === 'IPv4' && !kort.internal) {
        adresser.push({ navn, adresse: kort.address });
      }
    }
  }

  return adresser;
}

/* -------------------------------------------------------------------------- */
/* Opstart                                                                    */
/* -------------------------------------------------------------------------- */

let server = null;
let lukkerNed = false;

function lukPaent(aarsag, afslutningskode = 0) {
  if (lukkerNed) return;
  lukkerNed = true;

  log.info(`Serveren lukker ned (${aarsag}).`);

  planlaegger.stop();

  const afslut = () => {
    try {
      database.luk();
      log.info('Databasen er lukket forsvarligt. Farvel.');
    } catch (fejl) {
      log.fejl('Databasen kunne ikke lukkes rent.', fejl);
    }

    process.exit(afslutningskode);
  };

  if (server) {
    server.close(afslut);
    // Hænger en forbindelse, lukkes der alligevel efter fem sekunder
    setTimeout(afslut, 5000).unref();
  } else {
    afslut();
  }
}

function start() {
  log.opsaetGlobaleFejlfangere(() => {
    planlaegger.stop();
    try {
      database.luk();
    } catch (_ignoreret) {
      // Nedlukningen må ikke i sig selv kaste
    }
  });

  const oplysninger = database.databaseoplysninger();

  log.info(
    `Database klar: ${path.basename(oplysninger.sti)} `
    + `(skemaversion ${oplysninger.skemaversion}, ${Math.round((oplysninger.stoerrelseBytes || 0) / 1024)} kB).`
  );

  // Første gang systemet startes, oprettes administratoren automatisk.
  // Der er med vilje kun én: restauranten har én ansvarlig, og flere logins
  // ville blot være flere adgangskoder at holde styr på.
  if (adgang.antalAdministratorer() === 0) {
    try {
      adgang.opretAdministrator({
        brugernavn: adgang.STANDARD_BRUGERNAVN,
        navn: 'Administrator',
        kodeord: adgang.STANDARD_KODEORD
      });

      log.info('');
      log.info(`  Administrator oprettet: ${adgang.STANDARD_BRUGERNAVN} / ${adgang.STANDARD_KODEORD}`);
      log.info('  Skift adgangskoden under Administration → Indstillinger.');
      log.info('');
    } catch (fejl) {
      log.fejl('Administratoren kunne ikke oprettes automatisk.', fejl);
      log.advarsel('Opret den i stedet med kommandoen: npm run opret-admin');
    }
  }

  planlaegger.start();

  server = app.listen(config.port, config.vaert, () => {
    const adresser = netvaerksadresser();

    log.info('');
    log.info('  Tidsregistrering er klar.');
    log.info('');
    log.info(`  På denne computer:      http://localhost:${config.port}`);

    for (const { adresse } of adresser) {
      log.info(`  På netværket:           http://${adresse}:${config.port}`);
    }

    log.info(`  Administration:         http://localhost:${config.port}/admin`);
    log.info('');
    log.info(`  Lukketid ${config.lukketid.tekst} - automatisk check ud. `
      + `Backup kl. ${config.automatiskBackupKlokken.tekst}.`);
    log.info('  Luk med Ctrl+C, eller kør STOP-SYSTEM.');
    log.info('');
  });

  server.on('error', (fejl) => {
    if (fejl.code === 'EADDRINUSE') {
      log.fejl(
        `Port ${config.port} er allerede i brug.\n`
        + '  Enten kører systemet allerede, eller også bruger et andet program porten.\n'
        + '  Kør STOP-SYSTEM først, eller vælg en anden port i konfiguration.json.'
      );
    } else if (fejl.code === 'EACCES') {
      log.fejl(
        `Der er ikke adgang til port ${config.port}. Porte under 1024 kræver særlige rettigheder - `
        + 'vælg f.eks. 3000 eller 8080 i konfiguration.json.'
      );
    } else {
      log.fejl('Serveren kunne ikke startes.', fejl);
    }

    process.exit(1);
  });

  // Holder forbindelser i live lidt længere end en almindelig browser gør,
  // så en tablet på et langsomt trådløst net ikke bliver afbrudt midt i et kald
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 70000;
}

process.on('SIGINT', () => lukPaent('Ctrl+C'));
process.on('SIGTERM', () => lukPaent('SIGTERM'));

start();

module.exports = { app, lukPaent };
