'use strict';

/**
 * server/config.js
 *
 * Central konfiguration for hele systemet.
 *
 * Rækkefølge: indbyggede standardværdier  ->  konfiguration.json  ->  miljøvariabler.
 * Ingen af dem er påkrævede. Systemet starter altid, også uden konfigurationsfil.
 */

const fs = require('fs');
const path = require('path');

const ROD = path.resolve(__dirname, '..');
const KONFIGURATIONSFIL = path.join(ROD, 'konfiguration.json');

/* -------------------------------------------------------------------------- */
/* Standardværdier                                                            */
/* -------------------------------------------------------------------------- */

const STANDARD = {
  // Netværk
  port: 3000,
  vaert: '0.0.0.0',

  // Tid
  tidszone: 'Europe/Copenhagen',
  lukketid: '21:00',

  // Backup
  automatiskBackupKlokken: '03:30',
  antalBackupsGemmes: 30,

  // Administratorsession
  sessionTimer: 8,
  maksLoginForsoeg: 5,
  spaerretidMinutter: 15,

  // Personaleskærmen
  sekunderFoerReturTilForside: 5,

  // Drift
  logNiveau: 'info'
};

/* -------------------------------------------------------------------------- */
/* Indlæsning af konfiguration.json                                           */
/* -------------------------------------------------------------------------- */

function laesKonfigurationsfil(sti) {
  if (!fs.existsSync(sti)) return {};

  try {
    const raa = fs.readFileSync(sti, 'utf8');
    const vaerdier = JSON.parse(raa);

    if (vaerdier === null || typeof vaerdier !== 'object' || Array.isArray(vaerdier)) {
      throw new Error('Filen skal indeholde et JSON-objekt.');
    }

    return vaerdier;
  } catch (fejl) {
    // En ødelagt konfigurationsfil må aldrig forhindre systemet i at starte.
    console.warn(
      `[konfiguration] Kunne ikke læse ${sti}: ${fejl.message}\n` +
      '[konfiguration] Fortsætter med standardværdier.'
    );
    return {};
  }
}

/* -------------------------------------------------------------------------- */
/* Miljøvariabler                                                             */
/* -------------------------------------------------------------------------- */

const MILJOENOEGLER = {
  TR_PORT: 'port',
  TR_VAERT: 'vaert',
  TR_TIDSZONE: 'tidszone',
  TR_LUKKETID: 'lukketid',
  TR_BACKUP_KLOKKEN: 'automatiskBackupKlokken',
  TR_BACKUP_ANTAL: 'antalBackupsGemmes',
  TR_SESSION_TIMER: 'sessionTimer',
  TR_MAKS_LOGINFORSOEG: 'maksLoginForsoeg',
  TR_SPAERRETID: 'spaerretidMinutter',
  TR_RETUR_SEKUNDER: 'sekunderFoerReturTilForside',
  TR_LOGNIVEAU: 'logNiveau'
};

function laesMiljoevariabler() {
  const vaerdier = {};

  for (const [noegle, felt] of Object.entries(MILJOENOEGLER)) {
    const raa = process.env[noegle];
    if (raa !== undefined && raa !== '') {
      vaerdier[felt] = raa;
    }
  }

  return vaerdier;
}

/* -------------------------------------------------------------------------- */
/* Validering                                                                 */
/* -------------------------------------------------------------------------- */

function fejl(besked) {
  throw new Error(`[konfiguration] ${besked}`);
}

function heltal(vaerdi, felt, mindst, hoejst) {
  const tal = Number.parseInt(String(vaerdi), 10);

  if (!Number.isInteger(tal)) {
    fejl(`"${felt}" skal være et helt tal. Modtog: ${JSON.stringify(vaerdi)}`);
  }
  if (tal < mindst || tal > hoejst) {
    fejl(`"${felt}" skal ligge mellem ${mindst} og ${hoejst}. Modtog: ${tal}`);
  }

  return tal;
}

function klokkeslaet(vaerdi, felt) {
  const tekst = String(vaerdi).trim();
  const traef = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(tekst);

  if (!traef) {
    fejl(`"${felt}" skal være et klokkeslæt i formatet tt:mm, f.eks. "21:00". Modtog: ${JSON.stringify(vaerdi)}`);
  }

  return {
    tekst,
    time: Number.parseInt(traef[1], 10),
    minut: Number.parseInt(traef[2], 10)
  };
}

function gyldigTidszone(vaerdi, felt) {
  const tekst = String(vaerdi).trim();

  try {
    new Intl.DateTimeFormat('da-DK', { timeZone: tekst });
  } catch (_ignoreret) {
    fejl(`"${felt}" er ikke en tidszone dette system kender. Modtog: ${JSON.stringify(vaerdi)}`);
  }

  return tekst;
}

function tekstVaerdi(vaerdi, felt, tilladte) {
  const tekst = String(vaerdi).trim().toLowerCase();

  if (!tilladte.includes(tekst)) {
    fejl(`"${felt}" skal være en af: ${tilladte.join(', ')}. Modtog: ${JSON.stringify(vaerdi)}`);
  }

  return tekst;
}

/* -------------------------------------------------------------------------- */
/* Sammensætning                                                              */
/* -------------------------------------------------------------------------- */

const raaVaerdier = Object.assign(
  {},
  STANDARD,
  laesKonfigurationsfil(KONFIGURATIONSFIL),
  laesMiljoevariabler()
);

const MAPPER = Object.freeze({
  rod: ROD,
  data: path.join(ROD, 'data'),
  backups: path.join(ROD, 'backups'),
  offentlig: path.join(ROD, 'public'),
  logfiler: path.join(ROD, 'logfiler')
});

const config = Object.freeze({
  // Netværk
  port: heltal(raaVaerdier.port, 'port', 1, 65535),
  vaert: String(raaVaerdier.vaert).trim(),

  // Tid
  tidszone: gyldigTidszone(raaVaerdier.tidszone, 'tidszone'),
  lukketid: Object.freeze(klokkeslaet(raaVaerdier.lukketid, 'lukketid')),

  // Backup
  automatiskBackupKlokken: Object.freeze(
    klokkeslaet(raaVaerdier.automatiskBackupKlokken, 'automatiskBackupKlokken')
  ),
  antalBackupsGemmes: heltal(raaVaerdier.antalBackupsGemmes, 'antalBackupsGemmes', 1, 3650),

  // Administratorsession
  sessionTimer: heltal(raaVaerdier.sessionTimer, 'sessionTimer', 1, 168),
  maksLoginForsoeg: heltal(raaVaerdier.maksLoginForsoeg, 'maksLoginForsoeg', 1, 100),
  spaerretidMinutter: heltal(raaVaerdier.spaerretidMinutter, 'spaerretidMinutter', 1, 1440),
  sessionCookieNavn: 'tr_admin_session',

  // Personaleskærmen
  sekunderFoerReturTilForside: heltal(
    raaVaerdier.sekunderFoerReturTilForside, 'sekunderFoerReturTilForside', 1, 120
  ),

  // Drift
  logNiveau: tekstVaerdi(raaVaerdier.logNiveau, 'logNiveau', ['fejl', 'advarsel', 'info', 'debug']),

  // Faste værdier - ændres kun i koden, med vilje
  madrabatProcent: 25,
  databasefil: path.join(MAPPER.data, 'tidsregistrering.db'),
  mapper: MAPPER,
  konfigurationsfil: KONFIGURATIONSFIL
});

/* -------------------------------------------------------------------------- */
/* Mapper oprettes ved indlæsning, så intet andet modul skal tænke over det    */
/* -------------------------------------------------------------------------- */

for (const sti of [MAPPER.data, MAPPER.backups, MAPPER.logfiler]) {
  try {
    fs.mkdirSync(sti, { recursive: true });
  } catch (opretFejl) {
    throw new Error(
      `[konfiguration] Kunne ikke oprette mappen ${sti}: ${opretFejl.message}\n` +
      'Kontrollér at brugeren har skriveadgang til projektmappen.'
    );
  }
}

module.exports = config;
