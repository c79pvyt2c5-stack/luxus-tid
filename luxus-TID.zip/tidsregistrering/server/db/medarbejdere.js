'use strict';

/**
 * server/db/medarbejdere.js
 *
 * Medarbejderne. Forsiden på personaleskærmen henter sin liste her, og
 * Administration opretter, retter, deaktiverer og sletter herfra.
 *
 * Om sletning: kravdokumentet siger både at administrator skal kunne slette
 * medarbejdere, og at ingen timer må forsvinde. Det kan ikke begge være sandt.
 * Løsningen er:
 *
 *   - Findes der registreringer, kan medarbejderen ikke slettes. I stedet
 *     tilbydes deaktivering: navnet forsvinder fra personaleskærmen, mens
 *     timerne bliver stående i kalenderen, statistikken og PDF-udskrifterne.
 *   - Er medarbejderen nyoprettet og har ingen registreringer - typisk en
 *     stavefejl - slettes rækken helt.
 *
 * Databasen håndhæver det samme med ON DELETE RESTRICT, så en fejl i koden
 * heller ikke kan tage timerne med sig.
 */

const { forbered, iTransaktion } = require('./database');
const revision = require('./revision');
const tid = require('../lib/tid');
const { IkkeFundet, Konflikt, kraevTekst, kraevHeltal } = require('../lib/fejl');

const FELTER = `
  id, navn, sorteringsnummer, aktiv, noter,
  oprettet_tid, sidst_aendret_tid, deaktiveret_tid
`;

/* -------------------------------------------------------------------------- */
/* Læsning                                                                    */
/* -------------------------------------------------------------------------- */

function pynt(raekke) {
  if (!raekke) return null;

  return {
    id: raekke.id,
    navn: raekke.navn,
    sorteringsnummer: raekke.sorteringsnummer,
    aktiv: raekke.aktiv === 1,
    noter: raekke.noter,
    oprettetTid: raekke.oprettet_tid,
    sidstAendretTid: raekke.sidst_aendret_tid,
    deaktiveretTid: raekke.deaktiveret_tid
  };
}

/** Én medarbejder. Kaster IkkeFundet hvis id'et ikke findes. */
function hent(id) {
  const nummer = kraevHeltal(id, 'Medarbejder-id', { mindst: 1 });
  const raekke = forbered(`SELECT ${FELTER} FROM medarbejdere WHERE id = ?`).get(nummer);

  if (!raekke) {
    throw new IkkeFundet('Medarbejderen findes ikke. Den er måske slettet fra et andet vindue.');
  }

  return pynt(raekke);
}

/** Findes medarbejderen, og er den aktiv? Bruges før check ind. */
function hentAktiv(id) {
  const medarbejder = hent(id);

  if (!medarbejder.aktiv) {
    throw new Konflikt(
      'Medarbejderen er deaktiveret og kan ikke registrere tid. Kontakt den ansvarlige.',
      'medarbejder_deaktiveret'
    );
  }

  return medarbejder;
}

/**
 * Listen til personaleskærmens forside: kun aktive, i den rækkefølge de
 * skal stå i, og med oplysning om hvem der er checket ind lige nu - så
 * skærmen kan vise det uden et ekstra kald.
 */
function hentTilForside() {
  return forbered(`
    SELECT
      m.id,
      m.navn,
      m.sorteringsnummer,
      v.check_ind_tid AS check_ind_tid,
      v.registrering_id AS registrering_id
    FROM medarbejdere m
    LEFT JOIN v_checket_ind_nu v ON v.medarbejder_id = m.id
    WHERE m.aktiv = 1
    ORDER BY m.sorteringsnummer, m.navn COLLATE NOCASE
  `).all().map((r) => ({
    id: r.id,
    navn: r.navn,
    sorteringsnummer: r.sorteringsnummer,
    erCheketInd: r.check_ind_tid !== null,
    registreringId: r.registrering_id,
    checkIndTid: r.check_ind_tid,
    checkIndKlokkeslaet: r.check_ind_tid ? tid.klokkeslaet(r.check_ind_tid) : null
  }));
}

/**
 * Alle medarbejdere til Administration.
 * @param {object} [valg]
 * @param {boolean} [valg.medInaktive=true]
 * @param {string} [valg.soegetekst]
 */
function hentAlle(valg = {}) {
  const { medInaktive = true, soegetekst = null } = valg;

  const betingelser = [];
  const vaerdier = [];

  if (!medInaktive) betingelser.push('aktiv = 1');

  if (soegetekst && String(soegetekst).trim() !== '') {
    vaerdier.push(`%${String(soegetekst).trim()}%`);
    betingelser.push('navn LIKE ? COLLATE NOCASE');
  }

  const hvor = betingelser.length > 0 ? `WHERE ${betingelser.join(' AND ')}` : '';

  return forbered(`
    SELECT ${FELTER} FROM medarbejdere
    ${hvor}
    ORDER BY aktiv DESC, sorteringsnummer, navn COLLATE NOCASE
  `).all(...vaerdier).map(pynt);
}

/** Hvor meget data hænger der på medarbejderen? Afgør om sletning er mulig. */
function optaelling(id) {
  const nummer = kraevHeltal(id, 'Medarbejder-id', { mindst: 1 });

  const registreringer = forbered(
    'SELECT COUNT(*) AS antal FROM registreringer WHERE medarbejder_id = ?'
  ).get(nummer).antal;

  const madregistreringer = forbered(
    'SELECT COUNT(*) AS antal FROM madregistreringer WHERE medarbejder_id = ?'
  ).get(nummer).antal;

  return {
    registreringer,
    madregistreringer,
    harData: registreringer > 0 || madregistreringer > 0
  };
}

/* -------------------------------------------------------------------------- */
/* Oprettelse og rettelse                                                     */
/* -------------------------------------------------------------------------- */

/** Næste ledige plads i rækkefølgen, så nye navne lander nederst. */
function naesteSorteringsnummer() {
  const svar = forbered(
    'SELECT COALESCE(MAX(sorteringsnummer), 0) + 10 AS naeste FROM medarbejdere'
  ).get();
  return svar.naeste;
}

/**
 * Opretter en medarbejder.
 * @param {{navn:string, sorteringsnummer?:number, noter?:string}} oplysninger
 * @param {{id:?number, navn:string}} administrator
 */
function opret(oplysninger, administrator) {
  const navn = kraevTekst(oplysninger.navn, 'Navn', { mindst: 1, hoejst: 60 });
  const noter = kraevTekst(oplysninger.noter, 'Note', { hoejst: 500, paakraevet: false });

  const sortering = oplysninger.sorteringsnummer === undefined
    || oplysninger.sorteringsnummer === null
    || oplysninger.sorteringsnummer === ''
    ? null
    : kraevHeltal(oplysninger.sorteringsnummer, 'Rækkefølge', { mindst: 0, hoejst: 100000 });

  return iTransaktion(() => {
    const resultat = forbered(`
      INSERT INTO medarbejdere (navn, sorteringsnummer, noter, oprettet_tid)
      VALUES (@navn, @sortering, @noter, @tid)
    `).run({
      navn,
      sortering: sortering === null ? naesteSorteringsnummer() : sortering,
      noter,
      tid: tid.tilISO(tid.nu())
    });

    const id = Number(resultat.lastInsertRowid);

    revision.skriv({
      administrator,
      handling: 'opret',
      tabel: 'medarbejdere',
      postId: id,
      medarbejderId: id,
      felt: 'navn',
      ny: navn
    });

    return hent(id);
  });
}

/**
 * Retter navn, rækkefølge eller note. Kun felter der sendes med, ændres.
 * @returns {{medarbejder:object, antalAendringer:number}}
 */
function opdater(id, aendringer, administrator, begrundelse = null) {
  const foer = hent(id);
  const nye = {};

  if (aendringer.navn !== undefined) {
    nye.navn = kraevTekst(aendringer.navn, 'Navn', { mindst: 1, hoejst: 60 });
  }
  if (aendringer.sorteringsnummer !== undefined) {
    nye.sorteringsnummer = kraevHeltal(
      aendringer.sorteringsnummer, 'Rækkefølge', { mindst: 0, hoejst: 100000 }
    );
  }
  if (aendringer.noter !== undefined) {
    nye.noter = kraevTekst(aendringer.noter, 'Note', { hoejst: 500, paakraevet: false });
  }

  if (Object.keys(nye).length === 0) {
    return { medarbejder: foer, antalAendringer: 0 };
  }

  return iTransaktion(() => {
    const saet = Object.keys(nye).map((felt) => `${felt} = @${felt}`).join(', ');

    forbered(`
      UPDATE medarbejdere SET ${saet}, sidst_aendret_tid = @tid WHERE id = @id
    `).run({ ...nye, id: foer.id, tid: tid.tilISO(tid.nu()) });

    const antalAendringer = revision.skrivAendringer({
      administrator,
      handling: 'ret',
      tabel: 'medarbejdere',
      postId: foer.id,
      medarbejderId: foer.id,
      begrundelse,
      foer: {
        navn: foer.navn,
        sorteringsnummer: foer.sorteringsnummer,
        noter: foer.noter
      },
      efter: nye
    });

    return { medarbejder: hent(foer.id), antalAendringer };
  });
}

/* -------------------------------------------------------------------------- */
/* Aktivering og deaktivering                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Slår en medarbejder til eller fra. Deaktivering fjerner navnet fra
 * personaleskærmen, men rører ikke timerne.
 */
function saetAktiv(id, aktiv, administrator, begrundelse = null) {
  const foer = hent(id);
  const nyTilstand = aktiv ? 1 : 0;

  if ((foer.aktiv ? 1 : 0) === nyTilstand) {
    return { medarbejder: foer, aendret: false };
  }

  return iTransaktion(() => {
    const nu = tid.tilISO(tid.nu());

    // En medarbejder der deaktiveres midt i en vagt beholder sin åbne
    // registrering. Det automatiske check ud kl. 21:00 lukker den, så
    // timerne op til deaktiveringen ikke går tabt.
    forbered(`
      UPDATE medarbejdere
      SET aktiv = @aktiv,
          deaktiveret_tid = CASE WHEN @aktiv = 0 THEN @nu ELSE NULL END,
          sidst_aendret_tid = @nu
      WHERE id = @id
    `).run({ aktiv: nyTilstand, nu, id: foer.id });

    revision.skriv({
      administrator,
      handling: nyTilstand === 1 ? 'aktiver' : 'deaktiver',
      tabel: 'medarbejdere',
      postId: foer.id,
      medarbejderId: foer.id,
      felt: 'aktiv',
      gammel: foer.aktiv,
      ny: nyTilstand === 1,
      begrundelse
    });

    return { medarbejder: hent(foer.id), aendret: true };
  });
}

/* -------------------------------------------------------------------------- */
/* Sletning                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Sletter en medarbejder - men kun hvis der ikke findes registreringer.
 * Ellers kastes en Konflikt med en forklaring der peger på deaktivering.
 */
function slet(id, administrator, begrundelse = null) {
  const medarbejder = hent(id);
  const tal = optaelling(medarbejder.id);

  if (tal.harData) {
    const dele = [];
    if (tal.registreringer > 0) {
      dele.push(`${tal.registreringer} ${tal.registreringer === 1 ? 'tidsregistrering' : 'tidsregistreringer'}`);
    }
    if (tal.madregistreringer > 0) {
      dele.push(`${tal.madregistreringer} ${tal.madregistreringer === 1 ? 'madregistrering' : 'madregistreringer'}`);
    }

    throw new Konflikt(
      `${medarbejder.navn} kan ikke slettes, fordi der findes ${dele.join(' og ')}. `
      + 'Deaktivér i stedet: navnet forsvinder fra personaleskærmen, og timerne bliver bevaret.',
      'har_registreringer',
      {
        medarbejderId: medarbejder.id,
        registreringer: tal.registreringer,
        madregistreringer: tal.madregistreringer,
        foreslaaetHandling: 'deaktiver'
      }
    );
  }

  return iTransaktion(() => {
    revision.skriv({
      administrator,
      handling: 'slet',
      tabel: 'medarbejdere',
      postId: medarbejder.id,
      medarbejderId: medarbejder.id,
      felt: 'navn',
      gammel: medarbejder.navn,
      begrundelse
    });

    forbered('DELETE FROM medarbejdere WHERE id = ?').run(medarbejder.id);

    return { slettet: true, navn: medarbejder.navn };
  });
}

module.exports = {
  hent,
  hentAktiv,
  hentTilForside,
  hentAlle,
  optaelling,
  opret,
  opdater,
  saetAktiv,
  slet
};
