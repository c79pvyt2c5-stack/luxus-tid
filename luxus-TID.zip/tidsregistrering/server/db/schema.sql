-- =============================================================================
--  server/db/schema.sql
--  Databasedesign - version 1
--
--  Konventioner:
--    * Tidsstempler gemmes som ISO 8601 i UTC:  '2026-07-26T18:45:12.000Z'
--      Serveren regner altid om til Europe/Copenhagen ved visning.
--      Derved overlever data sommertidsskift og en eventuel flytning af Mac'en.
--    * "dato" er den danske lokale kalenderdato som tekst: 'YYYY-MM-DD'.
--      Den gemmes særskilt, så en arbejdsdag altid hører til den dag
--      medarbejderen selv oplevede - uafhængigt af UTC-forskydningen.
--    * Beløb gemmes som hele ører (INTEGER). Aldrig kommatal.
--    * 0/1 bruges som falsk/sand, håndhævet med CHECK.
-- =============================================================================

PRAGMA foreign_keys = ON;


-- -----------------------------------------------------------------------------
--  Administratorer
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS administratorer (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  brugernavn         TEXT    NOT NULL UNIQUE,
  navn               TEXT    NOT NULL,
  kodeord_hash       TEXT    NOT NULL,
  aktiv              INTEGER NOT NULL DEFAULT 1 CHECK (aktiv IN (0, 1)),
  oprettet_tid       TEXT    NOT NULL,
  sidst_aendret_tid  TEXT,
  sidste_login_tid   TEXT,

  CHECK (length(trim(brugernavn)) >= 3),
  CHECK (length(trim(navn)) >= 1)
);


-- -----------------------------------------------------------------------------
--  Administratorsessioner
--  Nøglen er et hash af sessionstokenet - selve tokenet gemmes aldrig,
--  så en stjålet databasefil ikke giver adgang til systemet.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_sessioner (
  token_hash        TEXT    PRIMARY KEY,
  administrator_id  INTEGER NOT NULL REFERENCES administratorer(id) ON DELETE CASCADE,
  oprettet_tid      TEXT    NOT NULL,
  udloeber_tid      TEXT    NOT NULL,
  sidst_brugt_tid   TEXT    NOT NULL,
  ip                TEXT,
  browser           TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessioner_udloeber
  ON admin_sessioner (udloeber_tid);


-- -----------------------------------------------------------------------------
--  Loginforsøg - grundlag for midlertidig spærring efter gentagne fejl
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_forsoeg (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  brugernavn  TEXT    NOT NULL,
  ip          TEXT,
  lykkedes    INTEGER NOT NULL CHECK (lykkedes IN (0, 1)),
  tidspunkt   TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_loginforsoeg_opslag
  ON login_forsoeg (brugernavn, tidspunkt);


-- -----------------------------------------------------------------------------
--  Medarbejdere
--  Slettes normalt ikke - de deaktiveres, så historikken bevares.
--  ON DELETE RESTRICT nedenfor gør det umuligt at slette en medarbejder,
--  der har registreringer. Det er den vigtigste enkelte spærring i databasen.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS medarbejdere (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  navn               TEXT    NOT NULL,
  sorteringsnummer   INTEGER NOT NULL DEFAULT 0,
  aktiv              INTEGER NOT NULL DEFAULT 1 CHECK (aktiv IN (0, 1)),
  noter              TEXT,
  oprettet_tid       TEXT    NOT NULL,
  sidst_aendret_tid  TEXT,
  deaktiveret_tid    TEXT,

  CHECK (length(trim(navn)) >= 1)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_medarbejdere_navn
  ON medarbejdere (navn COLLATE NOCASE);

CREATE INDEX IF NOT EXISTS idx_medarbejdere_forside
  ON medarbejdere (aktiv, sorteringsnummer, navn COLLATE NOCASE);


-- -----------------------------------------------------------------------------
--  Registreringer - én række pr. check ind
--  check_ud_tid er NULL så længe medarbejderen er checket ind.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS registreringer (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  medarbejder_id         INTEGER NOT NULL REFERENCES medarbejdere(id) ON DELETE RESTRICT,
  dato                   TEXT    NOT NULL,
  check_ind_tid          TEXT    NOT NULL,
  check_ud_tid           TEXT,
  sekunder               INTEGER,
  afsluttet_automatisk   INTEGER NOT NULL DEFAULT 0 CHECK (afsluttet_automatisk IN (0, 1)),
  rettet_af_admin        INTEGER NOT NULL DEFAULT 0 CHECK (rettet_af_admin IN (0, 1)),
  kommentar              TEXT,
  oprettet_tid           TEXT    NOT NULL,
  sidst_aendret_tid      TEXT,

  -- Datoformat 'YYYY-MM-DD'
  CHECK (dato GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  -- Sluttid kan ikke ligge før starttid
  CHECK (check_ud_tid IS NULL OR check_ud_tid > check_ind_tid),
  -- Varighed findes præcis når registreringen er lukket, og kun da
  CHECK (
    (check_ud_tid IS NULL AND sekunder IS NULL) OR
    (check_ud_tid IS NOT NULL AND sekunder IS NOT NULL AND sekunder >= 0)
  )
);

-- Én medarbejder kan højst have én åben registrering ad gangen.
-- Dobbelttryk på "Check ind" kan dermed ikke skabe en spøgelsesregistrering.
CREATE UNIQUE INDEX IF NOT EXISTS idx_registrering_kun_en_aaben
  ON registreringer (medarbejder_id)
  WHERE check_ud_tid IS NULL;

CREATE INDEX IF NOT EXISTS idx_registrering_medarbejder_dato
  ON registreringer (medarbejder_id, dato);

CREATE INDEX IF NOT EXISTS idx_registrering_dato
  ON registreringer (dato);


-- -----------------------------------------------------------------------------
--  Madregistreringer - højst én pr. medarbejder pr. dag
--  Pris og rabat gemmes som de var på registreringstidspunktet, så en senere
--  prisændring ikke ændrer gamle måneders regnskab.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS madregistreringer (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  medarbejder_id   INTEGER NOT NULL REFERENCES medarbejdere(id) ON DELETE RESTRICT,
  dato             TEXT    NOT NULL,
  tidspunkt        TEXT    NOT NULL,
  normalpris_oere  INTEGER NOT NULL CHECK (normalpris_oere >= 0),
  rabat_procent    INTEGER NOT NULL CHECK (rabat_procent BETWEEN 0 AND 100),
  pris_oere        INTEGER NOT NULL CHECK (pris_oere >= 0),
  registreret_af   TEXT    NOT NULL CHECK (registreret_af IN ('medarbejder', 'administrator')),
  kommentar        TEXT,

  CHECK (dato GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  CHECK (pris_oere <= normalpris_oere)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_mad_en_pr_dag
  ON madregistreringer (medarbejder_id, dato);

CREATE INDEX IF NOT EXISTS idx_mad_dato
  ON madregistreringer (dato);


-- -----------------------------------------------------------------------------
--  Indstillinger - værdier administratoren kan ændre under drift
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS indstillinger (
  noegle          TEXT PRIMARY KEY,
  vaerdi          TEXT NOT NULL,
  beskrivelse     TEXT,
  opdateret_tid   TEXT,
  opdateret_af    TEXT
);

INSERT OR IGNORE INTO indstillinger (noegle, vaerdi, beskrivelse) VALUES
  ('madpris_normal_oere', '8000',           'Normalprisen for et måltid, i ører. 8000 = 80,00 kr.'),
  ('virksomhedsnavn',     'Restauranten',   'Navnet der står øverst på PDF-udskrifter.'),
  ('pdf_fodnote',         '',               'Valgfri tekst nederst på PDF-udskrifter.');


-- -----------------------------------------------------------------------------
--  Ændringslog - kun synlig for administrator
--  Hver rettelse gemmes felt for felt med gammel og ny værdi.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS aendringslog (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  tidspunkt           TEXT    NOT NULL,
  administrator_id    INTEGER REFERENCES administratorer(id) ON DELETE SET NULL,
  administrator_navn  TEXT    NOT NULL,
  handling            TEXT    NOT NULL CHECK (handling IN (
                                'opret', 'ret', 'slet', 'aktiver', 'deaktiver',
                                'indstilling', 'backup', 'gendan'
                              )),
  tabel               TEXT    NOT NULL,
  post_id             INTEGER,
  medarbejder_id      INTEGER,
  felt                TEXT,
  gammel_vaerdi       TEXT,
  ny_vaerdi           TEXT,
  begrundelse         TEXT
);

CREATE INDEX IF NOT EXISTS idx_aendringslog_tid
  ON aendringslog (tidspunkt);

CREATE INDEX IF NOT EXISTS idx_aendringslog_post
  ON aendringslog (tabel, post_id);


-- -----------------------------------------------------------------------------
--  Backuplog
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS backuplog (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  tidspunkt         TEXT    NOT NULL,
  filnavn           TEXT    NOT NULL,
  stoerrelse_bytes  INTEGER,
  type              TEXT    NOT NULL CHECK (type IN ('automatisk', 'manuel', 'foer_gendannelse')),
  status            TEXT    NOT NULL CHECK (status IN ('ok', 'fejl')),
  fejlbesked        TEXT
);

CREATE INDEX IF NOT EXISTS idx_backuplog_tid
  ON backuplog (tidspunkt);


-- -----------------------------------------------------------------------------
--  Hvem er checket ind lige nu - bruges af Administration -> Statistik
-- -----------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_checket_ind_nu AS
SELECT
  r.id              AS registrering_id,
  r.medarbejder_id  AS medarbejder_id,
  m.navn            AS navn,
  r.dato            AS dato,
  r.check_ind_tid   AS check_ind_tid
FROM registreringer r
JOIN medarbejdere m ON m.id = r.medarbejder_id
WHERE r.check_ud_tid IS NULL;
