'use strict';

/**
 * server/db/registreringer.js
 *
 * Kernen i systemet: check ind, check ud, og alle timeopgørelser.
 *
 * Grundregler:
 *   - En medarbejder har højst én åben registrering. Databasen håndhæver det.
 *   - Varigheden gemmes i sekunder, beregnet på faktiske UTC-tidspunkter.
 *   - En åben registrering har sekunder = NULL. Den tæller derfor ikke med i
 *     summerne som en nulværdi, men lægges til særskilt som "løbende tid".
 *   - Ingen registrering slettes af systemet selv. Nogensinde.
 */

const config = require('../config');
const { forbered, iTransaktion } = require('./database');
const medarbejdere = require('./medarbejdere');
const revision = require('./revision');
const tid = require('../lib/tid');
const {
  IkkeFundet, Konflikt, Valideringsfejl, kraevTekst, kraevHeltal
} = require('../lib/fejl');

const FELTER = `
  id, medarbejder_id, dato, check_ind_tid, check_ud_tid, sekunder,
  afsluttet_automatisk, rettet_af_admin, kommentar, oprettet_tid, sidst_aendret_tid
`;

/* -------------------------------------------------------------------------- */
/* Visning                                                                    */
/* -------------------------------------------------------------------------- */

function pynt(raekke) {
  if (!raekke) return null;

  const aaben = raekke.check_ud_tid === null;

  return {
    id: raekke.id,
    medarbejderId: raekke.medarbejder_id,
    dato: raekke.dato,
    datoDansk: tid.datoDansk(raekke.dato),
    ugedag: tid.ugedagsnavn(raekke.dato),
    checkIndTid: raekke.check_ind_tid,
    checkUdTid: raekke.check_ud_tid,
    checkInd: tid.klokkeslaet(raekke.check_ind_tid),
    checkUd: aaben ? null : tid.klokkeslaet(raekke.check_ud_tid),
    aaben,
    sekunder: raekke.sekunder,
    varighed: aaben ? null : tid.varighed(raekke.sekunder),
    timer: aaben ? null : tid.timerDecimal(raekke.sekunder),
    afsluttetAutomatisk: raekke.afsluttet_automatisk === 1,
    rettetAfAdmin: raekke.rettet_af_admin === 1,
    kommentar: raekke.kommentar
  };
}

/* -------------------------------------------------------------------------- */
/* Opslag                                                                     */
/* -------------------------------------------------------------------------- */

function hent(id) {
  const nummer = kraevHeltal(id, 'Registrerings-id', { mindst: 1 });
  const raekke = forbered(`SELECT ${FELTER} FROM registreringer WHERE id = ?`).get(nummer);

  if (!raekke) throw new IkkeFundet('Registreringen findes ikke.');

  return pynt(raekke);
}

/** Den åbne registrering for en medarbejder, eller null. */
function aktiv(medarbejderId) {
  const raekke = forbered(`
    SELECT ${FELTER} FROM registreringer
    WHERE medarbejder_id = ? AND check_ud_tid IS NULL
  `).get(kraevHeltal(medarbejderId, 'Medarbejder-id', { mindst: 1 }));

  return pynt(raekke);
}

/** Alle der er checket ind lige nu. Bruges af Administration. */
function checketIndNu() {
  const nu = tid.nu();

  return forbered(`
    SELECT registrering_id, medarbejder_id, navn, dato, check_ind_tid
    FROM v_checket_ind_nu
    ORDER BY check_ind_tid
  `).all().map((r) => {
    const sekunder = Math.max(0, Math.round((nu - tid.fraISO(r.check_ind_tid)) / 1000));

    return {
      registreringId: r.registrering_id,
      medarbejderId: r.medarbejder_id,
      navn: r.navn,
      dato: r.dato,
      datoDansk: tid.datoDansk(r.dato),
      checkIndTid: r.check_ind_tid,
      checkInd: tid.klokkeslaet(r.check_ind_tid),
      sekunderIndtilNu: sekunder,
      varighedIndtilNu: tid.varighed(sekunder)
    };
  });
}

/* -------------------------------------------------------------------------- */
/* Check ind og check ud                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Registrerer at medarbejderen møder ind. Tidspunktet er serverens ur.
 * @returns {{registrering:object, medarbejder:object}}
 */
function checkInd(medarbejderId) {
  const medarbejder = medarbejdere.hentAktiv(medarbejderId);

  return iTransaktion(() => {
    const aabenNu = aktiv(medarbejder.id);

    if (aabenNu) {
      throw new Konflikt(
        `Du er allerede checket ind kl. ${aabenNu.checkInd}. Tryk på Check ud, når du går hjem.`,
        'allerede_checket_ind',
        { registreringId: aabenNu.id, checkInd: aabenNu.checkInd }
      );
    }

    const nu = tid.nu();
    const isoNu = tid.tilISO(nu);

    const resultat = forbered(`
      INSERT INTO registreringer (medarbejder_id, dato, check_ind_tid, oprettet_tid)
      VALUES (@medarbejderId, @dato, @nu, @nu)
    `).run({ medarbejderId: medarbejder.id, dato: tid.lokalDato(nu), nu: isoNu });

    return {
      registrering: hent(Number(resultat.lastInsertRowid)),
      medarbejder
    };
  });
}

/**
 * Registrerer at medarbejderen går hjem, og beregner dagens varighed.
 * @returns {{registrering:object, medarbejder:object}}
 */
function checkUd(medarbejderId) {
  const medarbejder = medarbejdere.hent(medarbejderId);

  return iTransaktion(() => {
    const aabenNu = aktiv(medarbejder.id);

    if (!aabenNu) {
      throw new Konflikt(
        'Du er ikke checket ind. Tryk på Check ind, når du møder.',
        'ikke_checket_ind'
      );
    }

    const nu = tid.nu();
    const sekunder = tid.sekunderMellem(aabenNu.checkIndTid, tid.tilISO(nu));

    forbered(`
      UPDATE registreringer
      SET check_ud_tid = @slut, sekunder = @sekunder, sidst_aendret_tid = @slut
      WHERE id = @id
    `).run({ slut: tid.tilISO(nu), sekunder, id: aabenNu.id });

    return {
      registrering: hent(aabenNu.id),
      medarbejder
    };
  });
}

/* -------------------------------------------------------------------------- */
/* Automatisk check ud ved lukketid                                           */
/* -------------------------------------------------------------------------- */

/**
 * Lukker registreringer der stadig står åbne efter lukketid.
 *
 * Sluttiden sættes til lukketiden på registreringens egen dato - ikke til
 * det tidspunkt hvor funktionen tilfældigvis kører. Har serveren været
 * slukket i tre dage, får en glemt registrering fra mandag derfor stadig
 * sluttid mandag kl. 21:00, ikke torsdag.
 *
 * Er der checket ind EFTER lukketid, f.eks. kl. 21:30 til oprydning, bruges
 * den næste lukketid i stedet. Registreringen bliver lang og markeres som
 * automatisk afsluttet, så administrator kan rette den - frem for at
 * systemet gætter på en varighed.
 *
 * @returns {Array<object>} De registreringer der blev lukket.
 */
function automatiskCheckUd(nu = tid.nu()) {
  const aabne = forbered(`
    SELECT ${FELTER} FROM registreringer WHERE check_ud_tid IS NULL ORDER BY check_ind_tid
  `).all().map(pynt);

  const lukkede = [];

  for (const registrering of aabne) {
    let sluttid = tid.lukketidPaaDato(registrering.dato);

    // Checket ind efter lukketid: brug næste dags lukketid
    if (sluttid.getTime() <= tid.fraISO(registrering.checkIndTid).getTime()) {
      sluttid = tid.lukketidPaaDato(tid.laegDageTil(registrering.dato, 1));
    }

    if (sluttid.getTime() > nu.getTime()) continue; // lukketiden er ikke nået endnu

    const isoSlut = tid.tilISO(sluttid);
    const sekunder = tid.sekunderMellem(registrering.checkIndTid, isoSlut);

    iTransaktion(() => {
      forbered(`
        UPDATE registreringer
        SET check_ud_tid = @slut,
            sekunder = @sekunder,
            afsluttet_automatisk = 1,
            sidst_aendret_tid = @nu
        WHERE id = @id AND check_ud_tid IS NULL
      `).run({
        slut: isoSlut,
        sekunder,
        nu: tid.tilISO(nu),
        id: registrering.id
      });

      revision.skriv({
        handling: 'ret',
        tabel: 'registreringer',
        postId: registrering.id,
        medarbejderId: registrering.medarbejderId,
        felt: 'check_ud_tid',
        gammel: null,
        ny: isoSlut,
        begrundelse: `Automatisk check ud ved lukketid kl. ${config.lukketid.tekst}`
      });
    });

    lukkede.push(hent(registrering.id));
  }

  return lukkede;
}

/* -------------------------------------------------------------------------- */
/* Opgørelser                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Summerer afsluttede registreringer i en periode.
 * @returns {{sekunder:number, antal:number, dage:number}}
 */
function sumFor(medarbejderId, fra, til) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  const svar = forbered(`
    SELECT
      COALESCE(SUM(sekunder), 0) AS sekunder,
      COUNT(*) AS antal,
      COUNT(DISTINCT dato) AS dage
    FROM registreringer
    WHERE medarbejder_id = ? AND dato BETWEEN ? AND ? AND check_ud_tid IS NOT NULL
  `).get(Number(medarbejderId), fra, til);

  return { sekunder: svar.sekunder, antal: svar.antal, dage: svar.dage };
}

/** Den løbende tid på en åben registrering, i sekunder. Nul hvis ingen. */
function loebendeSekunder(medarbejderId, nu = tid.nu()) {
  const aabenNu = aktiv(medarbejderId);
  if (!aabenNu) return 0;

  return Math.max(0, Math.round((nu - tid.fraISO(aabenNu.checkIndTid)) / 1000));
}

/**
 * Alle tallene medarbejdersiden skal vise: i dag, denne uge, denne måned,
 * dette år og samlet. Den åbne registrering lægges til i dag og i alle
 * perioder der indeholder dagens dato, så tallene ikke springer ved check ud.
 */
function oversigt(medarbejderId, nu = tid.nu()) {
  const id = kraevHeltal(medarbejderId, 'Medarbejder-id', { mindst: 1 });
  const iDag = tid.lokalDato(nu);

  const uge = tid.ugeInterval(iDag);
  const maaned = tid.maanedInterval(iDag);
  const aar = tid.aarInterval(iDag);

  const loebende = loebendeSekunder(id, nu);

  const samlet = forbered(`
    SELECT COALESCE(SUM(sekunder), 0) AS sekunder, COUNT(DISTINCT dato) AS dage
    FROM registreringer
    WHERE medarbejder_id = ? AND check_ud_tid IS NOT NULL
  `).get(id);

  const byg = (navn, interval, ekstra) => {
    const sum = sumFor(id, interval.fra, interval.til);
    const sekunder = sum.sekunder + ekstra;

    return {
      periode: navn,
      fra: interval.fra,
      til: interval.til,
      sekunder,
      varighed: tid.varighed(sekunder),
      timer: tid.timerDecimal(sekunder),
      antalRegistreringer: sum.antal,
      antalDage: sum.dage
    };
  };

  return {
    medarbejderId: id,
    dato: iDag,
    datoDansk: tid.datoDansk(iDag),
    ugenummer: tid.ugenummer(iDag).uge,
    loebendeSekunder: loebende,
    iDag: byg('dag', tid.dagInterval(iDag), loebende),
    denneUge: byg('uge', uge, loebende),
    denneMaaned: byg('maaned', maaned, loebende),
    detteAar: byg('aar', aar, loebende),
    samlet: {
      periode: 'samlet',
      sekunder: samlet.sekunder + loebende,
      varighed: tid.varighed(samlet.sekunder + loebende),
      timer: tid.timerDecimal(samlet.sekunder + loebende),
      antalDage: samlet.dage
    }
  };
}

/** Status til personaleskærmen: skal der vises Check ind eller Check ud? */
function status(medarbejderId, nu = tid.nu()) {
  const medarbejder = medarbejdere.hent(medarbejderId);
  const aabenNu = aktiv(medarbejder.id);
  const tal = oversigt(medarbejder.id, nu);

  return {
    medarbejder,
    erCheketInd: Boolean(aabenNu),
    aktivRegistrering: aabenNu,
    serverTid: tid.tilISO(nu),
    oversigt: tal
  };
}

/* -------------------------------------------------------------------------- */
/* Kalender                                                                   */
/* -------------------------------------------------------------------------- */

/** Alle registreringer i en periode, ældste først. */
function hentPeriode(medarbejderId, fra, til) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  return forbered(`
    SELECT ${FELTER} FROM registreringer
    WHERE medarbejder_id = ? AND dato BETWEEN ? AND ?
    ORDER BY dato, check_ind_tid
  `).all(Number(medarbejderId), fra, til).map(pynt);
}

/**
 * Én linje pr. dag med timer - grundlaget for kalendervisningen.
 * Dage uden registrering udelades, så frontenden selv kan tegne tomme felter.
 */
function dagssummer(medarbejderId, fra, til) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  return forbered(`
    SELECT
      dato,
      COALESCE(SUM(sekunder), 0) AS sekunder,
      COUNT(*) AS antal,
      SUM(CASE WHEN check_ud_tid IS NULL THEN 1 ELSE 0 END) AS aabne
    FROM registreringer
    WHERE medarbejder_id = ? AND dato BETWEEN ? AND ?
    GROUP BY dato
    ORDER BY dato
  `).all(Number(medarbejderId), fra, til).map((r) => ({
    dato: r.dato,
    datoDansk: tid.datoDansk(r.dato),
    ugedag: tid.ugedagsnavn(r.dato),
    sekunder: r.sekunder,
    varighed: tid.varighed(r.sekunder),
    timer: tid.timerDecimal(r.sekunder),
    antalRegistreringer: r.antal,
    harAabenRegistrering: r.aabne > 0
  }));
}

/**
 * Alt om én dato: registreringer og dagens sum.
 *
 * @param {object} [valg]
 * @param {boolean} [valg.medAdminfelter=true] Sæt false for medarbejdersiden.
 *        Så fjernes oplysningen om at en tid er rettet eller lukket automatisk,
 *        allerede i svaret - ikke bare i visningen.
 */
function hentDag(medarbejderId, dato, valg = {}) {
  tid.kraevGyldigDato(dato, 'Dato');

  let raekker = hentPeriode(medarbejderId, dato, dato);

  if (valg.medAdminfelter === false) {
    raekker = raekker.map((r) => {
      const { afsluttetAutomatisk, rettetAfAdmin, ...resten } = r;
      return resten;
    });
  }
  const sekunder = raekker.reduce((sum, r) => sum + (r.sekunder || 0), 0);

  return {
    dato,
    datoDansk: tid.datoDansk(dato),
    datoLang: tid.datoLang(dato),
    ugedag: tid.ugedagsnavn(dato),
    registreringer: raekker,
    sekunder,
    varighed: tid.varighed(sekunder),
    timer: tid.timerDecimal(sekunder)
  };
}

/* -------------------------------------------------------------------------- */
/* Administratorens rettelser                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Retter en registrering. Kun de felter der sendes med, ændres.
 *
 * @param {number} id
 * @param {{dato?:string, checkInd?:string, checkUd?:string|null, kommentar?:string}} aendringer
 *        checkInd og checkUd angives som dansk klokkeslæt, f.eks. '08:00'.
 *        checkUd = null gør registreringen åben igen.
 * @param {{id:?number, navn:string}} administrator
 * @param {string} [begrundelse]
 */
function opdater(id, aendringer, administrator, begrundelse = null) {
  const foer = hent(id);

  const nyDato = aendringer.dato === undefined
    ? foer.dato
    : tid.kraevGyldigDato(String(aendringer.dato).trim(), 'Dato');

  let nyIndISO = foer.checkIndTid;
  if (aendringer.checkInd !== undefined) {
    nyIndISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(nyDato, aendringer.checkInd));
  } else if (nyDato !== foer.dato) {
    // Flyttes dagen, flytter klokkeslættet med
    nyIndISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(nyDato, tid.klokkeslaetMedSekunder(foer.checkIndTid)));
  }

  let nyUdISO = foer.checkUdTid;
  if (aendringer.checkUd !== undefined) {
    nyUdISO = aendringer.checkUd === null || String(aendringer.checkUd).trim() === ''
      ? null
      : tid.tilISO(tid.datoOgKlokkeslaetTilDato(nyDato, aendringer.checkUd));
  } else if (nyDato !== foer.dato && foer.checkUdTid !== null) {
    nyUdISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(nyDato, tid.klokkeslaetMedSekunder(foer.checkUdTid)));
  }

  // En vagt der slutter efter midnat: sluttiden lægges på dagen efter
  if (nyUdISO !== null && tid.fraISO(nyUdISO).getTime() <= tid.fraISO(nyIndISO).getTime()) {
    const dagenEfter = tid.laegDageTil(nyDato, 1);
    const klokkeslaet = aendringer.checkUd !== undefined
      ? aendringer.checkUd
      : tid.klokkeslaetMedSekunder(foer.checkUdTid);

    nyUdISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(dagenEfter, klokkeslaet));

    if (tid.fraISO(nyUdISO).getTime() <= tid.fraISO(nyIndISO).getTime()) {
      throw new Valideringsfejl('Sluttiden skal ligge efter starttiden.');
    }
  }

  const nyKommentar = aendringer.kommentar === undefined
    ? foer.kommentar
    : kraevTekst(aendringer.kommentar, 'Kommentar', { hoejst: 500, paakraevet: false });

  const nySekunder = nyUdISO === null ? null : tid.sekunderMellem(nyIndISO, nyUdISO);

  const uaendret = nyDato === foer.dato
    && nyIndISO === foer.checkIndTid
    && nyUdISO === foer.checkUdTid
    && nyKommentar === foer.kommentar;

  if (uaendret) {
    return { registrering: foer, antalAendringer: 0 };
  }

  return iTransaktion(() => {
    forbered(`
      UPDATE registreringer
      SET dato = @dato,
          check_ind_tid = @ind,
          check_ud_tid = @ud,
          sekunder = @sekunder,
          kommentar = @kommentar,
          rettet_af_admin = 1,
          sidst_aendret_tid = @nu
      WHERE id = @id
    `).run({
      dato: nyDato,
      ind: nyIndISO,
      ud: nyUdISO,
      sekunder: nySekunder,
      kommentar: nyKommentar,
      nu: tid.tilISO(tid.nu()),
      id: foer.id
    });

    const antalAendringer = revision.skrivAendringer({
      administrator,
      handling: 'ret',
      tabel: 'registreringer',
      postId: foer.id,
      medarbejderId: foer.medarbejderId,
      begrundelse,
      foer: {
        dato: foer.dato,
        check_ind_tid: foer.checkIndTid,
        check_ud_tid: foer.checkUdTid,
        kommentar: foer.kommentar
      },
      efter: {
        dato: nyDato,
        check_ind_tid: nyIndISO,
        check_ud_tid: nyUdISO,
        kommentar: nyKommentar
      }
    });

    return { registrering: hent(foer.id), antalAendringer };
  });
}

/**
 * Opretter en registrering bagud i tiden - f.eks. når en medarbejder helt
 * glemte at checke ind. Markeres som rettet af administrator.
 */
function opretManuelt(oplysninger, administrator, begrundelse = null) {
  const medarbejder = medarbejdere.hent(oplysninger.medarbejderId);
  const dato = tid.kraevGyldigDato(String(oplysninger.dato || '').trim(), 'Dato');

  if (!tid.erGyldigtKlokkeslaet(String(oplysninger.checkInd || ''))) {
    throw new Valideringsfejl('Angiv et starttidspunkt i formatet tt:mm.');
  }

  const indISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(dato, oplysninger.checkInd));

  let udISO = null;
  if (oplysninger.checkUd && String(oplysninger.checkUd).trim() !== '') {
    udISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(dato, oplysninger.checkUd));

    if (tid.fraISO(udISO).getTime() <= tid.fraISO(indISO).getTime()) {
      udISO = tid.tilISO(tid.datoOgKlokkeslaetTilDato(tid.laegDageTil(dato, 1), oplysninger.checkUd));
    }
  }

  const kommentar = kraevTekst(oplysninger.kommentar, 'Kommentar', {
    hoejst: 500, paakraevet: false
  });

  return iTransaktion(() => {
    if (udISO === null && aktiv(medarbejder.id)) {
      throw new Konflikt(
        `${medarbejder.navn} har allerede en åben registrering. Luk den først.`,
        'allerede_checket_ind'
      );
    }

    const nu = tid.tilISO(tid.nu());

    const resultat = forbered(`
      INSERT INTO registreringer (
        medarbejder_id, dato, check_ind_tid, check_ud_tid, sekunder,
        rettet_af_admin, kommentar, oprettet_tid, sidst_aendret_tid
      ) VALUES (
        @medarbejderId, @dato, @ind, @ud, @sekunder, 1, @kommentar, @nu, @nu
      )
    `).run({
      medarbejderId: medarbejder.id,
      dato,
      ind: indISO,
      ud: udISO,
      sekunder: udISO === null ? null : tid.sekunderMellem(indISO, udISO),
      kommentar,
      nu
    });

    const nyId = Number(resultat.lastInsertRowid);

    revision.skriv({
      administrator,
      handling: 'opret',
      tabel: 'registreringer',
      postId: nyId,
      medarbejderId: medarbejder.id,
      felt: 'registrering',
      ny: `${tid.datoDansk(dato)} ${tid.klokkeslaet(indISO)}-${udISO ? tid.klokkeslaet(udISO) : 'åben'}`,
      begrundelse
    });

    return hent(nyId);
  });
}

/**
 * Sletter en registrering. Kræver en begrundelse, og hele den slettede
 * registrering gemmes i ændringsloggen, så timerne kan genskabes manuelt.
 */
function slet(id, administrator, begrundelse) {
  const registrering = hent(id);

  const forklaring = kraevTekst(begrundelse, 'Begrundelse', { mindst: 3, hoejst: 500 });

  return iTransaktion(() => {
    revision.skriv({
      administrator,
      handling: 'slet',
      tabel: 'registreringer',
      postId: registrering.id,
      medarbejderId: registrering.medarbejderId,
      felt: 'registrering',
      gammel: `${tid.datoDansk(registrering.dato)} `
        + `${registrering.checkInd}-${registrering.checkUd || 'åben'} `
        + `(${registrering.varighed || 'ingen varighed'})`,
      begrundelse: forklaring
    });

    forbered('DELETE FROM registreringer WHERE id = ?').run(registrering.id);

    return { slettet: true, registrering };
  });
}

module.exports = {
  hent,
  aktiv,
  checketIndNu,

  checkInd,
  checkUd,
  automatiskCheckUd,

  sumFor,
  loebendeSekunder,
  oversigt,
  status,

  hentPeriode,
  dagssummer,
  hentDag,

  opdater,
  opretManuelt,
  slet
};
