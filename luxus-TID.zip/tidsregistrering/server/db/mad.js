'use strict';

/**
 * server/db/mad.js
 *
 * Madordningen. Medarbejderen trykker "Jeg har spist" og skriver hvad maden
 * kostede - f.eks. 99. Systemet trækker de 25 % medarbejderrabat fra og
 * gemmer måltidet.
 *
 * Der findes ingen fast pris i systemet. Beløbet skal skrives hver gang, og
 * det er derfor et påkrævet felt.
 *
 * Prisen fryses ved registreringen: det indtastede beløb, rabatprocenten og
 * den faktiske pris gemmes på hver enkelt række, så en opgørelse fra en
 * tidligere måned aldrig kan ændre sig bagud.
 *
 * Højst ét måltid pr. medarbejder pr. dag. Databasen håndhæver det.
 */

const config = require('../config');
const { forbered, iTransaktion } = require('./database');
const medarbejdere = require('./medarbejdere');
const indstillinger = require('./indstillinger');
const revision = require('./revision');
const tid = require('../lib/tid');
const {
  IkkeFundet, Konflikt, Valideringsfejl, kraevTekst, kraevHeltal
} = require('../lib/fejl');

/** Højeste beløb der kan skrives for ét måltid. Fanger tastefejl som "8000". */
const HOEJESTE_BELOEB_OERE = 100000;

const FELTER = `
  id, medarbejder_id, dato, tidspunkt, normalpris_oere,
  rabat_procent, pris_oere, registreret_af, kommentar
`;

/* -------------------------------------------------------------------------- */
/* Visning                                                                    */
/* -------------------------------------------------------------------------- */

function pynt(raekke) {
  if (!raekke) return null;

  return {
    id: raekke.id,
    medarbejderId: raekke.medarbejder_id,
    dato: raekke.dato,
    datoDansk: tid.datoDansk(raekke.dato),
    tidspunkt: raekke.tidspunkt,
    klokkeslaet: tid.klokkeslaet(raekke.tidspunkt),
    normalprisOere: raekke.normalpris_oere,
    normalpris: indstillinger.formatKroner(raekke.normalpris_oere),
    rabatProcent: raekke.rabat_procent,
    rabatOere: raekke.normalpris_oere - raekke.pris_oere,
    rabat: indstillinger.formatKroner(raekke.normalpris_oere - raekke.pris_oere),
    prisOere: raekke.pris_oere,
    pris: indstillinger.formatKroner(raekke.pris_oere),
    registreretAf: raekke.registreret_af,
    kommentar: raekke.kommentar
  };
}

/* -------------------------------------------------------------------------- */
/* Opslag                                                                     */
/* -------------------------------------------------------------------------- */

function hent(id) {
  const nummer = kraevHeltal(id, 'Madregistrerings-id', { mindst: 1 });
  const raekke = forbered(`SELECT ${FELTER} FROM madregistreringer WHERE id = ?`).get(nummer);

  if (!raekke) throw new IkkeFundet('Madregistreringen findes ikke.');

  return pynt(raekke);
}

/** Dagens måltid for en medarbejder, eller null hvis der ikke er spist. */
function hentForDato(medarbejderId, dato) {
  tid.kraevGyldigDato(dato, 'Dato');

  const raekke = forbered(`
    SELECT ${FELTER} FROM madregistreringer WHERE medarbejder_id = ? AND dato = ?
  `).get(Number(medarbejderId), dato);

  return pynt(raekke);
}

function hentPeriode(medarbejderId, fra, til) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  return forbered(`
    SELECT ${FELTER} FROM madregistreringer
    WHERE medarbejder_id = ? AND dato BETWEEN ? AND ?
    ORDER BY dato
  `).all(Number(medarbejderId), fra, til).map(pynt);
}

/**
 * Antal måltider og samlet beløb i en periode.
 * @returns {{antal:number, prisOere:number, pris:string, normalprisOere:number}}
 */
function sumFor(medarbejderId, fra, til) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  const svar = forbered(`
    SELECT
      COUNT(*) AS antal,
      COALESCE(SUM(pris_oere), 0) AS pris_oere,
      COALESCE(SUM(normalpris_oere), 0) AS normalpris_oere
    FROM madregistreringer
    WHERE medarbejder_id = ? AND dato BETWEEN ? AND ?
  `).get(Number(medarbejderId), fra, til);

  return {
    antal: svar.antal,
    prisOere: svar.pris_oere,
    pris: indstillinger.formatKroner(svar.pris_oere),
    normalprisOere: svar.normalpris_oere,
    rabatOere: svar.normalpris_oere - svar.pris_oere,
    rabat: indstillinger.formatKroner(svar.normalpris_oere - svar.pris_oere)
  };
}

/**
 * Det medarbejdersiden skal vise: har jeg spist i dag, hvad koster det,
 * og hvad står jeg for denne måned.
 */
function oversigt(medarbejderId, nu = tid.nu()) {
  const id = kraevHeltal(medarbejderId, 'Medarbejder-id', { mindst: 1 });
  const iDag = tid.lokalDato(nu);
  const maaned = tid.maanedInterval(iDag);
  const aar = tid.aarInterval(iDag);

  return {
    dato: iDag,
    harSpistIDag: hentForDato(id, iDag) !== null,
    iDag: hentForDato(id, iDag),
    rabatProcent: config.madrabatProcent,
    hoejesteBeloebOere: HOEJESTE_BELOEB_OERE,
    denneMaaned: sumFor(id, maaned.fra, maaned.til),
    detteAar: sumFor(id, aar.fra, aar.til)
  };
}

/* -------------------------------------------------------------------------- */
/* Registrering                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Registrerer et måltid.
 *
 * @param {object} p
 * @param {number} p.medarbejderId
 * @param {string} [p.dato]            Standard: i dag. Kun administrator må vælge en anden dag.
 * @param {string|number} p.beloeb  Hvad maden kostede, i kroner ('99' eller '85,50').
 *                                   Påkrævet - der findes ingen fast pris.
 * @param {'medarbejder'|'administrator'} [p.registreretAf='medarbejder']
 * @param {string} [p.kommentar]
 * @param {{id:?number, navn:string}} [p.administrator] Kræves når administrator registrerer.
 */
function registrer(p) {
  const registreretAf = p.registreretAf === 'administrator' ? 'administrator' : 'medarbejder';
  const medarbejder = registreretAf === 'administrator'
    ? medarbejdere.hent(p.medarbejderId)
    : medarbejdere.hentAktiv(p.medarbejderId);

  const iDag = tid.iDag();
  const dato = p.dato ? tid.kraevGyldigDato(String(p.dato).trim(), 'Dato') : iDag;

  // Medarbejderen kan kun registrere dagens måltid. Bagudrettede
  // registreringer er en administratorhandling, så de kan spores.
  if (registreretAf === 'medarbejder' && dato !== iDag) {
    throw new Konflikt(
      'Mad kan kun registreres for i dag. Kontakt den ansvarlige for at få rettet en tidligere dag.',
      'kun_i_dag'
    );
  }

  if (dato > iDag) {
    throw new Konflikt('Mad kan ikke registreres frem i tiden.', 'fremtidig_dato');
  }

  const kommentar = kraevTekst(p.kommentar, 'Kommentar', { hoejst: 300, paakraevet: false });

  // Beløbet skrives i kroner og er påkrævet
  if (p.beloeb === undefined || p.beloeb === null || String(p.beloeb).trim() === '') {
    throw new Valideringsfejl('Skriv hvad maden kostede, f.eks. 99.');
  }

  const beloebOere = indstillinger.kronerTilOere(p.beloeb);

  if (beloebOere <= 0) {
    throw new Valideringsfejl('Beløbet skal være større end 0 kr.');
  }

  if (beloebOere > HOEJESTE_BELOEB_OERE) {
    throw new Valideringsfejl(
      `Beløbet må højst være ${indstillinger.formatKroner(HOEJESTE_BELOEB_OERE, false)} kr. `
      + 'Kontrollér at du har skrevet kroner og ikke ører.'
    );
  }

  const priser = indstillinger.beregnMedarbejderpris(beloebOere, config.madrabatProcent);

  return iTransaktion(() => {
    const findes = hentForDato(medarbejder.id, dato);

    if (findes) {
      throw new Konflikt(
        dato === iDag
          ? `Maden er allerede registreret i dag kl. ${findes.klokkeslaet}.`
          : `Der er allerede registreret mad den ${findes.datoDansk}.`,
        'mad_allerede_registreret',
        { madregistreringId: findes.id, pris: findes.pris }
      );
    }

    const resultat = forbered(`
      INSERT INTO madregistreringer (
        medarbejder_id, dato, tidspunkt, normalpris_oere,
        rabat_procent, pris_oere, registreret_af, kommentar
      ) VALUES (
        @medarbejderId, @dato, @tidspunkt, @normalpris,
        @rabat, @pris, @af, @kommentar
      )
    `).run({
      medarbejderId: medarbejder.id,
      dato,
      tidspunkt: tid.tilISO(tid.nu()),
      normalpris: priser.normalprisOere,
      rabat: priser.rabatProcent,
      pris: priser.prisOere,
      af: registreretAf,
      kommentar
    });

    const nyId = Number(resultat.lastInsertRowid);

    // Kun administratorens indgreb havner i ændringsloggen. Medarbejderens
    // eget tryk er ikke en rettelse - det er den almindelige brug.
    if (registreretAf === 'administrator') {
      revision.skriv({
        administrator: p.administrator,
        handling: 'opret',
        tabel: 'madregistreringer',
        postId: nyId,
        medarbejderId: medarbejder.id,
        felt: 'mad',
        ny: `${tid.datoDansk(dato)} ${indstillinger.formatKroner(priser.prisOere)}`,
        begrundelse: p.begrundelse || null
      });
    }

    return { madregistrering: hent(nyId), medarbejder };
  });
}


/**
 * Retter en madregistrering: beløbet, datoen eller kommentaren.
 *
 * Rabatprocenten er den samme som da måltidet blev registreret - ændrer man
 * beløbet, regnes den nye pris med den oprindelige rabat, så en gammel
 * registrering ikke pludselig følger en anden sats.
 *
 * @param {number} id
 * @param {{beloeb?:string|number, dato?:string, kommentar?:string}} aendringer
 * @param {{id:?number, navn:string}} administrator
 * @param {string} [begrundelse]
 * @returns {{madregistrering:object, antalAendringer:number}}
 */
function opdater(id, aendringer, administrator, begrundelse = null) {
  const foer = hent(id);

  const nyDato = aendringer.dato === undefined
    ? foer.dato
    : tid.kraevGyldigDato(String(aendringer.dato).trim(), 'Dato');

  if (nyDato > tid.iDag()) {
    throw new Konflikt('Mad kan ikke registreres frem i tiden.', 'fremtidig_dato');
  }

  let nyNormalOere = foer.normalprisOere;

  if (aendringer.beloeb !== undefined && String(aendringer.beloeb).trim() !== '') {
    nyNormalOere = indstillinger.kronerTilOere(aendringer.beloeb);

    if (nyNormalOere <= 0) {
      throw new Valideringsfejl('Beløbet skal være større end 0 kr.');
    }
    if (nyNormalOere > HOEJESTE_BELOEB_OERE) {
      throw new Valideringsfejl(
        `Beløbet må højst være ${indstillinger.formatKroner(HOEJESTE_BELOEB_OERE, false)} kr. `
        + 'Kontrollér at du har skrevet kroner og ikke ører.'
      );
    }
  }

  const priser = indstillinger.beregnMedarbejderpris(nyNormalOere, foer.rabatProcent);

  const nyKommentar = aendringer.kommentar === undefined
    ? foer.kommentar
    : kraevTekst(aendringer.kommentar, 'Kommentar', { hoejst: 300, paakraevet: false });

  const uaendret = nyDato === foer.dato
    && nyNormalOere === foer.normalprisOere
    && nyKommentar === foer.kommentar;

  if (uaendret) {
    return { madregistrering: foer, antalAendringer: 0 };
  }

  return iTransaktion(() => {
    // Flyttes måltidet til en dag hvor der allerede er registreret mad,
    // ville de to støde sammen. Sig det tydeligt frem for at lade
    // databasen afvise med sin egen besked.
    if (nyDato !== foer.dato) {
      const findes = hentForDato(foer.medarbejderId, nyDato);

      if (findes) {
        throw new Konflikt(
          `Der er allerede registreret mad den ${tid.datoDansk(nyDato)}.`,
          'mad_allerede_registreret'
        );
      }
    }

    forbered(`
      UPDATE madregistreringer
      SET dato = @dato,
          normalpris_oere = @normal,
          pris_oere = @pris,
          kommentar = @kommentar
      WHERE id = @id
    `).run({
      dato: nyDato,
      normal: priser.normalprisOere,
      pris: priser.prisOere,
      kommentar: nyKommentar,
      id: foer.id
    });

    const antalAendringer = revision.skrivAendringer({
      administrator,
      handling: 'ret',
      tabel: 'madregistreringer',
      postId: foer.id,
      medarbejderId: foer.medarbejderId,
      begrundelse,
      foer: {
        dato: foer.dato,
        beloeb: indstillinger.formatKroner(foer.normalprisOere),
        kommentar: foer.kommentar
      },
      efter: {
        dato: nyDato,
        beloeb: indstillinger.formatKroner(priser.normalprisOere),
        kommentar: nyKommentar
      }
    });

    return { madregistrering: hent(foer.id), antalAendringer };
  });
}

/**
 * Fjerner en madregistrering. Kun administrator, og kun med begrundelse -
 * det er et beløb medarbejderen skal betale, så det skal kunne efterprøves.
 */
function fjern(id, administrator, begrundelse) {
  const madregistrering = hent(id);
  const forklaring = kraevTekst(begrundelse, 'Begrundelse', { mindst: 3, hoejst: 500 });

  return iTransaktion(() => {
    revision.skriv({
      administrator,
      handling: 'slet',
      tabel: 'madregistreringer',
      postId: madregistrering.id,
      medarbejderId: madregistrering.medarbejderId,
      felt: 'mad',
      gammel: `${madregistrering.datoDansk} ${madregistrering.pris} `
        + `(normalpris ${madregistrering.normalpris})`,
      begrundelse: forklaring
    });

    forbered('DELETE FROM madregistreringer WHERE id = ?').run(madregistrering.id);

    return { slettet: true, madregistrering };
  });
}

/* -------------------------------------------------------------------------- */
/* Til Administration                                                         */
/* -------------------------------------------------------------------------- */

/** Alle madregistreringer i en periode, på tværs af medarbejdere. */
function alleForPeriode(fra, til, medarbejderId = null) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  const vaerdier = [fra, til];
  let filter = '';

  if (medarbejderId) {
    filter = 'AND m.medarbejder_id = ?';
    vaerdier.push(Number(medarbejderId));
  }

  return forbered(`
    SELECT m.${FELTER.trim().split(/,\s*/).join(', m.')}, e.navn AS medarbejder_navn
    FROM madregistreringer m
    JOIN medarbejdere e ON e.id = m.medarbejder_id
    WHERE m.dato BETWEEN ? AND ? ${filter}
    ORDER BY m.dato DESC, e.navn COLLATE NOCASE
  `).all(...vaerdier).map((r) => ({
    ...pynt(r),
    medarbejderNavn: r.medarbejder_navn
  }));
}

/** Samlet madopgørelse pr. medarbejder i en periode. Bruges til statistik. */
function opgoerelsePrMedarbejder(fra, til) {
  tid.kraevGyldigDato(fra, 'Fra-dato');
  tid.kraevGyldigDato(til, 'Til-dato');

  return forbered(`
    SELECT
      e.id AS medarbejder_id,
      e.navn AS navn,
      COUNT(m.id) AS antal,
      COALESCE(SUM(m.pris_oere), 0) AS pris_oere,
      COALESCE(SUM(m.normalpris_oere), 0) AS normalpris_oere
    FROM medarbejdere e
    LEFT JOIN madregistreringer m
      ON m.medarbejder_id = e.id AND m.dato BETWEEN ? AND ?
    GROUP BY e.id
    HAVING antal > 0
    ORDER BY pris_oere DESC, e.navn COLLATE NOCASE
  `).all(fra, til).map((r) => ({
    medarbejderId: r.medarbejder_id,
    navn: r.navn,
    antal: r.antal,
    prisOere: r.pris_oere,
    pris: indstillinger.formatKroner(r.pris_oere),
    rabatOere: r.normalpris_oere - r.pris_oere,
    rabat: indstillinger.formatKroner(r.normalpris_oere - r.pris_oere)
  }));
}

module.exports = {
  HOEJESTE_BELOEB_OERE,
  hent,
  hentForDato,
  hentPeriode,
  sumFor,
  oversigt,
  registrer,
  opdater,
  fjern,
  alleForPeriode,
  opgoerelsePrMedarbejder
};
