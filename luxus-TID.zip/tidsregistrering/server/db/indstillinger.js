'use strict';

/**
 * server/db/indstillinger.js
 *
 * De værdier administratoren kan ændre under drift - først og fremmest
 * normalprisen for et måltid.
 *
 * Beløb behandles overalt som hele ører i heltal. 80,00 kr. er tallet 8000.
 * Kommatal bruges aldrig til penge: 0,1 + 0,2 giver ikke 0,3 i en computer,
 * og den slags må ikke kunne snige sig ind i en madopgørelse.
 *
 * Rabatten på 25 % står i config.js og ændres kun i koden. Normalprisen
 * ændres i Administration, og hver ændring havner i ændringsloggen.
 */

const config = require('../config');
const { forbered, iTransaktion } = require('./database');
const revision = require('./revision');
const tid = require('../lib/tid');
const { Valideringsfejl, IkkeFundet } = require('../lib/fejl');

/* -------------------------------------------------------------------------- */
/* Kendte indstillinger                                                       */
/* -------------------------------------------------------------------------- */

const KENDTE = {
  virksomhedsnavn: {
    type: 'tekst',
    hoejst: 100,
    standard: 'Restauranten',
    etiket: 'Virksomhedsnavn',
    beskrivelse: 'Står øverst på alle PDF-udskrifter.'
  }
};

/* -------------------------------------------------------------------------- */
/* Beløb                                                                      */
/* -------------------------------------------------------------------------- */

/** 8000 -> '80,00 kr.' */
function formatKroner(oere, medEnhed = true) {
  const tal = Math.round(Number(oere) || 0);
  const fortegn = tal < 0 ? '-' : '';
  const absolut = Math.abs(tal);

  const kroner = Math.floor(absolut / 100);
  const rest = String(absolut % 100).padStart(2, '0');

  // Tusindtalsseparator som punktum, dansk skik: 1.234,50
  const kronerMedPunktum = String(kroner).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

  return `${fortegn}${kronerMedPunktum},${rest}${medEnhed ? ' kr.' : ''}`;
}

/** '80,50', '80.50', '80', ' 80,50 kr. ' -> 8050 */
function kronerTilOere(vaerdi) {
  if (typeof vaerdi === 'number' && Number.isInteger(vaerdi * 100)) {
    return Math.round(vaerdi * 100);
  }

  const tekst = String(vaerdi ?? '')
    .replace(/kr\.?/gi, '')
    .replace(/\s/g, '')
    .replace(/\./g, '')   // tusindtalspunktum
    .replace(',', '.')    // dansk decimalkomma
    .trim();

  if (!/^\d+(\.\d{1,2})?$/.test(tekst)) {
    throw new Valideringsfejl(
      'Prisen skal skrives som kroner og ører, f.eks. 80 eller 80,50.'
    );
  }

  return Math.round(Number.parseFloat(tekst) * 100);
}

/**
 * Beregner medarbejderprisen ud fra normalprisen.
 * Rabatten trækkes fra og resultatet rundes til nærmeste øre.
 *
 * 8000 ører med 25 % rabat -> 6000 ører.
 * 8550 ører med 25 % rabat -> 6413 ører (6412,5 rundet op).
 */
function beregnMedarbejderpris(normalprisOere, rabatProcent = config.madrabatProcent) {
  const normal = Math.max(0, Math.round(Number(normalprisOere) || 0));
  const rabat = Math.min(100, Math.max(0, Math.round(Number(rabatProcent) || 0)));
  const pris = Math.round((normal * (100 - rabat)) / 100);

  return {
    normalprisOere: normal,
    rabatProcent: rabat,
    prisOere: Math.min(pris, normal),
    rabatOere: normal - Math.min(pris, normal)
  };
}

/* -------------------------------------------------------------------------- */
/* Læsning                                                                    */
/* -------------------------------------------------------------------------- */

function raaVaerdi(noegle) {
  const raekke = forbered('SELECT vaerdi FROM indstillinger WHERE noegle = ?').get(noegle);
  return raekke ? raekke.vaerdi : null;
}

function hentTekst(noegle) {
  const kendt = KENDTE[noegle];
  if (!kendt) throw new IkkeFundet(`Ukendt indstilling: ${noegle}`);

  const vaerdi = raaVaerdi(noegle);
  return vaerdi === null ? String(kendt.standard) : vaerdi;
}

function hentHeltal(noegle) {
  const kendt = KENDTE[noegle];
  if (!kendt) throw new IkkeFundet(`Ukendt indstilling: ${noegle}`);

  const raa = raaVaerdi(noegle);
  const tal = Number.parseInt(raa === null ? kendt.standard : raa, 10);

  return Number.isInteger(tal) ? tal : Number(kendt.standard);
}

/** Alle indstillinger med etiket og beskrivelse - bruges af Administration. */
function hentAlle() {
  const gemte = new Map(
    forbered('SELECT noegle, vaerdi, opdateret_tid, opdateret_af FROM indstillinger').all()
      .map((r) => [r.noegle, r])
  );

  return Object.entries(KENDTE).map(([noegle, kendt]) => {
    const gemt = gemte.get(noegle);
    const vaerdi = gemt ? gemt.vaerdi : String(kendt.standard);

    return {
      noegle,
      etiket: kendt.etiket,
      beskrivelse: kendt.beskrivelse,
      type: kendt.type,
      vaerdi,
      visning: kendt.type === 'heltal' && noegle.endsWith('_oere')
        ? formatKroner(vaerdi)
        : vaerdi,
      opdateretTid: gemt ? gemt.opdateret_tid : null,
      opdateretAf: gemt ? gemt.opdateret_af : null
    };
  });
}

/* -------------------------------------------------------------------------- */
/* Skrivning                                                                  */
/* -------------------------------------------------------------------------- */

function validerVaerdi(noegle, vaerdi) {
  const kendt = KENDTE[noegle];

  if (kendt.type === 'heltal') {
    // Prisfelter indtastes ALTID i kroner - '85' betyder 85,00 kr., ikke 85 ører.
    // Uden den regel ville '85' kunne læses på to måder, og forskellen er
    // hundrede gange prisen. Selve værdien gemmes stadig i ører.
    const oere = noegle.endsWith('_oere')
      ? kronerTilOere(vaerdi)
      : Number.parseInt(String(vaerdi).replace(/\s/g, ''), 10);

    if (!Number.isInteger(oere)) {
      throw new Valideringsfejl(`${kendt.etiket} skal være et tal.`, { felt: noegle });
    }
    if (oere < kendt.mindst || oere > kendt.hoejst) {
      throw new Valideringsfejl(
        `${kendt.etiket} skal ligge mellem `
        + `${formatKroner(kendt.mindst, false)} og ${formatKroner(kendt.hoejst, false)} kr.`,
        { felt: noegle }
      );
    }

    return String(oere);
  }

  const tekst = String(vaerdi ?? '').trim();

  if (tekst === '' && kendt.paakraevet !== false) {
    throw new Valideringsfejl(`${kendt.etiket} skal udfyldes.`, { felt: noegle });
  }
  if (tekst.length > kendt.hoejst) {
    throw new Valideringsfejl(
      `${kendt.etiket} må højst være på ${kendt.hoejst} tegn.`,
      { felt: noegle }
    );
  }

  return tekst;
}

/**
 * Ændrer én indstilling. Skriver samtidig i ændringsloggen.
 *
 * Prisfelter (nøgler der ender på _oere) indtastes i KRONER: '85' eller
 * '85,50'. Værdien gemmes i ører. Læsning med hentHeltal giver ører tilbage.
 *
 * @returns {{noegle:string, foer:string, efter:string, aendret:boolean}}
 */
function saet(noegle, vaerdi, administrator, begrundelse = null) {
  if (!KENDTE[noegle]) {
    throw new IkkeFundet(`Ukendt indstilling: ${noegle}`);
  }

  const ny = validerVaerdi(noegle, vaerdi);

  return iTransaktion(() => {
    const foer = raaVaerdi(noegle) ?? String(KENDTE[noegle].standard);

    if (foer === ny) {
      return { noegle, foer, efter: ny, aendret: false };
    }

    forbered(`
      INSERT INTO indstillinger (noegle, vaerdi, beskrivelse, opdateret_tid, opdateret_af)
      VALUES (@noegle, @vaerdi, @beskrivelse, @tid, @af)
      ON CONFLICT(noegle) DO UPDATE SET
        vaerdi = @vaerdi,
        opdateret_tid = @tid,
        opdateret_af = @af
    `).run({
      noegle,
      vaerdi: ny,
      beskrivelse: KENDTE[noegle].beskrivelse,
      tid: tid.tilISO(tid.nu()),
      af: administrator ? administrator.navn : 'System'
    });

    revision.skriv({
      administrator,
      handling: 'indstilling',
      tabel: 'indstillinger',
      felt: noegle,
      gammel: foer,
      ny,
      begrundelse
    });

    return { noegle, foer, efter: ny, aendret: true };
  });
}

/* -------------------------------------------------------------------------- */
/* Genveje                                                                    */
/* -------------------------------------------------------------------------- */

function virksomhedsnavn() {
  return hentTekst('virksomhedsnavn');
}

/** Fodnoten er fjernet fra Indstillinger. Tom tekst holder PDF-koden uændret. */
function pdfFodnote() {
  return '';
}

module.exports = {
  KENDTE,

  formatKroner,
  kronerTilOere,
  beregnMedarbejderpris,

  hentTekst,
  hentHeltal,
  hentAlle,
  saet,

  virksomhedsnavn,
  pdfFodnote
};
