'use strict';

/**
 * server/db/revision.js
 *
 * Ændringsloggen. Hver gang en administrator retter noget, gemmes hvad der
 * blev ændret, fra hvad til hvad, af hvem og hvornår.
 *
 * Loggen er det ENESTE sted en rettelse kan ses. Ude på registreringerne selv
 * står der intet - hverken på medarbejdersiden, i kalenderen, på PDF-udskriften
 * eller i adminpanelets timeoversigt. Åbner man en vagt, ser den ud som enhver
 * anden. Vil man vide om noget er blevet rettet, skal man slå det op i loggen.
 *
 * Loggen skrives i samme transaktion som selve ændringen. Går ændringen
 * tilbage, gør logposten det også. Der kan derfor ikke opstå en logpost
 * for noget der aldrig skete - eller en ændring uden spor.
 */

const { forbered } = require('./database');
const tid = require('../lib/tid');
const { Valideringsfejl } = require('../lib/fejl');

const HANDLINGER = [
  'opret', 'ret', 'slet', 'aktiver', 'deaktiver', 'indstilling', 'backup', 'gendan'
];

/** Handlinger systemet selv udfører, uden en administrator bag. */
const SYSTEM = Object.freeze({ id: null, navn: 'System' });

/** Feltnavne som de hedder i databasen, oversat til noget der kan læses. */
const FELTNAVNE = {
  check_ind_tid: 'check ind',
  check_ud_tid: 'check ud',
  dato: 'dato',
  kommentar: 'kommentar',
  sekunder: 'varighed',
  navn: 'navn',
  aktiv: 'aktiv',
  sorteringsnummer: 'rækkefølge',
  noter: 'note',
  brugernavn: 'brugernavn',
  kodeord: 'adgangskode',
  filnavn: 'backupfil',
  databasefil: 'database',
  registrering: 'registrering',
  mad: 'madregistrering',
  virksomhedsnavn: 'virksomhedsnavn'
};

/* -------------------------------------------------------------------------- */
/* Skrivning                                                                  */
/* -------------------------------------------------------------------------- */

const INDSAET = `
  INSERT INTO aendringslog (
    tidspunkt, administrator_id, administrator_navn, handling,
    tabel, post_id, medarbejder_id, felt, gammel_vaerdi, ny_vaerdi, begrundelse
  ) VALUES (
    @tidspunkt, @administrator_id, @administrator_navn, @handling,
    @tabel, @post_id, @medarbejder_id, @felt, @gammel_vaerdi, @ny_vaerdi, @begrundelse
  )
`;

/** Gør en vilkårlig værdi til tekst der kan læses i panelet. */
function somTekst(vaerdi) {
  if (vaerdi === undefined || vaerdi === null) return null;
  if (typeof vaerdi === 'boolean') return vaerdi ? 'ja' : 'nej';
  if (typeof vaerdi === 'object') {
    try {
      return JSON.stringify(vaerdi);
    } catch (_ignoreret) {
      return '[kunne ikke vises]';
    }
  }
  return String(vaerdi);
}

/**
 * Skriver én linje i ændringsloggen.
 *
 * @param {object} p
 * @param {{id:?number, navn:string}} [p.administrator] Udføreren. Udelades ved systemhandlinger.
 * @param {string} p.handling      En af HANDLINGER.
 * @param {string} p.tabel         Hvilken tabel der blev berørt.
 * @param {number} [p.postId]      Id på den berørte post.
 * @param {number} [p.medarbejderId] Hvem ændringen handler om, hvis relevant.
 * @param {string} [p.felt]        Hvilket felt der blev ændret.
 * @param {*} [p.gammel]           Værdien før.
 * @param {*} [p.ny]               Værdien efter.
 * @param {string} [p.begrundelse] Administratorens egen forklaring.
 * @returns {number} Id på logposten.
 */
function skriv(p) {
  const administrator = p.administrator || SYSTEM;

  if (!HANDLINGER.includes(p.handling)) {
    throw new Valideringsfejl(`Ukendt handling i ændringsloggen: ${p.handling}`);
  }
  if (!p.tabel) {
    throw new Valideringsfejl('Ændringsloggen mangler oplysning om hvilken tabel der blev berørt.');
  }

  const resultat = forbered(INDSAET).run({
    tidspunkt: tid.tilISO(tid.nu()),
    administrator_id: administrator.id ?? null,
    administrator_navn: administrator.navn || 'System',
    handling: p.handling,
    tabel: p.tabel,
    post_id: p.postId ?? null,
    medarbejder_id: p.medarbejderId ?? null,
    felt: p.felt ?? null,
    gammel_vaerdi: somTekst(p.gammel),
    ny_vaerdi: somTekst(p.ny),
    begrundelse: p.begrundelse ? String(p.begrundelse).trim().slice(0, 500) : null
  });

  return Number(resultat.lastInsertRowid);
}

/**
 * Sammenligner to tilstande og skriver én linje pr. felt der reelt ændrede sig.
 * @returns {number} Antal linjer skrevet. Nul betyder at intet blev ændret.
 */
function skrivAendringer(p) {
  const { foer = {}, efter = {} } = p;
  let antal = 0;

  for (const felt of Object.keys(efter)) {
    const gammel = somTekst(foer[felt]);
    const ny = somTekst(efter[felt]);

    if (gammel === ny) continue;

    skriv({
      administrator: p.administrator,
      handling: p.handling || 'ret',
      tabel: p.tabel,
      postId: p.postId,
      medarbejderId: p.medarbejderId,
      felt,
      gammel,
      ny,
      begrundelse: p.begrundelse
    });

    antal += 1;
  }

  return antal;
}

/* -------------------------------------------------------------------------- */
/* Læsning                                                                    */
/* -------------------------------------------------------------------------- */

const GRUNDVALG = `
  SELECT
    id, tidspunkt, administrator_id, administrator_navn, handling,
    tabel, post_id, medarbejder_id, felt, gammel_vaerdi, ny_vaerdi, begrundelse
  FROM aendringslog
`;

const ISO_MOENSTER = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;

/**
 * Gør en gemt værdi læselig. Tidspunkter står i databasen som UTC i ISO-format;
 * i loggen skal de læses som dansk dato og klokkeslæt.
 */
function laeseligVaerdi(vaerdi) {
  if (vaerdi === null || vaerdi === undefined) return null;

  const tekst = String(vaerdi);

  if (ISO_MOENSTER.test(tekst)) {
    try {
      const dato = tid.fraISO(tekst);
      return `${tid.datoDansk(tid.lokalDato(dato))} kl. ${tid.klokkeslaet(tekst)}`;
    } catch (_ignoreret) {
      return tekst;
    }
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(tekst)) {
    try {
      return tid.datoDansk(tekst);
    } catch (_ignoreret) {
      return tekst;
    }
  }

  return tekst;
}

function pynt(raekke) {
  if (!raekke) return null;

  return {
    id: raekke.id,
    tidspunkt: raekke.tidspunkt,
    dato: tid.datoDansk(tid.lokalDato(tid.fraISO(raekke.tidspunkt))),
    klokkeslaet: tid.klokkeslaetMedSekunder(raekke.tidspunkt),
    administratorId: raekke.administrator_id,
    administrator: raekke.administrator_navn,
    handling: raekke.handling,
    tabel: raekke.tabel,
    postId: raekke.post_id,
    medarbejderId: raekke.medarbejder_id,
    felt: FELTNAVNE[raekke.felt] || raekke.felt,
    foer: laeseligVaerdi(raekke.gammel_vaerdi),
    efter: laeseligVaerdi(raekke.ny_vaerdi),
    begrundelse: raekke.begrundelse
  };
}

/** Hele historikken for én post, nyeste først. */
function hentForPost(tabel, postId) {
  return forbered(`${GRUNDVALG} WHERE tabel = ? AND post_id = ? ORDER BY tidspunkt DESC, id DESC`)
    .all(String(tabel), Number(postId))
    .map(pynt);
}

/** Alt hvad der er sket for én medarbejder, nyeste først. */
function hentForMedarbejder(medarbejderId, graense = 200) {
  return forbered(`${GRUNDVALG} WHERE medarbejder_id = ? ORDER BY tidspunkt DESC, id DESC LIMIT ?`)
    .all(Number(medarbejderId), Number(graense))
    .map(pynt);
}

/** Søgning i ændringsloggen. Alle filtre er valgfrie og kan kombineres. */
function soeg(filtre = {}) {
  const betingelser = [];
  const vaerdier = [];

  if (filtre.fraDato) {
    tid.kraevGyldigDato(filtre.fraDato, 'Fra-dato');
    vaerdier.push(tid.tilISO(tid.datoOgKlokkeslaetTilDato(filtre.fraDato, '00:00')));
    betingelser.push('tidspunkt >= ?');
  }

  if (filtre.tilDato) {
    tid.kraevGyldigDato(filtre.tilDato, 'Til-dato');
    const dagenEfter = tid.laegDageTil(filtre.tilDato, 1);
    vaerdier.push(tid.tilISO(tid.datoOgKlokkeslaetTilDato(dagenEfter, '00:00')));
    betingelser.push('tidspunkt < ?');
  }

  if (filtre.handling) {
    if (!HANDLINGER.includes(filtre.handling)) {
      throw new Valideringsfejl(`Ukendt handling: ${filtre.handling}`);
    }
    vaerdier.push(filtre.handling);
    betingelser.push('handling = ?');
  }

  if (filtre.tabel) {
    vaerdier.push(String(filtre.tabel));
    betingelser.push('tabel = ?');
  }

  if (filtre.medarbejderId) {
    vaerdier.push(Number(filtre.medarbejderId));
    betingelser.push('medarbejder_id = ?');
  }

  if (filtre.soegetekst) {
    const moenster = `%${String(filtre.soegetekst).trim()}%`;
    vaerdier.push(moenster, moenster, moenster, moenster);
    betingelser.push(
      '(administrator_navn LIKE ? OR felt LIKE ? OR begrundelse LIKE ? OR ny_vaerdi LIKE ?)'
    );
  }

  const hvor = betingelser.length > 0 ? `WHERE ${betingelser.join(' AND ')}` : '';
  const graense = Math.min(Math.max(Number(filtre.graense) || 200, 1), 2000);

  vaerdier.push(graense);

  return forbered(`${GRUNDVALG} ${hvor} ORDER BY tidspunkt DESC, id DESC LIMIT ?`)
    .all(...vaerdier)
    .map(pynt);
}

/** Antal ændringer i alt. */
function antal() {
  return forbered('SELECT COUNT(*) AS antal FROM aendringslog').get().antal;
}

module.exports = {
  HANDLINGER,
  SYSTEM,
  skriv,
  skrivAendringer,
  hentForPost,
  hentForMedarbejder,
  soeg,
  antal
};
