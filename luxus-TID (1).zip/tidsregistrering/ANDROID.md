# Kør systemet på en Android-telefon eller -tablet

Android kan køre systemet gennem en app der hedder **Termux**. Det virker, men
læs afsnittet "Hvad du skal vide" nederst, før du beslutter dig — en telefon er
ikke bygget til at være server.

Hele opsætningen tager omkring tyve minutter første gang.

---

## Trin 1 — Installer Termux

Termux er **ikke** i Google Play længere. Udgaven derinde er forældet og virker
ikke. Hent den i stedet fra **F-Droid**:

1. Åbn <https://f-droid.org> i telefonens browser
2. Tryk **Download F-Droid** og installer den
   (telefonen spørger om lov til at installere fra ukendt kilde — sig ja)
3. Åbn F-Droid, søg efter **Termux**, og installer den
4. Søg også efter **Termux:API** og installer den
   (den bruges til at holde telefonen vågen)

---

## Trin 2 — Klargør Termux

Åbn Termux. Der kommer en sort skærm med et tastatur. Skriv én linje ad gangen
og tryk retur efter hver:

```
pkg update
```

Den spørger måske om noget undervejs — tryk bare retur.

```
pkg install nodejs-lts unzip termux-api
```

Sig ja hvis den spørger. Det tager et par minutter.

Kontrollér at det virkede:

```
node --version
```

Der skal stå **v22** eller højere. Står der et lavere tal, så kør
`pkg upgrade` og prøv igen.

---

## Trin 3 — Giv Termux adgang til dine filer

```
termux-setup-storage
```

Telefonen spørger om lov. Tryk **Tillad**.

---

## Trin 4 — Læg systemet på telefonen

Overfør `luxus-TID.zip` til telefonen — send den til dig selv på mail, læg den
i Google Drev, eller brug et USB-kabel. Gem den i mappen **Downloads**.

Skriv så i Termux:

```
cd ~/storage/downloads
unzip luxus-TID.zip -d ~
cd ~/tidsregistrering
```

---

## Trin 5 — Start systemet

```
bash start-android.sh
```

Første gang henter den programbibliotekerne — det kræver internet og tager et
minut. Derefter skriver den:

```
Administrator oprettet: admin / admin123

Skriv denne adresse på tabletten:  http://192.168.1.55:3000
```

**Skriv adressen ned.** Det er den, dine medarbejdere skal bruge.

---

## Trin 6 — Sæt tabletten op

Åbn adressen i tablettens browser. Er alt gået godt, står der "Tryk på dit navn".

Log ind i Administration fra din egen telefon eller computer:

```
192.168.1.55:3000/admin
```

Brugernavn `admin`, adgangskode `admin123`. **Skift adgangskoden med det samme**
under Indstillinger.

---

## Hver gang du skal starte systemet igen

Åbn Termux og skriv:

```
cd ~/tidsregistrering
bash start-android.sh
```

To linjer. Du kan holde fingeren nede på Termux-ikonet og lave en genvej, hvis
du vil undgå at skrive dem hver gang.

---

## Vigtigt: telefonen skal have lov til at blive ved

Android lukker apps ned for at spare strøm. Det skal slås fra for Termux,
ellers stopper systemet når skærmen slukker.

**Batterioptimering** — Indstillinger → Apps → Termux → Batteri →
vælg **Ubegrænset** eller **Optimer ikke**. Navnene er lidt forskellige fra
telefon til telefon; led efter noget med batteri eller baggrund.

**Lad telefonen være tilsluttet strøm.** Systemet skal køre hele dagen, og
skærmen tændes jævnligt.

**Slå wi-fi-dvale fra**, hvis din telefon har den indstilling. Ellers mister
tabletten forbindelsen når skærmen har været slukket længe.

Scriptet slår selv `termux-wake-lock` til, som holder telefonen vågen. Du kan
se en notifikation fra Termux mens systemet kører — den skal blive der.

---

## Hvad du skal vide

**Databasen skiftes automatisk.** På en computer bruger systemet pakken
`better-sqlite3`, som skal oversættes til maskinkode. Det er besværligt på en
telefon, så systemet skifter selv til Nodes indbyggede database. Du mærker
ingen forskel — alle funktioner virker ens.

**Android er ikke bygget til dette.** Producenterne lukker baggrundsapps ned for
at spare strøm, og de gør det forskelligt fra mærke til mærke. Samsung og
Xiaomi er kendt for at være hårde ved det. Det kan derfor ske, at systemet
stopper midt på dagen uden varsel — og så kan medarbejderne ikke checke ind.

**Går telefonen tabt, er alt tabt.** Databasen ligger på telefonen. Læg jævnligt
en kopi af mappen `backups` over på Google Drev eller en computer.

**Til daglig drift er en Raspberry Pi et bedre valg.** Den koster omkring
700 kr., bruger 5 watt, går aldrig i dvale, og starter af sig selv efter et
strømsvigt. Android duer fint til at prøve systemet af, eller som nødløsning
hvis computeren er i stykker.

---

## Når noget driller

**"node: command not found"** — Node blev ikke installeret. Kør
`pkg install nodejs-lts` igen.

**"Node.js er for gammel"** — kør `pkg upgrade`, luk Termux helt, og åbn den igen.

**Tabletten kan ikke finde systemet** — kontrollér at Termux stadig kører, at
begge enheder er på samme wi-fi, og at adressen er den rigtige. Telefonens IP
kan ændre sig, når den har været væk fra netværket; kør scriptet igen og se
hvad der står.

**Systemet stopper når skærmen slukker** — batterioptimeringen er ikke slået
fra for Termux. Se afsnittet ovenfor.

**Termux lukker af sig selv** — telefonen er løbet tør for hukommelse. Luk
andre apps, og lad være med at bruge telefonen til andet mens systemet kører.
