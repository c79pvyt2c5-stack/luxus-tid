#!/data/data/com.termux/files/usr/bin/bash
#
# start-android.sh
#
# Starter systemet på en Android-telefon eller -tablet gennem Termux.
#
#   bash start-android.sh
#
# Holder telefonen vågen mens systemet kører, og starter serveren igen hvis
# den skulle gå ned. Luk med Ctrl+C.

cd "$(dirname "$0")" || exit 1

clear
echo ""
echo "  Tidsregistrering - Android"
echo "  =========================="
echo ""

# --- Node.js -------------------------------------------------------------
if ! command -v node > /dev/null 2>&1; then
  echo "  Node.js er ikke installeret i Termux."
  echo ""
  echo "  Kør denne kommando først:"
  echo "      pkg install nodejs-lts"
  echo ""
  exit 1
fi

HOVEDVERSION=$(node -p "process.versions.node.split('.')[0]")

if [ "$HOVEDVERSION" -lt 22 ]; then
  echo "  Node.js $(node --version) er for gammel."
  echo ""
  echo "  På Android bruger systemet Nodes indbyggede database,"
  echo "  og den kræver version 22 eller nyere."
  echo ""
  echo "  Kør:  pkg upgrade && pkg install nodejs-lts"
  echo ""
  exit 1
fi

# --- Programbiblioteker --------------------------------------------------
if [ ! -d node_modules ]; then
  echo "  Henter programbiblioteker (kræver internet, tager et minut) ..."
  echo ""

  if ! npm install --no-audit --no-fund; then
    echo ""
    echo "  Installationen mislykkedes. Kontrollér internetforbindelsen."
    echo ""
    exit 1
  fi
fi

# --- Hold telefonen vågen ------------------------------------------------
# Uden dette lukker Android systemet ned, så snart skærmen slukker.
if command -v termux-wake-lock > /dev/null 2>&1; then
  termux-wake-lock
  echo "  Telefonen holdes vågen mens systemet kører."
else
  echo "  BEMÆRK: termux-wake-lock blev ikke fundet."
  echo "  Systemet kan blive lukket ned når skærmen slukker."
fi

# --- Netværksadressen ----------------------------------------------------
IP=$(ip route get 1 2> /dev/null | awk '{print $7; exit}')

echo ""
if [ -n "$IP" ]; then
  echo "  Skriv denne adresse på tabletten:  http://$IP:3000"
else
  echo "  Find telefonens IP under Indstillinger -> Wi-Fi."
fi
echo ""
echo "  Luk ikke Termux. Lad den køre i baggrunden."
echo "  Stop systemet med Ctrl+C."
echo ""

oprydning() {
  command -v termux-wake-unlock > /dev/null 2>&1 && termux-wake-unlock
  echo ""
  echo "  Systemet er stoppet."
  echo ""
  exit 0
}

trap oprydning INT TERM

# --- Kør, og start igen hvis den falder ----------------------------------
while true; do
  node server/index.js
  KODE=$?

  [ $KODE -eq 0 ] && oprydning

  echo ""
  echo "  Serveren stoppede uventet. Starter igen om 3 sekunder ..."
  echo ""
  sleep 3
done
