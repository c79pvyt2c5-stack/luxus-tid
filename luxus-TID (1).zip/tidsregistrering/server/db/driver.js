'use strict';

/**
 * server/db/driver.js
 *
 * Vælger databasedriver efter hvad maskinen har.
 *
 *   1. better-sqlite3, hvis den er installeret. Hurtigst, og den vi bruger
 *      på Mac og på en almindelig computer.
 *   2. Nodes egen indbyggede sqlite, hvis ikke. Den kræver ingen oversættelse
 *      til maskinkode og virker derfor også på en telefon (Termux på Android)
 *      og på en Raspberry Pi uden byggeværktøjer.
 *
 * Resten af systemet mærker ingen forskel: begge veje giver den samme
 * Database-klasse med prepare, exec, pragma, transaction og close.
 *
 * Nodes indbyggede sqlite kræver Node 22 eller nyere.
 */

/* -------------------------------------------------------------------------- */
/* Forsøg 1: better-sqlite3                                                   */
/* -------------------------------------------------------------------------- */

let Database = null;
let navn = null;

try {
  Database = require('better-sqlite3');
  navn = 'better-sqlite3';
} catch (_ikkeInstalleret) {
  Database = null;
}

/* -------------------------------------------------------------------------- */
/* Forsøg 2: Nodes indbyggede sqlite                                          */
/* -------------------------------------------------------------------------- */

if (Database === null) {
  let DatabaseSync = null;

  try {
    ({ DatabaseSync } = require('node:sqlite'));
  } catch (_findesIkke) {
    DatabaseSync = null;
  }

  if (DatabaseSync === null) {
    console.error(
      '\nDer blev ikke fundet nogen databasedriver.\n\n'
      + 'Systemet kan bruge én af to:\n'
      + '  1. Pakken better-sqlite3   ->  kør:  npm install\n'
      + '  2. Nodes indbyggede sqlite ->  kræver Node 22 eller nyere\n\n'
      + `Denne maskine kører Node ${process.version}.\n`
      + 'Hent den nyeste LTS-udgave fra nodejs.org, eller kør npm install.\n'
    );
    process.exit(1);
  }

  /** Efterligner en klargjort forespørgsel fra better-sqlite3. */
  class Saetning {
    constructor(indre) {
      this.indre = indre;
    }

    /**
     * better-sqlite3 tager enten løse værdier eller ét objekt med navngivne
     * felter. Nodes sqlite vil have objektet som ét argument, så det sendes
     * videre uændret - men løse værdier skal spredes ud.
     */
    _argumenter(givet) {
      const etObjekt = givet.length === 1
        && givet[0] !== null
        && typeof givet[0] === 'object'
        && !Array.isArray(givet[0]);

      return etObjekt ? [givet[0]] : givet;
    }

    run(...givet) {
      const svar = this.indre.run(...this._argumenter(givet));
      return { changes: svar.changes, lastInsertRowid: svar.lastInsertRowid };
    }

    get(...givet) {
      const raekke = this.indre.get(...this._argumenter(givet));
      // Nodes sqlite giver objekter uden prototype - kopier til almindelige
      return raekke === undefined ? undefined : { ...raekke };
    }

    all(...givet) {
      return this.indre.all(...this._argumenter(givet)).map((r) => ({ ...r }));
    }
  }

  class NodeDatabase {
    constructor(sti, valg = {}) {
      this.db = new DatabaseSync(sti, { readOnly: valg.readonly === true });
      this.aaben = true;
    }

    prepare(sql) {
      return new Saetning(this.db.prepare(sql));
    }

    exec(sql) {
      this.db.exec(sql);
      return this;
    }

    /**
     * PRAGMA med lighedstegn sætter en værdi; uden lighedstegn læser den.
     * valg.simple giver den bare værdi i stedet for et objekt.
     */
    pragma(tekst, valg = {}) {
      const rent = String(tekst).trim();

      if (rent.includes('=')) {
        this.db.exec(`PRAGMA ${rent}`);
        return undefined;
      }

      const raekker = this.db.prepare(`PRAGMA ${rent}`).all();

      if (valg.simple) {
        const foerste = raekker[0];
        return foerste ? Object.values(foerste)[0] : undefined;
      }

      return raekker.map((r) => ({ ...r }));
    }

    /** Samme form som better-sqlite3: giver en funktion der kører i en transaktion. */
    transaction(arbejde) {
      const db = this.db;

      return function iTransaktion(...givet) {
        db.exec('BEGIN');

        try {
          const svar = arbejde(...givet);
          db.exec('COMMIT');
          return svar;
        } catch (fejl) {
          try {
            db.exec('ROLLBACK');
          } catch (_ignoreret) {
            // Kan der ikke rulles tilbage, er den oprindelige fejl vigtigst
          }
          throw fejl;
        }
      };
    }

    close() {
      if (this.aaben) {
        this.db.close();
        this.aaben = false;
      }
    }
  }

  Database = NodeDatabase;
  navn = 'node:sqlite (indbygget)';
}

module.exports = Database;
module.exports.driverNavn = navn;
