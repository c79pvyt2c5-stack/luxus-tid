'use strict';

/**
 * server/db/database.js
 *
 * Åbner databasen, opretter den hvis den ikke findes, og holder skemaet
 * opdateret. Alle andre filer henter deres forbindelse herfra.
 *
 * Databasen findes som én fil: data/tidsregistrering.db
 * Ved siden af den ligger to arbejdsfiler, -wal og -shm, som SQLite selv
 * styrer. De hører til databasen og må ikke slettes manuelt.
 */

const fs = require('fs');
const path = require('path');

const config = require('../config');

/* -------------------------------------------------------------------------- */
/* Indlæsning af databasedriveren                                             */
/* -------------------------------------------------------------------------- */

// Driveren vælger selv mellem better-sqlite3 og Nodes indbyggede sqlite,
// alt efter hvad maskinen har. Se server/db/driver.js.
const Database = require('./driver');

/* -------------------------------------------------------------------------- */
/* Skema og versionering                                                      */
/* -------------------------------------------------------------------------- */

const SKEMAFIL = path.join(__dirname, 'schema.sql');
const NYESTE_SKEMAVERSION = 1;

/**
 * Fremtidige skemaændringer lægges her som funktioner.
 * Nøglen er den version databasen ender på. Eksempel:
 *
 *   2: (db) => {
 *        db.exec('ALTER TABLE medarbejdere ADD COLUMN telefon TEXT');
 *      }
 *
 * Systemet kører dem i rækkefølge, i én transaktion, og hæver
 * PRAGMA user_version undervejs. Eksisterende data bevares.
 */
const MIGRERINGER = {};

/* -------------------------------------------------------------------------- */
/* Åbning                                                                     */
/* -------------------------------------------------------------------------- */

function aabnDatabase() {
  const sti = config.databasefil;
  const erNy = !fs.existsSync(sti);

  let db;

  try {
    db = new Database(sti);
  } catch (fejl) {
    throw new Error(
      `Databasen kunne ikke åbnes: ${sti}\n` +
      `Årsag: ${fejl.message}\n` +
      'Kontrollér at filen ikke er åben i et andet program, og at brugeren har skriveadgang.'
    );
  }

  if (erNy) {
    console.log(`[database] Ny database oprettes: ${sti}`);
  }

  return db;
}

function opsaetPragmaer(db) {
  // WAL lader flere tablets og telefoner læse samtidig med at der skrives.
  db.pragma('journal_mode = WAL');

  // FULL betyder at hver bekræftet registrering står på disken med det samme.
  // Koster ubetydeligt lidt hastighed, og overlever at strømmen ryger.
  db.pragma('synchronous = FULL');

  // Fremmednøgler håndhæves - det er dem der beskytter historikken.
  db.pragma('foreign_keys = ON');

  // Venter i stedet for at fejle, hvis to skrivninger rammer samme øjeblik.
  db.pragma('busy_timeout = 5000');
}

function skemaversion(db) {
  return db.pragma('user_version', { simple: true });
}

function opretSkema(db) {
  if (!fs.existsSync(SKEMAFIL)) {
    throw new Error(`Skemafilen mangler: ${SKEMAFIL}`);
  }

  const sql = fs.readFileSync(SKEMAFIL, 'utf8');

  db.exec('BEGIN');
  try {
    db.exec(sql);
    db.pragma(`user_version = ${NYESTE_SKEMAVERSION}`);
    db.exec('COMMIT');
  } catch (fejl) {
    db.exec('ROLLBACK');
    throw new Error(`Databaseskemaet kunne ikke oprettes: ${fejl.message}`);
  }

  console.log(`[database] Skema oprettet (version ${NYESTE_SKEMAVERSION}).`);
}

function koerMigreringer(db) {
  let version = skemaversion(db);

  if (version === 0) {
    opretSkema(db);
    version = skemaversion(db);
  }

  if (version > NYESTE_SKEMAVERSION) {
    throw new Error(
      `Databasen er version ${version}, men denne udgave af systemet kender kun version ${NYESTE_SKEMAVERSION}.\n` +
      'Du kører formentlig en ældre programversion end databasen. Opdatér systemet i stedet for at fortsætte.'
    );
  }

  while (version < NYESTE_SKEMAVERSION) {
    const naeste = version + 1;
    const migrering = MIGRERINGER[naeste];

    if (typeof migrering !== 'function') {
      throw new Error(`Der mangler en migrering til version ${naeste}.`);
    }

    console.log(`[database] Opdaterer skema: version ${version} -> ${naeste}`);

    db.exec('BEGIN');
    try {
      migrering(db);
      db.pragma(`user_version = ${naeste}`);
      db.exec('COMMIT');
    } catch (fejl) {
      db.exec('ROLLBACK');
      throw new Error(`Migreringen til version ${naeste} fejlede: ${fejl.message}`);
    }

    version = skemaversion(db);
  }
}

function hurtigtIntegritetstjek(db) {
  const svar = db.pragma('quick_check', { simple: true });

  if (svar !== 'ok') {
    console.error(
      '[database] ADVARSEL: databasen bestod ikke integritetstjekket.\n' +
      `[database] Svar: ${svar}\n` +
      '[database] Gendan den nyeste backup fra mappen backups/.'
    );
  }

  return svar;
}

/* -------------------------------------------------------------------------- */
/* Opstart                                                                    */
/* -------------------------------------------------------------------------- */

const db = aabnDatabase();

opsaetPragmaer(db);
koerMigreringer(db);
hurtigtIntegritetstjek(db);

/* -------------------------------------------------------------------------- */
/* Hjælpefunktioner                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Kører en funktion som én transaktion. Fejler noget undervejs,
 * ruller hele ændringen tilbage - der efterlades aldrig halve registreringer.
 *
 *   iTransaktion(() => {
 *     opretRegistrering(...);
 *     skrivTilLog(...);
 *   });
 */
function iTransaktion(arbejde) {
  if (typeof arbejde !== 'function') {
    throw new TypeError('iTransaktion kræver en funktion.');
  }
  return db.transaction(arbejde)();
}

/** Klargjorte forespørgsler genbruges - hurtigere og sikrere mod SQL-indsprøjtning. */
const forberedteCache = new Map();

function forbered(sql) {
  let saetning = forberedteCache.get(sql);

  if (!saetning) {
    saetning = db.prepare(sql);
    forberedteCache.set(sql, saetning);
  }

  return saetning;
}

/** Komprimerer databasefilen. Kaldes efter store oprydninger, ikke dagligt. */
function komprimer() {
  db.pragma('wal_checkpoint(TRUNCATE)');
  db.exec('VACUUM');
}

function databaseoplysninger() {
  let stoerrelse = null;

  try {
    stoerrelse = fs.statSync(config.databasefil).size;
  } catch (_ignoreret) {
    stoerrelse = null;
  }

  return {
    sti: config.databasefil,
    skemaversion: skemaversion(db),
    stoerrelseBytes: stoerrelse,
    journaltilstand: db.pragma('journal_mode', { simple: true })
  };
}

let erLukket = false;

/** Lukkes ved kontrolleret nedlukning, så WAL-filen skrives færdig. */
function luk() {
  if (erLukket) return;

  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
  } catch (_ignoreret) {
    // Uden betydning under nedlukning
  }

  db.close();
  erLukket = true;
}

module.exports = {
  db,
  forbered,
  iTransaktion,
  komprimer,
  hurtigtIntegritetstjek,
  databaseoplysninger,
  luk,
  NYESTE_SKEMAVERSION
};
